<?php

namespace App\Imports;

use App\Models\Excel;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;


class ImportUser implements ToModel, WithHeadingRow
{
   public function model(array $row)
   {
     
      return new Excel([
         'Title_of_Educational_Resource' => $row['title_of_educational_resource'],
         'author' => $row['author'],
         'brief_description' => $row['brief_description'],
         'year' => $row['year'],
         'keywords' => $row['keywords'],
         'link' => $row['link'],
         'categor_name' => $row['categor_name'],
         'resource_type' => $row['resource_type'],
         'Contributor' => $row['contributor']

      ]);
   }
}
