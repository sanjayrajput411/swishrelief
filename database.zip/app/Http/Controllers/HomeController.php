<?php

namespace App\Http\Controllers;

use App\Models\Priority;
use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\Category;
use App\Models\Patient;
use App\Models\User;
use DB;
use Carbon;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function getInfo(Request $request, $id)
    {
        $category = Category::get();
        $post_detail = Post::leftjoin('feature_categories', 'posts.feature_category_id', '=', 'feature_categories.id')
            ->select('posts.*', 'feature_categories.feature_category')->where('posts.id', $id)->first();
        $top_stories = Post::leftjoin('feature_categories', 'posts.feature_category_id', '=', 'feature_categories.id')
            ->where('posts.feature_category_id', 2)->orderBy('start_date', 'DESC')->take(5)->get();
        return view('view_detail', compact('category', 'post_detail', 'top_stories'));
    }
  
    public function gethome(Request $request)
    {  
        $data = [];
        return view('home', compact('data'));
    }

    public function showPosts(Request $request)
    {
        $post_id = $request->post_id;
        $data = [];
        $title = '';
        if ($post_id) {

            $data = Post::where('id', $post_id)->get();
            foreach ($data as $row) {

                $title .= '<div class="main_heading"><h3>' . $row->post_name . '</h></br>' .
                    '<p><b><i class="fa fa-globe"></i>' . $row->city . '</b> - BY <i
                     class="fa fa-user-circle"></i>' . $row->author . '- <i
                     class="fa fa-calendar"></i>' . date("M,d,y ", strtotime($row->start_date)) . '
                     </p></div>'
                    . '</p><img src="https://webwatt.com/Theinsiderupdate/public/images/gallery/' . $row->feature_images . '" width="100%">' . '' .

                    '<p class="description">' . implode(' ', array_slice(explode(' ', $row->description), 0, 100)) . "\n" . '</p>' . '</p><a href="https://webwatt.com/Theinsiderupdate/view_detail/' . $row->id . '">' . '<button type="button" class="btn btn-primary readmore">READ MORE</button></a>' . '</a>';
            }
        }
        return $title;
    }

    public function showFeature(Request $request)
    {
        $post_id = $request->post_id;
        $data1 = [];
        $title = '';
        if ($post_id) {

            $data1 = Post::where('id', $post_id)->get();

            foreach ($data1 as $row) {

                $title .= '<div class="main_heading"><h3>' . $row->post_name . '</h3></br>' .
                    '<p><b><i class="fa fa-globe"></i>' . $row->city . '</b> - BY <i
                         class="fa fa-user-circle"></i>' . $row->author . '- <i
                         class="fa fa-calendar"></i>' . date("M,d,y ", strtotime($row->start_date)) . '
                         </p></div>'
                    . '</p><img src="https://webwatt.com/Theinsiderupdate/public/images/gallery/' . $row->feature_images . '" width="100%">' . '' .

                    '<p class="description">' . strip_tags(substr($row->description, 0, 500)) . "\n" . '</p>' . '</p><a href="https://webwatt.com/Theinsiderupdate/view_detail/' . $row->id . '">' . '<button type="button" class="btn btn-primary readmore">READ MORE</button></a>' . '</a>';
            }
        }
        return $title;
    }
    //// report category ////////
    public function showReport(Request $request)
    {
        $post_id = $request->post_id;
        $data2 = [];
        $title = '';
        if ($post_id) {
            $data2 = Post::where('id', $post_id)->get();
            foreach ($data2 as $row) {
                $title .= '<div class="col-md-12 tabs_divide"><ul><video  src=" ' . $row->video . '" controls width="50%"></video></ul><ul><div class="main_videoheading"><h3>' . $row->post_name . '</h3
                ><p>' . '<p><b><i class="fa fa-globe"></i>' . $row->city . '</b> &nbsp;- BY <i
                class="fa fa-user-circle"></i>' . $row->author . '-&nbsp; <i
                class="fa fa-calendar"></i>' . date("M,d,y ", strtotime($row->start_date)) . '
                </p>'
                    . '</p>' . '' . '<p class="description" style="color:red;">' . implode(' ', array_slice(explode(' ', $row->description), 0, 100)) . "\n" . '</p>' . '</p><a href="https://webwatt.com/Theinsiderupdate/view_detail/' . $row->id . '">' . 'READ MORE</a>' . '</a></div></ul></div>';
            }
        }
        return $title;
    }

        public function GetPatient(Request $request)
    {
    
        $company=DB::table('category_company')->orderby('company_name','ASC')->get();
        return view('patient-form',compact('company'));



    }

    public function GetListing(Request $request,$id)
    {
        $company=DB::table('category_company')->orderby('company_name','ASC')->get();
      $patient = Patient::where('id',$id)->first();

        return view('view-listing',compact('patient','company'));
    }



    public function GetPrint(Request $request,$id)
    {

      $patient = Patient::where('id',$id)->first();

        return view('print-view',compact('patient'));
    }


        public function GetEdit(Request $request,$id)
    {
        $company=DB::table('category_company')->orderby('company_name','ASC')->get();
      $patient = Patient::where('id',$id)->first();
   
        return view('edit-listing',compact('patient','company'));
    }



    public function GetDelete(Request $request,$id)
    {

      $patient = Patient::where('id',$id)->delete();

      return redirect()->back()->with('success','Successfully delete');

         
    }





 public function addPatient(Request $request)
    {

            $patient = new Patient();
            $patient->admit_type = $request->input('admit_type');
            $patient->unit_type = $request->input('unit_type');
            $patient->admit_source = $request->input('admit_source');
            $patient->religion = $request->input('religion');
            $patient->discharge_by_discharge_status_time = $request->input('discharge_by_discharge_status_time');
            $patient->admit_date = $request->input('admit_date');
            $patient->time = $request->input('time');
            $patient->m_r = $request->input('m_r');
            $patient->account_number = $request->input('account_number');
            $patient->service = $request->input('service');
            $patient->financial_class = $request->input('financial_class');
            $patient->dob = $request->input('dob');
            $patient->print_by_date = $request->input('print_by_date');
            $patient->sex = $request->input('sex');
            $patient->ssn = $request->input('ssn');
            $patient->race = $request->input('race');
            $patient->room_no = $request->input('room_no');
            $patient->patient_name = $request->input('patient_name');
            $patient->patient_next_name = $request->input('patient_next_name');
            $patient->address = $request->input('address');
            $patient->realtionship = $request->input('realtionship');
            $patient->patient_phone = $request->input('patient_phone');
            $patient->patient_next_phone = $request->input('patient_next_phone');
            $patient->employer = $request->input('employer');
            $patient->address_2 = $request->input('address_2');
            $patient->occupation = $request->input('occupation');
            $patient->name_emergency = $request->input('name_emergency');
            $patient->realtionship_emergency = $request->input('realtionship_emergency');
            $patient->phone_emergency = $request->input('phone_emergency');
            $patient->chief = $request->input('chief');
            $patient->adm_dx = $request->input('adm_dx');
            $patient->proc = $request->input('proc');
            $patient->primary_company = $request->input('primary_company');

            $patient->primary_new_company = $request->input('primary_new_company');
            $patient->secondary_new_company = $request->input('secondary_new_company');

            $patient->primary_address = $request->input('primary_address');
            $patient->primary_certificate = $request->input('primary_certificate');
            $patient->primary_group = $request->input('primary_group');
            $patient->primary_verified = $request->input('primary_verified');
            $patient->primary_effective_date = $request->input('primary_effective_date');
            $patient->primary_ext_date = $request->input('primary_ext_date');
            $patient->secondary_company = $request->input('secondary_company');
            $patient->secondary_address = $request->input('secondary_address');
            $patient->secondary_certificate = $request->input('secondary_certificate');
            $patient->secondary_group = $request->input('secondary_group');
            $patient->secondary_verified = $request->input('secondary_verified');
            $patient->secondary_effective_date = $request->input('secondary_effective_date');
            $patient->secondary_ext_date = $request->input('secondary_ext_date');
            $patient->name_information = $request->input('name_information');
            $patient->address_information = $request->input('address_information');
            $patient->phone_information = $request->input('phone_information');
            $patient->guarantor_employer = $request->input('guarantor_employer');
            $patient->address_employer = $request->input('address_employer');
            $patient->phone_employer = $request->input('phone_employer');
            $patient->occupation_employer = $request->input('occupation_employer');
            $patient->effective_date_employer = $request->input('effective_date_employer');
            $patient->admitting_physician = $request->input('admitting_physician');
            $patient->attending_physician = $request->input('attending_physician');
            $patient->transferring_facility = $request->input('transferring_facility');
            $patient->admitting_phone = $request->input('admitting_phone');
            $patient->attending_phone = $request->input('attending_phone');
            $patient->transferring_phone = $request->input('transferring_phone');

            $patient->save();
            return redirect()->back()->with('User_Created', 'Patient Information Created Successfully.');
         
    }






 public function updatePatient(Request $request,$id)
    {

        Patient::where('id', $id)
       ->update([
              'admit_type' => $request->post('admit_type'),
              'unit_type' => $request->post('unit_type'),
              'admit_source' => $request->post('admit_source'),
              'religion' => $request->post('religion'),
              'discharge_by_discharge_status_time' => $request->post('discharge_by_discharge_status_time'),
              'admit_date' => $request->post('admit_date'),
              'time' => $request->post('time'),
              'account_number' => $request->post('account_number'),
              'service' => $request->post('service'),
              'financial_class' => $request->post('financial_class'),
              'dob' => $request->post('dob'),
              'print_by_date' => $request->post('print_by_date'),
              'sex' => $request->post('sex'),
              'ssn' => $request->post('ssn'),
              'race' => $request->post('race'),
              'room_no' => $request->post('room_no'),
              'patient_name' => $request->post('patient_name'),
              'patient_next_name' => $request->post('patient_next_name'),
              'address' => $request->post('address'),
              'realtionship' => $request->post('realtionship'),
              'patient_phone' => $request->post('patient_phone'),
              'patient_next_phone' => $request->post('patient_next_phone'),
              'employer' => $request->post('employer'),
              'address_2' => $request->post('address_2'),
              'occupation' => $request->post('occupation'),
              'name_emergency' => $request->post('name_emergency'),
              'realtionship_emergency' => $request->post('realtionship_emergency'),
              'phone_emergency' => $request->post('phone_emergency'),
              'chief' => $request->post('chief'),
              'adm_dx' => $request->post('adm_dx'),
              'proc' => $request->post('proc'),
              'primary_company' => $request->post('primary_company'),

              'primary_new_company' => $request->post('primary_new_company'),
              'secondary_new_company' => $request->post('secondary_new_company'),

              'primary_address' => $request->post('primary_address'),
              'primary_certificate' => $request->post('primary_certificate'),
              'primary_group' => $request->post('primary_group'),
              'primary_verified' => $request->post('primary_verified'),
              'primary_effective_date' => $request->post('primary_effective_date'),
              'primary_ext_date' => $request->post('primary_ext_date'),
              'secondary_company' => $request->post('secondary_company'),
              'secondary_address' => $request->post('secondary_address'),
              'secondary_certificate' => $request->post('secondary_certificate'),
              'secondary_group' => $request->post('secondary_group'),
              'secondary_verified' => $request->post('secondary_verified'),
              'secondary_effective_date' => $request->post('secondary_effective_date'),
              'secondary_ext_date' => $request->post('secondary_ext_date'),
              'name_information' => $request->post('name_information'),
              'address_information' => $request->post('address_information'),
              'phone_employer' => $request->post('phone_employer'),
              'occupation_employer' => $request->post('occupation_employer'),
              'effective_date_employer' => $request->post('effective_date_employer'),
              'admitting_physician' => $request->post('admitting_physician'),
              'attending_physician' => $request->post('attending_physician'),
              'transferring_facility' => $request->post('transferring_facility'),
              'admitting_phone' => $request->post('admitting_phone'),
              'attending_phone' => $request->post('attending_phone'),
              'transferring_phone' => $request->post('transferring_phone'),

        ]);

            // $patient->save();
            return redirect()->back()->with('Patient_Updated', 'Updated Information Successfully.');
         
    }








      public function PatientListing(Request $request)
    {
        $patients = Patient::orderby('id','DESC')->get();
        return view('patient-listing', compact('patients'));
    }


      public function dischargepatient(Request $request)
    {
        $currentDate = date('Y-m-d');
        $patients = Patient::where([['discharge_by_discharge_status_time', '<', $currentDate]])->orderby('id','DESC')->get();
        return view('discharge_patient', compact('patients'));
    }

        public function PatientLabel(Request $request,$id)
    {
        $patient =Patient::find($id);
        $mytime = Carbon\Carbon::now();
        $startDate = $mytime; 
        $endDate = $patient->dob; 
        $diff = $startDate->diffInYears($endDate);
      
        return view('patient-label',compact('patient','diff'));
    }

    public function getdistrict(Request $request)
    {
        $address= DB::table('company_address')->where("company_id",$request->primary_company)->pluck('company_address');
        return response()->json(['success' => true,'company_address'=>$address]);
    }
        
}
