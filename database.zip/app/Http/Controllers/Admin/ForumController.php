<?php

namespace App\Http\Controllers\Admin;

use App\Models\Post;
use App\Models\TotalPlan;
use App\Models\Category;
use App\Models\Categor;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use DataTables;
use App\Models\FeatureCategory;
use App\Models\Priority;
use Image;

class ForumController extends Controller
{
    /* view posts page in admin */
    public function post()
    {
        $category = Category::where('status', 1)->get();
        $plans = TotalPlan::get();
        $feature_category = FeatureCategory::get();
        return view('admin.post', compact('category', 'plans', 'feature_category'));
    }
    /*  posts lists in admin */
    public function listpost()
    {
        $data = Post::orderby('created_at', 'DESC')->get();
        $posts = Post::leftjoin('categories', 'posts.category_id', '=', 'categories.id')
            ->leftjoin('sub_categories', 'posts.subcategory_id', '=', 'sub_categories.id')
            ->leftjoin('totalplans', 'posts.plan_id', '=', 'totalplans.id')
            ->leftjoin('feature_categories', 'posts.feature_category_id', '=', 'feature_categories.id')
            ->select('posts.*', 'feature_categories.feature_category', 'categories.category_name', 'sub_categories.subcategory_name', 'totalplans.package_name')
            ->orderby('created_at', 'DESC')->get();
        return view('admin.listpost', compact('data', 'posts'));
    }
    /* add posts page in admin */
    public function addpost(Request $request)
    {
        /* validate that either vedio or image store */
        if ($request->file('video') && $request->file('feature_images')) {
            return back()->with('imgOrVedioErrMsg', 'Select one of the them either vedio or feature image.');
        }


        //validate the files
        $currentDate = date('Y-m-d');
        $currentDate = date('Y-m-d H:i:s', strtotime($currentDate));
        $input = $request->all();
        $images = array();
        $data = $request->only('post_name', 'category_id', 'subcategory_id', 'user_id', 'video', 'tags', 'plan_id', 'draft_name', 'description', 'feature_images',);

        if ($request->file('video')) {
            $file = $request->file('video');
            $filename = $file->getClientOriginalName();
            $path = public_path() . '/videos/';
            $file->move($path, $filename);
            $fl = 'https://webwatt.com/Theinsiderupdate/public' . '/videos/' . $filename;
        }

        $request->validate([
            //'feature_images' => 'required|image|mimes:jpg,png,jpeg',
            'post_name' => 'required',
            'city' => 'required',
            'author' => 'required',
            'plan_id' => 'required',
            'description' => 'required',
            'category_id' => 'present',
            //  'video' => 'mimetypes:video/avi,video/mpeg,video/quicktime'
            //'video' => 'required|file|max:5000|mimes:jpeg,png,mp4,ogg,mp4s
        ]);
        if (!empty($request->file('feature_images'))) {
            $image = $request->file('feature_images');
            $feaureImage = time() . '.' . $image->extension();
            $destinationPath = public_path('/images/thumbnail/');
            $img = Image::make($image->path());
            $img->resize(200, 200, function ($constraint) {
                $constraint->aspectRatio();
            })->save($destinationPath . '/' . $feaureImage);
            $destinationPath1 = public_path('/images/thumb/');
            $img = Image::make($image->path());
            $img->resize(400, 400, function ($constraint) {
                $constraint->aspectRatio();
            })->save($destinationPath1 . '/' . $feaureImage);
            $destinationPath = public_path('/images/gallery');
            $image->move($destinationPath, $feaureImage);
        }
        // dd($request);
        $post = Post::create([
            'post_name' => $request->input('post_name'),
            'category_id' => $request->input('category_id'),
            'subcategory_id' => $request->input('subcategory_id'),
            'tags' => $request->input('tags'),
            'plan_id' => $request->input('plan_id'),
            'draft_name' => $request->input('draft_name'),
            'feature_category_id' => $request->input('feature_category_id'),
            'city' => $request->input('city'),
            'author' => $request->input('author'),
            'start_date' => $currentDate,
            'feature_images' => isset($feaureImage) ? $feaureImage : '',
            'video' => isset($fl) ? $fl : '',
            //'description' => strip_tags($request->input('description')),
            'description' => $request->input('description'),
            'user_id' => Auth::user()->id,
        ]);
        Priority::create([
            'post_id' => $post->id,
            'featured_category_id' => $request->input('feature_category_id'),
        ]);
        return redirect('/admin/list-post')->with('Trans_msg', 'Post Created Successfully.');
    }
    /* delete posts in admin */
    public function deletePost(Request $request, $id)
    {

        Priority::where('post_id', $id)->delete();
        Post::where('id', $id)->delete();
        return redirect()->back()->with('Delete_Msg', 'Post deleted Successfully.');
    }
    /* edit posts in admin */
    public function updatepost(Request $request, $id)
    {
        $posts = Post::find($id);
        $category = Category::where('status', 1)->get();
        $plans = TotalPlan::get();
        $feature_category = FeatureCategory::get();
        return view('admin.updatepost', compact('posts', 'category', 'plans', 'feature_category'));
    }
    /* update posts in admin */
    public function update(Request $request, $id)
    {
        /* validate that either vedio or image store */
        if ($request->file('video') && $request->file('feature_images')) {
            return back()->with('imgOrVedioErrMsg', 'Select one of the them either vedio or feature image.');
        }
        
        $currentDate = date('Y-m-d');
        $currentDate = date('Y-m-d H:i:s', strtotime($currentDate));
        $input = $request->all();
        $images = array();
        $data = $request->only('post_name', 'category_id', 'subcategory_id', 'user_id', 'tags', 'plan_id', 'draft_name', 'description', 'feature_images',);
        if (!empty($request->file('video'))) {
            if ($request->file('video')) {
                $file = $request->file('video');
                $filename = $file->getClientOriginalName();
                $path = public_path() . '/videos/';
                $file->move($path, $filename);
                $fl = 'https://webwatt.com/Theinsiderupdate/public' . '/videos/' . $filename;
                $data = Post::find($id);
                $data->video = isset($fl) ? $fl : '';
                $data->update();
            }
        }
        $image = $request->file('feature_images');
        if (!empty($image)) {
            $feaureImage = time() . '.' . $image->extension();
            $destinationPath = public_path('/images/thumbnail/');
            $img = Image::make($image->path());
            $img->resize(200, 200, function ($constraint) {
                $constraint->aspectRatio();
            })->save($destinationPath . '/' . $feaureImage);
            $destinationPath1 = public_path('/images/thumb/');
            $img = Image::make($image->path());
            $img->resize(400, 400, function ($constraint) {
                $constraint->aspectRatio();
            })->save($destinationPath1 . '/' . $feaureImage);
            $destinationPath = public_path('/images/gallery');
            $image->move($destinationPath, $feaureImage);
            $data = Post::find($id);
            $data->feature_images = isset($feaureImage) ? $feaureImage : $request->file('feature_images');
            $data->update();
        }
        $data = Post::find($id);
        $data->post_name = $request->input('post_name');
        $data->category_id = $request->input('category_id');
        $data->subcategory_id = $request->input('subcategory_id');
        $data->tags = $request->input('tags');
        $data->plan_id = $request->input('plan_id');
        $data->draft_name = $request->input('draft_name');
        $data->feature_category_id = $request->input('feature_category_id');
        $data->city = $request->input('city');
        $data->author = $request->input('author');
        $data->description = $request->input('description');
        $data->update();
        return redirect('admin/list-post')->with('Update_Msg', 'Post Updated Successfully.');
    }
    /* categories in post page  in admin */
    public function categories()
    {
        $data = Category::get();
        return view('admin.categories', compact('data'));
    }
    /* sub categories behald of category in admin */
    public function getcategory(Request $request)
    {

        $category = Categor::where("category_id", $request->category_id)->get(["subcategory_name", "id"]);
        return response()->json(['success' => true, 'subcategory_name' => $category]);
    }
    /* view category list in admin */
    public function index(Request $request)
    {
        if ($request->ajax()) {
            $data = Category::latest()->get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $btn = '<a href="javascript:void(0)" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="Edit" class="edit btn btn-primary btn-sm editcategory">Edit</a>';
                    $btn = $btn . ' <a href="javascript:void(0)" onclick="destroy" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="Delete" class="btn btn-danger btn-sm deletecategory">Delete</a>';
                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('category');
    }
    /*  category add or update in admin */
    public function store(Request $request)
    {
        Category::updateOrCreate(
            [
                'id' => $request->id
            ],
            [
                'category_name' => $request->category_name,
                'category_description' => $request->category_description,
                'user_id'  => Auth::user()->id,
            ]
        );
        return response()->json(['success' => 'category saved successfully.']);
    }
    /* category edit in admin */
    public function edit($id)
    {
        $id = Category::find($id);
        return response()->json($id);
    }
    /* category destroy in admin */
    public function destroy($id)
    {
        Category::find($id)->delete();
        return response()->json(['success' => 'Category deleted successfully.']);
    }
    //For Session Destroy
    public function frontendLogout()
    {
        Auth::logout();
        return redirect('/');
    }
    /* view  post in admin */
    public function getPostView($id)
    {
        $view = Post::leftjoin('feature_categories', 'posts.feature_category_id', '=', 'feature_categories.id')
            ->select('posts.id', 'posts.feature_images', 'feature_categories.feature_category', 'posts.city', 'posts.post_name', 'posts.author', 'posts.description', 'posts.created_at')->find($id);
        return view('admin.post_view', compact('view'));
    }
    /// post selected ///
    public function LatestpostSave(Request $request)
    {
        // dd($request);
        Priority::create([
            'post_id' => $request->post_id,
            'featured_category_id' => $request->featured_category_id,
        ]);
        return response()->json(['success' => 'post selected successfully.']);
    }
}
