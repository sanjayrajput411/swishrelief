<?php

namespace App\Http\Controllers\Admin;

use Auth;
use App\Models\User;
use App\Models\Page;
use App\Http\Controllers\Controller;
use DataTables;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function page()
    {
        return view('admin.dashboard');
    }
    public function index(Request $request)
    {
        $data = DB::table('users')->get();
        if ($request->ajax()) {
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $btn = '<a href="javascript:void(0)" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="Edit" class="edit btn btn-primary btn-sm "><i class="fa-solid fa-pen-to-square"></i></a>';
                    $btn = $btn . ' <a href="javascript:void(0)" onclick="destroy" data-toggle="tooltip"  data-id="' . $row->id . '" data-original-title="Delete" class="delete btn btn-danger btn-sm deletecategory"><i class="fa-solid fa-trash-can"></i></a>';
                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
        return view('userlist');
    }
    public function store(Request $request)
    {
        User::updateOrCreate(
            [
                'id' => $request->id
            ],
            [
                'name' => $request->name,
                'email' => $request->email,
            ]
        );
        return response()->with('Update_User', 'User Created or Updated Successfully.');
    }
    public function edit($id)
    {
        $id = User::find($id);
        return response()->json($id);
    }
    public function destroy($id)
    {
        User::find($id)->delete();
        return response()->json(['success' => 'User deleted successfully.']);
    }
    ///////// Create New Pages Infromation //////////
    public function Getinfo()
    {
        return view('admin.information');
    }
    public function addNewpages(Request $request)
    {
        $input = $request->all();
        $data = $request->only('info_title', 'description', 'tag_title', 'tag_description', 'title_tags', 'tag_keyword',);
        Page::create([
            'info_title' => $request->input('info_title'),
            'description' => $request->input('description'),
            'tag_title' => $request->input('tag_title'),
            'tag_description' => $request->input('tag_description'),
            'title_tags' => $request->input('title_tags'),
            'tag_keyword' => $request->input('tag_keyword'),
        ]);
        return redirect('admin/pages-list')->with('New_msg', 'New Page Created Successfully.');
    }
    public function pagesList(Request $request)
    {
        return view('admin.pages-list');
    }

    /* return vedio upload view page */
    public function uploadVedio()
    {
        return view('admin.upload-vedio');
    }
    /* Store vedio and return url. */
    public function vedioUrlUplaod(Request $request)
    {
        if ($request->file('video')) {
            $file = $request->file('video');
            $filename =  uniqid() . '_' . $file->getClientOriginalName();
            $path = public_path() . '/editorvedios/';
            $file->move($path, $filename);
            $Dbfilename = 'https://webwatt.com/Theinsiderupdate/public' . '/editorvedios/' . $filename;
            return  view('admin.upload-vedio',compact('Dbfilename'))->with('success', 'Successfully upload vedio');
        }
        return back()->with('errvedioUpload', 'Something went wrong, please try again.');
    }



    public function getPageList(Request $request)
    {
        if ($request->ajax()) {
            $data = Page::get();
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function ($row) {
                    $btn = '<a href="' . url('/admin/edit-page/' . $row->id) . '" class="edit btn btn-primary btn-sm"><i class="fa-solid fa-pen-to-square"></i></a>';
                    $btn = $btn . '<a href="' . url('admin/delete-page/' . $row->id) . '" class="edit btn btn-danger btn-sm"><i class="fa-solid fa-trash-can"></i></a>';
                    return $btn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
    }
    public function editPage(Request $request, $id)
    {
        $page = Page::find($id);
        return view('admin.edit-page', compact('page'));
    }
    public function updatePage(Request $request, $id)
    {
        $data = Page::find($id);
        $data->info_title = $request->input('info_title');
        $data->description = $request->input('description');
        $data->tag_title = $request->input('tag_title');
        $data->tag_description = $request->input('tag_description');
        $data->title_tags = $request->input('title_tags');
        $data->tag_keyword = $request->input('tag_keyword');
        $data->update();
        return redirect('admin/pages-list')->with('Update_Msg', 'Page Updated Successfully');
    }
    public function deletePage(Request $request, $id)
    {
        Page::where('id', $id)->delete();
        return redirect()->back()->with('Delete_Page', 'Page deleted Successfully.');
    }
    //For Session Destroy
    public function frontendLogout()
    {
        Auth::logout();
        return redirect('/');
    }
}
