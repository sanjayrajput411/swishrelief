<?php

namespace App\Http\Controllers;

use App\Models\Excel;
use App\Models\Categor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use DataTables;

class AddPackagesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $categ = Categor::get();
        if ($request->cates_name) {
            $all_cat_info = DB::table('excels')->where('categor_name', $request->cates_name)->get();
        } else {
            $all_cat_info = DB::table('excels')->get();
        }
        return view('addPackages', compact('categ', 'all_cat_info'));
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Excel::updateOrCreate(
            [

                'id' => $request->id

            ],
            [
                'Title_of_Educational_Resource' => $request->Title_of_Educational_Resource,
                'author' => $request->author,
                'brief_description'  => $request->brief_description,
                'keywords'  => $request->keywords,
                'link'  => $request->link,
            ]
        );
        return response()->json(['success' => 'category saved successfully.']);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function editForm($id)
    {
        $category = DB::table('excels')->find($id);
        return view('edit', compact('data'));
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateform(Request $request, $id)
    {
        $data = Excel::find($id);
        $data->Title_of_Educational_Resource = $request->input('Title_of_Educational_Resource');
        $data->author = $request->input('author');
        $data->keywords = $request->input('keywords');
        $data->link = $request->input('link');
        $data->update();
        return redirect()->back()->with('status', 'Category Updated Successfully');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function delete($id)
    {
        Excel::find($id)->delete();
        return redirect()->back()->with('message', 'Data is delete Successfully.');
    }
}
