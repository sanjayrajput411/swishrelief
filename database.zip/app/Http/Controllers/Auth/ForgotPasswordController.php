<?php

namespace App\Http\Controllers\Auth;
use Mail;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Http\Request;
use App\Models\User;
//use App\Traits\common;
use App\Models\PasswordResets;
use Crypt;

class ForgotPasswordController extends Controller
{
    //use common;

    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;


    public function forgotPasswordPage()
    {

        return view('auth.passwords.email');
    }

    public function submitForgotPassword(Request $request)
    {
//dd('0');
        $request->validate(
            [
                'email' => 'required|email|exists:users',
            ],
            [
                'email.required' => 'Please enter your email address',
                'email.exists' => 'User not found for this e-mail address'
            ]
        );

        $data = ['name' => 'abhishek', "data" => 'test_id'];
        $user['to'] = $request->email;
        Mail::send('customermail', $data, function ($message) use ($user) {
            $message->to($user['to']);
            $message->subject('Insider Update');
        });

        $userData = User::where("email", $request->email)->first();
        $token = Crypt::encrypt($userData->id);

        $this->sendMail(ucwords($userData->name), $userData->email, 'Reset Password Link', 'reset_link', $token, '');

        PasswordResets::create([
            'email' => $userData->email,
            'token' => $token
        ]);
        return redirect()->back();
    }
    public function ResetForgotPassword(Request $request, $encryptID)
    {
        $decryptedID = Crypt::decrypt($encryptID);
        $userData = User::find($decryptedID);
        $passwordResetData = PasswordResets::where("token", $encryptID)->first();

        if (empty($passwordResetData)) {
            dd("link expired");
        }

        if ($request->isMethod('get')) {

            $data['token'] = $encryptID;
            return view('auth.passwords.reset', $data);
        } else {

            $request->validate(
                [
                    'password' => 'required|min:6',
                    'password_confirmation' => 'required|same:password|min:6'
                ],
                [
                    'password.required' => 'New Password is required',
                    'password.min' => 'New Password minimum length is 6',
                    'password_confirmation.required' => 'Confirm Password is required',
                    'password_confirmation.same' => 'Confirm Password same as New Password',
                ]
            );

            $userData->password = password_hash($request->password, PASSWORD_DEFAULT);
            $userData->save();

            $passwordResetData->delete();

            return redirect('/login');
        }
    }
}
