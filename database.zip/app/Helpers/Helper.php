<?php 
namespace App\Helpers;
use App\Models\Categor;

class Helper 
{

    public function SubCategory($id)
    {

      $sub_category = Categor::where('category_id',$id)->get();
          if(!empty($sub_category)){
            return $sub_category;
          }
          return false;

    }
    
}
