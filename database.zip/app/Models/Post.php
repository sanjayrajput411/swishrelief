<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    use HasFactory;
        
protected $fillable = ['post_name',
'category_id',
'subcategory_id',
'feature_images',
'tags',
'plan_id',
'draft_name',
'user_id',
'description'
];



}
