<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Excel extends Model
{
    use HasFactory;

    protected $fillable = [
        'Title_of_Educational_Resource',
        'author',
        'brief_description',
        'year',
        'keywords',
        'link',
        'categor_name',
        'resource_type',
        'Contributor',
    ];
}
