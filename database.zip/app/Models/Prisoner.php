<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Prisoner extends Model
{
    use HasFactory;
        
protected $fillable = ['first_name',
'prisoner_name',
'last_name',
'mailing_address',
'galleries',
'user_id',

];



}