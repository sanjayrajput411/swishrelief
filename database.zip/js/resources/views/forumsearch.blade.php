@include('layouts.front.include.header')
<!-- start banner section -->
<section class="forum-main-banner">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="contact-heading forum-heading neww">
          <h1>Forum</h1>
          <p>Welcome! Have a look around and join the discussions.</p>
          <ul>
            <li>
              <form action="{{ route('forumsearch') }}" method="GET" style="display: flex;">
                <input type="text" name="search" placeholder="Search.." required />
                <button type="submit">Search</button>
              </form>
            </li>
            <!-- <input type="text" placeholder="Search.." name="search"><i class="fa fa-search"></i></li> -->
            <ul>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end banner section -->
<section class="general-section neww">
  <div class="container">
    <div class="forum-nav">
      <div class="share-store">
        <ul>
          <li>
            <select id="dropDown">
              <option value="Category">--Select Category--</option>
              @foreach ($data as $row)
              <option value="{{url('front/category/'.$row->id)}}">
                <p>{{$row->category_name}}</p>
              </option>
              @endforeach
            </select>
          </li>
          <li class="all-posts"><a href="{{url('front/all-post')}}">All Posts</a></li>
        </ul>
      </div>
      <div class="all-posts">
        <a href="{{url('front/create-post')}}"><button type="button" name="button">Create New Post</button></a>
      </div>
    </div>
    @if($data->isNotEmpty())
    @foreach ($data as $row)
    <div class="row">
      <div class="col-md-12">
        <div class="comman-forum">
          <div class="forms-follow-second">
            <img src="/front/images/millennial-asia.png">
            <a href="{{url('front/category/'.$row->id)}}">
              <h2>{{$row->category_name}}</h2>
            </a>

            <ul>
              <a href="{{url('front/category/'.$row->id)}}"><button type="button" name="button">View All</button></a>
            </ul>
          </div>
          @endforeach

            @endif
        </div>
      </div>
    </div>
  </div>
  </div>
  <!-- </div> -->
</section>
<!-- end section -->
<section class="new-pots">
  <div class="container">
    <h2>New Posts</h2>
    <div class="row">
@if( $search_result)
 
   
    @foreach($search_result as $newposts)
    <div class="col-md-4">
        <div class="take-community-frist">
          <div class="take-second">
            <div class="take-community">
           </div>
            <div class="community-take-heading">
              <a href="" style="text-decoration: inherit;">
                <h3>{{$newposts->name}}</h3>
              </a>
              <p>{{Carbon\Carbon::parse($newposts->created_at)->format('M Y') }}</P>
            </div>
          </div>
          <a href="{{url('front/title/'.$newposts->id)}}" style="text-decoration: inherit;">
            <h5>{{$newposts->post_name}}</h5>
          </a>
          <a href="" style="text-decoration: inherit;">
            <h6>{{$newposts->category_name}}</h6>
          </a>
          <h6 style="height: 100px;overflow: hidden;"></h6>      
          <div class="liked-border">
            <div class="liked">
              <span> <i class="fa fa-heart" aria-hidden="true"></i> </span>
            </div>
            <div class="commentss">
              <span><i class="fa fa-comments" aria-hidden="true"></i> </span>
            </div>
          </div>
        </div>
      </div>
      @endforeach
@else 

      @foreach($post as $newposts)
      <div class="col-md-4">
        <div class="take-community-frist">
          <div class="take-second">
            <div class="take-community">
               <a href="{{url('front/profile/'.$newposts->u_id)}}" style="text-decoration: inherit;">
               <img src="/front/images/profile-main.png"></a> 
            </div>
            <div class="community-take-heading">
              <a href="{{url('front/profile/'.$newposts->u_id)}}" style="text-decoration: inherit;">
                <h3>{{$newposts->name}}</h3>
              </a>
              <p>{{Carbon\Carbon::parse($newposts->created_at)->format('M Y') }}</P>
            </div>
          </div>
          <a href="{{url('front/title/'.$newposts->id)}}" style="text-decoration: inherit;">
            <h5>{{$newposts->post_name}}</h5>
          </a>
          <a href="{{url('front/category/'.$newposts->category_id)}}" style="text-decoration: inherit;">
            <h6>{{$newposts->category_name}}</h6>
          </a>
          <h6 style="height: 100px;overflow: hidden;">
            <?php print_r($newposts->description); ?></h6>
          <!-- <p>{{$newposts->description}}</p> -->
          <div class="liked-border">
            <div class="liked">
              <span> <i class="fa fa-heart" aria-hidden="true"></i> </span>
            </div>
            <div class="commentss">
              <span><i class="fa fa-comments" aria-hidden="true"></i> {{$newposts->comment_count}} </span>
            </div>
          </div>
        </div>
      </div>
      @endforeach
@endif

    </div>
  </div>
</section>
<script>
  var dropDownValue = document.getElementById("dropDown");
  dropDownValue.onchange = function() {
    if (this.selectedIndex !== 0) {
      window.location.href = this.value;
    }
  };
</script>
<style>
  .liked {
    visibility: hidden;
  }
</style>
@include('layouts.front.include.footer')