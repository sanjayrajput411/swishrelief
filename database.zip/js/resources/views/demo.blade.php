@include('layouts.header')
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />

<link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">

<link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>

<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css">
<script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
</head>
<table id="example" class="display nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Age</th>
                <th>Start date</th>
                <th>Salary</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Tiger Nixon</td>
                <td>System Architect</td>
                <td>Edinburgh</td>
                <td>61</td>
                <td>2011-04-25</td>
                <td>$320,800</td>
            </tr>
            <tr>
                <td>Garrett Winters</td>
                <td>Accountant</td>
                <td>Tokyo</td>
                <td>63</td>
                <td>2011-07-25</td>
                <td>$170,750</td>
            </tr>
            <tr>
                <td>Ashton Cox</td>
                <td>Junior Technical Author</td>
                <td>San Francisco</td>
                <td>66</td>
                <td>2009-01-12</td>
                <td>$86,000</td>
            </tr>
            <tr>
                <td>Cedric Kelly</td>
                <td>Senior Javascript Developer</td>
                <td>Edinburgh</td>
                <td>22</td>
                <td>2012-03-29</td>
                <td>$433,060</td>
            </tr>
            <tr>
                <td>Airi Satou</td>
                <td>Accountant</td>
                <td>Tokyo</td>
                <td>33</td>
                <td>2008-11-28</td>
                <td>$162,700</td>
            </tr>
            <tr>
                <td>Brielle Williamson</td>
                <td>Integration Specialist</td>
                <td>New York</td>
                <td>61</td>
                <td>2012-12-02</td>
                <td>$372,000</td>
            </tr>
            <tr>
                <td>Herrod Chandler</td>
                <td>Sales Assistant</td>
                <td>San Francisco</td>
                <td>59</td>
                <td>2012-08-06</td>
                <td>$137,500</td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Age</th>
                <th>Start date</th>
                <th>Salary</th>
            </tr>
        </tfoot>
    </table>
    <script type="text/javascript">
        $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
                buttons: [
                    'copy', 'csv', 'excel', 'pdf', 'print'
                ]
            } );
        } );
    </script>
    <script type="text/javascript">
    $(function() {



        /*------------------------------------------

         --------------------------------------------

         Pass Header Token

         --------------------------------------------

         --------------------------------------------*/

        $.ajaxSetup({

            headers: {

                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

            }

        });



        /*------------------------------------------

        --------------------------------------------

        Render DataTable

        --------------------------------------------

        --------------------------------------------*/

        var table = $('.data-table').DataTable({

            processing: true,

            serverSide: true,

            ajax: "{{ route('fullcategory.index') }}",

            columns: [

                {
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex'
                },

                {
                    data: 'Title_of_Educational_Resource',
                    name: 'Title_of_Educational_Resource'
                },

                {
                    data: 'author',
                    name: 'author'
                },
                // {
                //     data: 'brief_description',
                //     name: 'brief_description'
                // },
                {
                    data: 'keywords',
                    name: 'keywords'
                },
                {
                    data: 'link',
                    name: 'link'
                },

                {
                    data: 'action',
                    name: 'action',
                    orderable: false,
                    searchable: false
                },

            ]

        });



        /*------------------------------------------

        --------------------------------------------

        Click to Button

        --------------------------------------------

        --------------------------------------------*/

        $('#createNewProduct').click(function() {

            $('#saveBtn').val("create-product");

            $('#id').val('');

            $('#productForm').trigger("reset");

            $('#modelHeading').html("Create New Category");

            $('#ajaxModel').modal('show');

        });



        /*------------------------------------------

        --------------------------------------------

        Click to Edit Button

        --------------------------------------------

        --------------------------------------------*/

        $('body').on('click', '.edit', function() {

            var id = $(this).data('id');

            $.get("{{ route('fullcategory.index') }}" + '/' + id + '/edit', function(data) {

                $('#modelHeading').html("Edit Category");

                $('#saveBtn').val("edit-user");

                $('#ajaxModel').modal('show');

                $('#id').val(data.id);

                $('#Title_of_Educational_Resource').val(data.Title_of_Educational_Resource);

                $('#author').val(data.author);
                $('#brief_description').val(data.brief_description);

                $('#keywords').val(data.keywords);

                $('#link').val(data.link);
            })

        });



        /*------------------------------------------

        --------------------------------------------

        Create Product Code

        --------------------------------------------

        --------------------------------------------*/

        $('#saveBtn').click(function(e) {

            e.preventDefault();

            $(this).html('Sending..');



            $.ajax({

                data: $('#productForm').serialize(),

                url: "{{ route('fullcategory.store') }}",

                type: "POST",

                dataType: 'json',

                success: function(data) {



                    $('#productForm').trigger("reset");

                    $('#ajaxModel').modal('hide');

                    table.draw();



                },

                error: function(data) {

                    console.log('Error:', data);

                    $('#saveBtn').html('Save Changes');

                }

            });

        });



        /*------------------------------------------

        --------------------------------------------

        Delete Product Code

        --------------------------------------------

        --------------------------------------------*/

        $('body').on('click', '.delete', function() {


            var id = $(this).data("id");

            if (confirm("Are You sure want to delete !")) {



                $.ajax({

                    type: "DELETE",

                    url: "{{ route('fullcategory.store') }}" + '/' + id,

                    success: function(data) {

                        table.draw();

                    },

                    error: function(data) {

                        console.log('Error:', data);

                    }

                });
            }
        });



    });
</script>
@include('layouts.footer')