@include('layouts.front.include.header')



<!-- start banner section -->
<section class="services-main-banner">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="contact-heading">
          <h1>Pricing</h1>
          <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform. Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>
          <button type="button" class="btn btn-warning">DONATE</button>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end banner section -->
<section class="book-appointment">
  <div class="container-fluid">
    <div class="row no-gutter">
      <div class="col-md-4">
        <div class="join-our-team">
          <div class="blance-our">
            <p><img src="{{asset('front/images/phone-banner.png')}}">(231) 598-8498</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="join-our-one">
          <div class="blance-our">
            <p> <img src="{{asset('front/images/balance-banner.png')}}">Join Our Team</p>
          </div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="join-our-two">
          <div class="blance-our">
            <p><img src="{{asset('front/images/book-appoinment.png')}}">Book An Appointment</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end section -->
<section class="picture-shipped services-plan">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="picture">
          <p>PICTURES</p>
          <h2>Pictures For Prisoners</h2>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-6">
        <div class="we-believe">
          <img src="{{asset('front/images/comma-paragrpah.png')}}">
          <p>We believe that no life is beyond the reach of God's power, and we envision a future in which countless prisoners, ex-prisoners, and their families are redeemed, restored, and reconciled. We provide a service for pictures for prisoners. We charge 60 cents $0.60 per picture and shipped to the prisoner every set of 10.</p>
          <button type="button" class="btn btn-warning">$0.60</button>
        </div>
      </div>
      <div class="col-md-6">
        <div class="we-believes">
          <img src="{{asset('front/images/home-hover-image.png')}}">
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end section -->
<section class="choose-your-plan services-mains">
  <div class="container">
    <div class="plans">
      <p>PLANS</p>
      <h2>Choose Your Pricing Plan</h2>
    </div>
    <div class="row">
      <!-- <div class="col-md-4">
    <div class="have-any">
    <h2>Have Any Questions?</h2>
    <p>We work with a wide variety of groups an individuals to promote prison reform. We look forward to hearing from you!</p>
      <button type="button" class="btn btn-warning">Contact Us</button>
  </div>
  </div> -->
      <?php //echo'<pre>';//print_r($data);die;
      ?>
      @if(Auth::User())
      <div class="col-md-4">
        <div class="bronze-plan">
          <h2>Bronze Plan</h2>
          <h3>$0.00</h3>
          <span>Free Plan</span>
          <p>Perfect for those who want to know the truth behind bars</p>
          <ul>
            <i class="fa fa-check"></i>
            <li>Unlimited access to Prisoners' Corner blogs</li>
            <i class="fa fa-check"></i>
            <li>Unlimited forum access</li>
            <i class="fa fa-check"></i>
            <li>Unlimited access to prisoner re-entry resources</li>
          </ul>

          <a style="text-decoration:none;"><button type="button" class="btn btn-warning">Activated</button></a>
        </div>
      </div>
      @else
      <div class="col-md-4">
        <div class="bronze-plan">
          <h2>Bronze Plan</h2>
          <h3>$0.00</h3>
          <span>Free Plan</span>
          <p>Perfect for those who want to know the truth behind bars</p>
          <ul>
            <i class="fa fa-check"></i>
            <li>Unlimited access to Prisoners' Corner blogs</li>
            <i class="fa fa-check"></i>
            <li>Unlimited forum access</li>
            <i class="fa fa-check"></i>
            <li>Unlimited access to prisoner re-entry resources</li>
          </ul>
          @if(Auth::User())
          @else
          <a href="{{url('front/sign-up')}}" style="text-decoration:none;"><button type="button" class="btn btn-warning">Select</button></a>
          @endif
        </div>
      </div>
      @endif

      @if(Auth::User())


          <div class="col-md-4">
          <form  action="{{url('front/billing-details') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="plan_id" value="{{ $plans1['plan_id'] }}">
            <div class="sliver-plan">
              <!---<h2>Silver Plan</h2>
              <h3>$6.95</h3> -->
              <h2>{{ $plans1['package_name'] }}</h2>
              <h3>${{ $plans1['plan_price'] }}</h3>
              <span>Paid Plan</span>
              <p>Government officials who found themselves on the wrong side</p>
              <ul>
                <i class="fa fa-check"></i>
                <li>Compromised judges</li>
                <i class="fa fa-check"></i>
                <li>Compromised congress</li>
              </ul>
              <button type="submit" class="btn btn-warning">Upgrade</button>
            <!--- <a href="{{url('front/billing-details')}}" style="text-decoration:none;">
            <button type="button" class="btn btn-warning">Upgrade</button>
          </a>  -->
          </form>
            </div>


      </div>
      @else
      <div class="col-md-4">
        <div class="sliver-plan">
          <h2>Silver Plan</h2>
          <h3>$6.95</h3>
          <span>Paid Plan</span>
          <p>Government officials who found themselves on the wrong side</p>
          <ul>
            <i class="fa fa-check"></i>
            <li>Compromised judges</li>
            <i class="fa fa-check"></i>
            <li>Compromised congress</li>
          </ul>
          @if(Auth::User())
          @else
           <a href="{{url('front/sign-up')}}" style="text-decoration:none;"><button type="button" class="btn btn-warning">Select</button></a>
          @endif
        </div>
      </div>
      @endif

      @if(Auth::User())
      <div class="col-md-4">
      <form  action="{{url('front/billing-details') }}" method="POST" enctype="multipart/form-data">
      @csrf
      <input type="hidden" name="plan_id" value="{{ $plans2['plan_id'] }}">

        <div class="sliver-plan">
          <!---<h2>Platinum</h2>
          <h3>$20.00</h3>-->
          <h2>{{ $plans2['package_name'] }}</h2>
              <h3>${{ $plans2['plan_price'] }}</h3>
          <span>Paid Plan</span>
          <p>Government officials who found themselves on the wrong side</p>
          <ul>
            <i class="fa fa-check"></i>
            <li>Compromised judges</li>
            <i class="fa fa-check"></i>
            <li>Compromised congress</li>
          </ul>
         <!---<a href="{{url('front/bill-detail')}}" style="text-decoration:none;"><button type="button" class="btn btn-warning">Upgrade</button></a>-->
         <button type="submit" class="btn btn-warning">Upgrade</button>
         </form>
        </div>
      </div>
      @else
      <div class="col-md-4">
        <div class="sliver-plan">
          <h2>Platinum</h2>
          <h3>$20.00</h3>
          <span>Paid Plan</span>
          <p>Government officials who found themselves on the wrong side</p>
          <ul>
            <i class="fa fa-check"></i>
            <li>Compromised judges</li>
            <i class="fa fa-check"></i>
            <li>Compromised congress</li>
          </ul>
          @if(Auth::User())
          @else
          <a href="{{url('front/sign-up')}}" style="text-decoration:none;"><button type="button" class="btn btn-warning">Select</button></a>
          @endif
        </div>
      </div>
      @endif
    </div>
  </div>
</section>
<!-- end section -->
<section class="research-services">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <div class="we-provider">
          <img src="{{asset('front/images/Rectangle -4.png')}}">
        </div>
      </div>
      <div class="col-md-6 ">
        <div class="we-provider-image">
          <h2>Research Services</h2>
          <img src="{{asset('front/images/search-icon-services.png')}}">
          <p>We provide research services at $6.95 / month but offer discounted rates.</p>
          <button type="button" class="btn btn-warning">$6.95 / month</button>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end section  -->
<section class="consultation-main">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="book-consultation">
          <h5>SERVICES</h5>
          <h2>Book Consultation</h2>
          <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform.Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>
          <button type="button" class="btn btn-warning">Book Now <i class="fa fa-arrow-right" aria-hidden="true"></i></button>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end section -->
<section class="for-frist-main">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="prisonas">
          <h5>SERVICES</h5>
          <h2>Consulting Services</h2>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-5">
        <div class="conselting-service">
          <img src="{{asset('front/images/happy-real-estate.png')}}">
        </div>
      </div>
      <div class="col-md-7">
        <div class="conselting-service-heading">
          <p>Consulting services $ 500 for case research</p>
          <div class="row">
            <div class="col-md-6 col-xs-6 ">
              <button type="button" class="btn btn-warning">Free</button>
              <h6>For First 15 minutes per issue</h6>
            </div>
            <div class="col-md-6 col-xs-6 right">
              <button type="button" class="btn btn-warning">$10</button>
              <h6>For First 15 minutes per issue</h6>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>







@include('layouts.front.include.footer')
