@include('layouts.front.include.header')

 <!-- end navbar -->

   <section class="main-banner">

    <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="sign-main">

        <h1>Log in</h1>

      <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform. Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>

    </div>

    </div>

  </div>

</div>

</section>

<!-- end banner section -->

<!-- start main section  -->

<section class="main-form">

  <div class="container">

   <div class="we-offer">

    <div class="row">

      <div class="col-md-6">

      <div class="login-member">

        <h2>Log in</h2>

       <p><a href="">Sign in</a> </p>

         <form>

            <div class="input-icon">
              <div class="sign-relati-main">

                <i class="fa fa-user"></i>

                <input class="input-field" type="text"  name="username" placeholder="User name">

               </div>

               <div class="sign-relati-main">

                <i class="fa fa-lock" aria-hidden="true"></i>

                <input class="input-fields" type="text"  name="phone" placeholder="Password">

                <p><a href="#">Forgot your password</a></p>

              </div>

              <div >

              <input type="submit" value="LOG IN">

              </div>

               <div class="checkboxx">

                <input type="checkbox" name="vehicle1" value="Bike">

                <label>Login up to this site with a public profile <a href="#"> Read more</a> </label>

                </div>

               </div>

                </form>

                 </div>

                 <div class="sign-here">

                 <h5>Don’t have an account? <a href="{{url('/front/sign-in-by')}}">Sign up here.</a></h5>

               </div>

                 </div>

          <div class="col-md-6">

         <div class="social-reform">

        <img src="images/search-mojar.png">

        <h2>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform.</h2>

        <p>Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>

   </div>

  </div>

</div>

</div>

</div>

</section>

<!-- end section -->



<!-- footer section start -->



@include('layouts.front.include.footer')
