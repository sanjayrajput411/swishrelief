@include('layouts.front.include.header')

<head>

    <!-- Required meta tags -->

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->

    <link href="https://netmaxims.in/projects/powerofourvoice/public/front/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://www.1001fonts.com/quattrocento-font.html?text=Power%20of%20Our%20Voices%20LLC" rel="stylesheet">

    <link href="https://netmaxims.in/projects/powerofourvoice/public//front/css/custom.css" rel="stylesheet" type="text/css">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" rel="stylesheet">

    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="https://netmaxims.in/projects/powerofourvoice/public//front/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

    <title>Power Of Our Voices</title>
<style>
* {
  font-family: 'Segoe UI Light';
  font-size: x-large;
}

.wrapper {
  display: flex;
  border-radius: 7px;
  border: 1px solid lightgray;
  box-shadow: 2px 2px 40px 2px;
  margin: 1.5em 3em;
}

.profile-image {
  flex: 1;
  padding: 1.5em 0;
}

.image {
  height: 200px;
  width: 200px;
  background: orange;
  margin-left: auto;
  margin-right: auto;
  border-radius: 50%;
}

.profile-info {
  flex: 3;
  align-self: center;
  display: flex;
}

.follow {
  flex: 1;
  margin: 10px;
  align-self: center;
}

.info {
  flex: 8;
}

button {
  background: blue;
  border: none;
  padding: 5px 10px;
  color: whitesmoke;
  width: 120px;
  border-radius: 5px;
  transition: all .3s ease-in;
}

button:active {
  outline: none;
}

button:visited {
  outline: none;
}

.unfollow {
  background: red;
  color: white;
}
</style>
</head>

@foreach($data as $data)

   <section class="profile-main-banner">

    <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="sign-main">

        <h1>Profile</h1>

      <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform. Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>

    </div>

    </div>

  </div>

</div>

</section>

<!-- end banner section -->

<!-- start profie section -->

<section class="profile-main-welcome">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="welcome-anegela">

          <h2>Welcome,{{$data->name}}</h2>
      </div>

    </div>

  </div>

    <div class="row">

      <div class="col-md-3">

      <div class="public-profile">

        <div class="images-profile">

       <img src="https://netmaxims.in/projects/powerofourvoice/public/front/images/profile-main.jpg">

      </div>

        <h3> {{$data->name}}</h3>
        <p>0 followers <span>0 following</span></p>
        <form action="{{url('front/follow')}}" method="POST">
           @csrf
     
        <button type="submit" class="btn btn-warning" name="login_id" value="{{$data->id}}">Follow<strong>



</strong></button>
</form>
     </div>

    </div>

    <div class="col-md-9">

    <div class="public-profile-edit">

    <h2>Profile</h2>
  

    <p> Join : {{Carbon\Carbon::parse($data->created_at)->format('M Y') }}</p>

    <h3>About</h3>

    <ul>

      <!-- <li>0 Like Received</li> -->

      <li>{{$newcomment}} Comment Received</li>

      <a href="{{url('front/my-post')}}" style="text"><li>{{$count}} My Post</li></a>

    </ul>
<!--<h3>Post</h3>
    <textarea id="subject" name="subject" placeholder="Share Something About Yourself...." style="height:150px;"></textarea>-->

  </div>

  </div>

  </div>

  </div>

 <script type="text/javascript">
// $('button').click(function() {
//   $(this).text(function(_, text) {
//     return text === "Follow" ? "Unfollow" : "Follow";
//   });
//   if($(this).text() == "Follow") {
//     $(this).removeClass('unfollow');
//   } else if($(this).text() == "Unfollow") {
//     $(this).addClass('unfollow');
//   }
// });
$(document).ready(function() {     


$.ajaxSetup({

    headers: {

        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

    }

});


$('.action-follow').click(function(){    

    var user_id = $(this).data('id');

    var cObj = $(this);

    var c = $(this).parent("div").find(".tl-follower").text();


    $.ajax({

       type:'POST',

       url:'/front/follow',

       data:{user_id:user_id},

       success:function(data){

          console.log(data.success);

          if(jQuery.isEmptyObject(data.success.attached)){

            cObj.find("strong").text("Follow");

            cObj.parent("div").find(".tl-follower").text(parseInt(c)-1);

          }else{

            cObj.find("strong").text("UnFollow");

            cObj.parent("div").find(".tl-follower").text(parseInt(c)+1);

          }

       }

    });

});      


}); 
  </script>
</section>

@endforeach


<!-- footer section start -->

@include('layouts.front.include.footer')

