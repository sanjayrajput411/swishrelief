@include('layouts.front.include.header')

@foreach($data as $data)

   <section class="profile-main-banner">

    <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="sign-main">

       <h1>Profile</h1>

    
    </div>

    </div>

  </div>

</div>

</section>

<!-- end banner section -->

<!-- start profie section -->

<section class="profile-main-welcome">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="welcome-anegela">

          <h2>Welcome,{{$data->name}}</h2>
      </div>

    </div>

  </div>

    <div class="row">

      <div class="col-md-3">

      <div class="public-profile">

        <div class="images-profile">

       <img src="{{url('public/front/images/profile-main.jpg')}}">

      </div>

        <h3> {{$data->name}}</h3>
        <!-- <p>0 followers <span>0 following</span></p> -->

        <em style="display: flex;"><a href="{{url('front/my-post')}}" style="text-decoration: none;">
       <button type="button" class="btn btn-warning"> My Post</button></a> 
       <!--<button type="button" class="btn btn-warning">Follow</button> -->
</em>
        
     </div>

    </div>

    <div class="col-md-9">

    <div class="public-profile-edit">

    <h2>Profile</h2>
  

    <p> Join : {{Carbon\Carbon::parse($data->created_at)->format('M Y') }}</p>

    <h3>About</h3>

    <ul>

      <!-- <li>0 Like Received</li> -->

      <li> {{$data->comment_count}} Comment Received</li>

      <li>{{$count}} Total Post</li>

    </ul>
<!--<h3>Post</h3>
    <textarea id="subject" name="subject" placeholder="Share Something About Yourself...." style="height:150px;"></textarea>-->

  </div>

  </div>

  </div>

  </div>

</section>

@endforeach


<section>
  <div class="container profile-tabs">
  

  <div class="box"></div>
  <div class="d-flex align-items-start">
  <div class="nav flex-column nav-pills me-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
    <img src="../public/front/images/profile-main.png">
    <h3 class="username">Angela zafirov</h3>
    <ul class="user-followers">
      <li>0 followers</li>
      <li>|</li>
      <li>1 following</li>
    </ul>
    <button class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-account" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true"><img src="../public/front/images/user-profile/Icon material-account-circle@2x.png">My Account</button>
    <button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-plan" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false"><img src="../public/front/images/user-profile/credit-card (6)@2x.png">Upgrade plan</button>
    <button class="nav-link" id="v-pills-messages-tab" data-bs-toggle="pill" data-bs-target="#v-pills-history" type="button" role="tab" aria-controls="v-pills-messages" aria-selected="false"><img src="../public/front/images/user-profile/wallet (3)@2x.png">Payment history</button>
    <button class="nav-link" id="v-pills-settings-tab" data-bs-toggle="pill" data-bs-target="#v-pills-prisoner" type="button" role="tab" aria-controls="v-pills-settings" aria-selected="false"><img src="../public/front/images/user-profile/photo@2x.png">Pictures for Prisoners</button>
    <button class="nav-link" id="v-pills-settings-tab" data-bs-toggle="pill" data-bs-target="#v-pills-settings" type="button" role="tab" aria-controls="v-pills-settings" aria-selected="false"><img src="../public/front/images/user-profile/Icon ionic-ios-settings@2x.png">Settings</button>
    <button class="nav-link" id="v-pills-settings-tab" data-bs-toggle="pill" data-bs-target="#v-pills-notification" type="button" role="tab" aria-controls="v-pills-settings" aria-selected="false"><img src="../public/front/images/user-profile/Icon material-notifications-active@2x.png">Notifications</button>    
  </div>
  <div class="tab-content" id="v-pills-tabContent">
    <div class="tab-pane fade show active" id="v-pills-account" role="tabpanel" aria-labelledby="v-pills-home-tab">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</div>
    <div class="tab-pane fade" id="v-pills-plan" role="tabpanel" aria-labelledby="v-pills-profile-tab">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</div>
    <div class="tab-pane fade" id="v-pills-history" role="tabpanel" aria-labelledby="v-pills-messages-tab">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</div>
    <div class="tab-pane fade" id="v-pills-prisoner" role="tabpanel" aria-labelledby="v-pills-settings-tab">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</div>
    <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</div>
    <div class="tab-pane fade" id="v-pills-notification" role="tabpanel" aria-labelledby="v-pills-settings-tab">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</div>
  </div>
</div>
  </div>
</section>


<!-- footer section start -->

@include('layouts.front.include.footer')

