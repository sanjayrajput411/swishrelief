@include('layouts.front.include.header')
@extends('layouts.app')
    <!-- end navbar -->
     <section class="main-banner">
      <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="sign-main">
          <h1>Sign Up</h1>
        <!-- <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform. Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p> -->
      </div>
      </div>
    </div>
  </div>
  </section>
  <!-- end banner section -->
  <!-- start main section  -->
  <section class="main-form">
    <div class="container">
     <div class="we-offer">
      <div class="row">
        <div class="col-md-6">
        <div class="login-member signup-member">
          <!-- <h2>Sign Up</h2> -->
          <p>Already A Member ? <a href="{{url('/login')}}" style="text-decoration:none;">Log In</a></p>
            <form method="POST" action="{{ route('register') }}">
                        @csrf
                        <div class="feedback-sign-up">
                            <label for="name" class="col-form-label">{{ __('Name') }}</label>
                                <input id="name" type="text" class="form-control  @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>
                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>

                         <div class="feedback-sign-up">
                            <label for="email" class="col-form-label">{{ __('Email Address') }}</label>
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" >

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>

                        <div class="feedback-sign-up">
                            <label for="password" class="col-form-label">{{ __('Password') }}</label>
                              <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">
                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>


                        <div class="feedback-sign-up">
                            <label for="password-confirm" class="col-form-label">{{ __('Confirm Password') }}</label>
                              <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                             </div>
                                <div class="register-button">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Sign up') }}
                                </button>
                        </div>
                    </form>
                   </div>
                   </div>
            <div class="col-md-6">
           <div class="social-reform">
          <img src="/front/images/search-mojar.png">
          <h2>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform.</h2>
          <p>Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>
     </div>
    </div>
  </div>
</div>
</div>
  </section>
  <!-- end section -->

  <!-- footer section start -->
<script>
`$validatedData = $request->validate([
        'table' => 'required|regex:/^[\pL\s]+$/u|min:3',
    ]);`
</script>
@include('layouts.front.include.footer')
