@include('layouts.front.include.header')
<!-- start banner section -->
<section class="goverment-main-banner">
  <div class="container">
    <div class="row">
    <div class="col-md-12">
      <div class="contact-heading">
        <h1>Government & Racism</h1>
        <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform. Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>
       <button type="button" class="btn btn-warning">DONATE</button>
      </div>
    </div>
  </div>
  </div>
</section>
<!-- end banner section -->
<section class="government-racism-main">
 <div class="container">
   <div class="row">
     <div class="col-md-12">
       <div class="goverment-second">
       <h2>Congresswoman Bustos Supports The Following Legislation:</h2>
       <ul>
        <li class="georgy">H.R. 7120 -George Floyd Justice in Policing Act</li>
      <p>This legislation works to address various policies regarding policing practice and law enforcement accountability. This bill also establishes a framework to prohibit racial profiling at the federal, state, and local levels and new requirements for law enforcement officers and agencies, including to report data on use-of-force incidents, to obtain training on implicit bias and racial profiling, and to wear body cameras.</p>
       <li class="emmett">H.R.35 – Emmett Till Antilynching Act</li>
       <p>This legislation, which passed the House on February 26, specifies lynching as a federal hate crime.</p>
       <li class="gerner">H.R.4408 – Eric Garner Excessive Use of Force Prevention Act of 2019</li>
       <p>This bill would make the use of chokeholds or maneuvers that restrict oxygen intake or blood flow to the brain by law enforcement unlawful under federal civil rights law.</p>
       <li class="juneteenth">H.R.7232 – Establishing Juneteenth Independence Day as a Federal holiday</li>
       <p>To amend title 5, United States Code, to establish Juneteenth Independence Day as a Federal holiday.</p>
       <li class="history">H.R.6902 – Black History is American History Act</li>
       <p>This bill authorizes the Secretary of Education to award grants to eligible entities to carry out educational programs that include the history of African-American and Black figures in the founding and growth of America, and the impact on and contributions to the development and enhancement of United States history and society.</p>
       <li class="twenty">H.R.3082 – Woman on the Twenty Act of 2019</li>
       <p>This bill would require all $20 Federal Reserve notes printed after December 31, 2022, prominently feature a portrait of Harriet Tubman on their front face.</p>
       <li class="commision">H.R.1636 – Commission on the Social Status of Black Men and Boys Act</li>
       <p>This bill would require all $20 Federal Reserve notes printed after December 31, 2022, prominently feature a portrait of Harriet Tubman on their front face.</p>
       <li class="euuity">H.R. 2574 – Equity and Inclusion Enforcement Act</li>
       <p>The legislation would hold federally funded programs, including schools, accountable for their responsibility to provide all students with equal opportunity for a quality education to combat discrimination in education.</p>
       <li class="strenght">H.R.2639 – Strength in Diversity Act of 2020</li>
       <p>The legislation would help desegregate public schools and provide support to school districts that are developing, implementing or expanding school diversity initiatives.</p>
       <li class="condemning">H. Res. 908 – Condemning all forms of anti-Asian sentiment as related to COVID-19.</li>
       <p>The resolution condemns all forms of anti-Asian sentiment related to COVID-19. The resolution recognizes and denounces the rise in anti-Asian hate crimes, which have been linked to the usage of racist terms like “Kung Flu” or “China Virus.” It also calls on federal and state authorities to document, investigate and prosecute hate crimes.</p>
       <li class="social">H.R.4004 – Social Determinants Accelerator Act of 2019</li>
       <p>The bill would create a federal grant program to empower states and local governments to tackle persistent economic and social conditions — like limited access to health care providers, stable housing, reliable transportation and healthy foods — that often hinder health outcomes and disproportionately impact communities of color and underserved communities. Through her role on the House Appropriations Committee, Congresswoman Bustos secured language for the creation of an Inter-Agency Social Determinants Council and $10 million for a new pilot program to help local governments create plans that aim to address the external, social factors that impact health</p>
       <li class="retain" >H.R.7769 – RETAIN Act</li>
       <p>This bicameral bill would would address severe nationwide shortages of early childhood and K-12 teachers that disproportionately impacts students from low-income backgrounds and students of color. Exacerbated by low pay, school leadership instability, and poor teaching conditions, schools in low-income communities struggle to retain experienced, qualified education professionals. Teacher pay has also worsened in the past 20 years, and teachers in low-income schools are more underpaid than teachers in more affluent schools.<br><br> The Retaining Educators Takes Added Investment Now (RETAIN) Act creates a fully refundable tax credit for teachers, paraprofessionals, mental health providers, and school leaders in Title I schools and educators, program providers, and program directors in head start, early head start, and Child Care & Development Block Grant (CCDBG) funded early childhood education programs. The tax credit increases as these professionals become more experienced to incentivize retention.</p>
       <li class="holiday">This bill establishes Juneteenth Independence Day as a federal holiday.</li>
       <p>This bill establishes Juneteenth Independence Day as a federal holiday.</p>
       </ul>
     </div>
   </div>
 </div>
 </div>
</section>
@include('layouts.front.include.footer')
