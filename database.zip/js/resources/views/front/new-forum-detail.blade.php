@include('layouts.front.include.header')

<!-- start banner section -->

<section class="newforum-main-banner">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="contact-heading">

          <h1>Forum Detail</h1>

        </div>

      </div>

    </div>

  </div>

</section>

<section class="newforum-detail sec1">

  <div class="container post-content">

    <h3>Over-Criminalization”: Exploring Solutions In Constitutionalism And Constitutional Morality</h3>

    <div class="edit delete">
      <button><i class="fa fa-pencil-square-o" aria-hidden="true"></i>&nbsp;Edit</button>
      <button><i class="fa fa-trash-o" aria-hidden="true"></i>&nbsp;Delete</button>
    </div>

    <hr>

    <h4>Introduction</h4>
    <p>The concepts of constitutionalism, constitutional morality, and legal moralism are intrinsically linked with the study of criminal law and are consciously employed by modern, civilised states in their exercise of criminalization of various human conducts. It is essential to briefly glance through the concepts of constitutionalism and constitutional morality to understand how they can curb the practice overzealous criminalization. Over-criminalization poses the threat of social ostracism and irreparable stigma to individuals coupled with the risk of confinement in prisons or other corrective institutions for even harmless or petty offences. A single instance of arrest can cause irreversible damage to one’s reputation. Therefore, criminalization as a tool of social control must be used sparingly and with great caution.</p>

    <h4>Constitutionalism And Constitutional Morality</h4>
    <p>The idea of constitutionalism is engrained in the basic principle of necessity to limit the unfettered exercise of power by the State. Conferment of absolute power would eventually lead to arbitrary, unreasonable restrictions on the liberties of citizens and constitutionalism thus seeks to reasonably restrict the arbitrary governmental discretion in making decisions for its people.</p> 
    
    <p>Adhering to the constitutional principles and commands is the foremost duty of not only the State but also of the people guided by the said Constitution. State functionaries must submit to the spirit and core values that inform our Constitution even in the exercise of discretionary powers. Dr. B.R. Ambedkar emphasized the need for the inclusion of administrative details and intricacies by invoking the principle of constitutional morality. The modern understanding of constitutional morality refers to the adherence to the principles which form the essence and core values of the Constitution. It is opposed to popular or mass morality in the sense that it commands disregard to the popular notions of morality subscribed by the society in the decision/ policy making process. For instance, popular morality may be opposed to homosexuality however, constitutional morality would permit it to protect the inalienable human right to sexual orientation.</p>

    <h4>Constitutionalism And Criminalization</h4>
    <p>A constitution may exist in a despotic regime but the principle of constitutionalism can certainly not exist in an arbitrary system of governance. A society in which constitutionalism informs the various institutions of the lives of citizens, the State would have to respect and uphold the innate rights and liberties of the citizens while exercising the tool of criminalization.</p>
    
    <p>We look at the following instances of criminalization to better understand the role that constitutionalism can plausibly play in preventing over-criminalization:</p>
    
    <p>The British administration stigmatised and criminalized a number of indigenous tribes and manifested their racist and casteist approach to administration. Such criminalization rendered an entire community of people vulnerable to being stripped of dignity for centuries to come. The children born in the said communities were deemed criminal and hence subjected to perpetual suspicion. There cannot be any reasonable argument which can justify stigmatization of a group of people while blatantly disregarding their individual conduct and intentions to determine their culpability and therefore such an exercise of criminalization was arbitrary.</p>



  </div>

  <div class="container comments">

    <h3 class="comments">Comments</h3>
    <hr>

    <h4>Neliyo</h4>
    <p class="content">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>
    <p class="date">March 23, 2018</p>

    <h4>Neliyo</h4>
    <p class="content">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>
    <p class="date">March 23, 2018</p>

    <h4>Neliyo</h4>
    <p class="content">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</p>
    <p class="date">March 23, 2018</p>

    <h2>Write a comment</h2>

    <textarea rows="4" placeholder="Write your comment here..."></textarea>
      

    <button>Submit</button>

    

  </div>
</section>



@include('layouts.front.include.footer')