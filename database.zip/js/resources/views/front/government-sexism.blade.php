@include('layouts.front.include.header')
<section class="goverment-seximss">
<div class="container">
<div class="row">
<div class="col-md-12">
  <div class="contact-heading">
  <h1>Government Sexism</h1>
    <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform. Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>
   <button type="button" class="btn btn-warning">DONATE</button>
  </div>
</div>
</div>
</div>
</section>
<!-- end section -->
<section class="more-information">
<div class="container">
  <div class="row">
  <div class="col-md-12">
  <div class=" goverment-second Based-sexics">
      <ul>
      <li class="discriminition">Sex-Based Discrimination</li>
    <P>Sex discrimination involves treating someone (an applicant or employee) unfavorably because of that person's
       sex, including the person's sexual orientation, gender identity, or pregnancy. Discrimination against an individual because of gender identity, including transgender status, or because of sexual orientation is discrimination because of sex in violation of Title VII. For more information about LGBTQ+-related sex discrimination claims, see <a href="https://www.eeoc.gov/sex-based-discrimination">https://www.eeoc.gov/sex-based-discrimination.</a></p>
     <p class="research-para">We offer free research on major topics like prisons, the legal system, justice system, prison reform, and social reform.</p>
    </ul>
    </div>
  </div>
 </div>
 </div>
</section>


@include('layouts.front.include.footer')