@include('layouts.front.include.header')
<style>
    .dropbtn {
  background-color: #3498DB;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
}

.dropbtn:hover, .dropbtn:focus {
  background-color: #2980B9;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  overflow: auto;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown a:hover {background-color: #ddd;}

.show {display: block;}
</style>
<section class="forum-main-banner">
  <div class="container">
    <div class="row">
    <div class="col-md-12">
      <div class="contact-heading forum-heading">
        <h1>All posts</h1>
      </div>
    </div>
  </div>
  </div>
</section>
<!-- end banner section -->
<section class="table-past-main">
<div class="container">
  <div class="row linesss" style="border-bottom: 1px solid gray;">
    <div class="col-md-8">
    <div class="newpost-blog">
     <ul>
       <li><a href="{{url('front/forum')}}">Categories</a></li>
          <li><a href="{{url('front/all-post')}}">All Posts</a></li>
          <!-- <li><a href="{{url('front/my-post')}}">My Posts</a></li> -->
      </ul>
  </div>
  </div>
  <div class="col-md-4">
  <div class="search-create-post">
    <ul>
    <li>
    <i class="fa fa-search"></i><input type="text" placeholder="Search.." name="search"></li>
    <ul>
  </div>
  </div>
  </div>
  <div class="row">
      <div class="col-md-12 text-center my-5">
          <h4 style="font-size: 3em;font-weight: bold;">Questions & Answers</h4>
          <p style="font-size: 20px;">Get answers and share knowledge.</p>
      </div>
  </div>
  <div class="row">
  <div class="col-md-12">
    <div class="mark-read" style="transform: translateY(10px);">
        <div class="right" style="float: left;display: flex;width: 50%;"><p>Questions & Answers</p> <p style="margin: 0 8px;">|</p> <p>Sort By:</p><select name="cars" id="cars" style="width: 25%;border: none;padding: 2px;transform: translateX(10px);background-color:white;">
   <option value="Recent Activity">Recent Activity</option>
  <option value="Newest">Newest</option>
  <option value="Most Comments">Most Comments</option>
  <option value="Most Views">Most Views</option>
  <option value="Most Likes">Most Likes</option>
</select></div>
      <div class="all-posts" style="display: flex;width: 35%;">
          <select name="cars" id="cars" style="width: 50%;border: 1px solid black;border-radius: 0;padding: 5px 20px;margin-right: 15px;">
 <option value="More Actions">More Actions</option>
  <option value="Unfollow Category">Unfollow Category</option>
  <option value="Marked all as read">Marked all as read</option>
</select>
     <a href="https://netmaxims.in/projects/powerofourvoice/front/create-post">
    <button type="button" name="button">Create New Post</button></a>
  </div>
</div>
  <table class="table caption-top">
  <thead>
    <tr class="main-headiing-table">
      <th></th>
      <th class="chat-box"><i class="fa fa-comment" aria-hidden="true"></i></th>
      <th class="chat-box"><i class="fa fa-eye" aria-hidden="true"></i></th>
      <th class="chat-box"><i class="fa fa-heart" aria-hidden="true"></i></th>
       <th class="recent">Recent actives</th>
    </tr>

  </thead>
  <tbody>
   @foreach($data as $data)
   @if($data->category_name == 'Questions & Answers')
    <tr class="all-class-same">
     <td class="example"><a href ="{{url('front/title/'.$data->id)}}" style="color: inherit;
text-decoration: inherit;">{{$data->post_name}}</a>  <br> <a href="{{ url('front/profile/' . $data->user_id)  }}"><i class="fa fa-user-circle" aria-hidden="true"></a></i><span style="font-size:18px;margin-left: 7px;">{{$data->name}}</span></td>
      <td class="take-communtity">0</td>
      <td class="take-communtity">0</td>
      <td class="take-communtity">0</td>
      <td class="take-july">jul 28</td>
      <td><i class="fa fa-ellipsis-v" aria-hidden="true"></i></td>
    </tr>
  @else  
@endif
     @endforeach
  </tbody>
</table>
</div>
</div>
</div>
</section>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>
@include('layouts.front.include.footer')
