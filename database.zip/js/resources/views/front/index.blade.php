@include('layouts.front.include.header')

<!-- start banner section -->
<section class="home-main-banner">
  <div class="container">
    <div class="row">
    <div class="col-md-7">
      <div class="home-heading">
        <h6>INTRODUCING</h6>
        <h1>Power of Our Voices LLC</h1>
        <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform. Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>
       <button type="button" class="btn btn-warning">DONATE</button>
      </div>
    </div>
  </div>
  </div>
</section>
<!-- end banner section -->
<section class="book-appointment">
<div class="container-fluid">
<div class="row no-gutter">
  <div class="col-md-4">
    <div class="join-our-team">
        <div class="blance-our">
        <p><img src="{{asset('front/images/phone-banner.png')}}">(231) 598-8498</p>
    </div>
  </div>
   </div>
    <div class="col-md-4">
      <div class="join-our-one">
      <div class="blance-our">
      <p> <img src="{{asset('front/images/balance-banner.png')}}">Join Our Team</p>
      </div>
     </div>
   </div>
      <div class="col-md-4">
        <div class="join-our-two">
      <div class="blance-our">
      <p><img src="{{asset('front/images/book-appoinment.png')}}">Book An Appointment</p>
        </div>
      </div>
    </div>
    </div>
  </div>
</section>
<!-- end section -->
<section class="your-gifts">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
      <div class="will-changes">
        <h2>ABOUT US</h2>
        <h3>Your Gifts Will Change Prisoners’ Lives!</h3>
        <p>Life doesn’t become simpler for people who go to jail. Families are strained and restricted when it comes to visitation and some families choose to disappear from the lives of their inmate all together.Supporting a prisoner shines a hope into a world of darkness and despair. <br> Donations help prisoners go through The Prisoner's Journey, a program that introduces them to the light and hope of changing them, and prisons, from the inside out.</p>
          <button type="button" class="btn btn-warning">CONTACT US</button>
      </div>
    </div>
    <div class="col-md-6">
      <div class="picture-prisoners">
        <img src="{{asset('front/images/diverse-group.png')}}">
  </div>
  </div>
   </section>
<!-- end section -->
<section class="the-full-store">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="what-we-do">
          <h2>WHAT WE DO</h2>
          <h3>The Full Story</h3>
          <p>​Welcome to Power of Our Voice LLC, a home for people without <br> distinction or separation. We as a community have reached out to those who have experienced the other side of our justice system. The ones that are often prohibited from voting, holding office, or otherwise being heard. They are prisoners who are trying to repay their debt to society and to get back. These individuals, the sometimes forgotten citizens, have spent their time researching and studying to provide the most vital information they could, all the while studying their own personal academics. They do so, so that they can help the people as a whole. They are considered part of the power of our voice's community. We all understand that there's a difference between what should be and what is. Together we hope that we can make change happen, first we must know the truth.</p>
        <button type="button" class="btn btn-warning">MORE INFORMATION</button>
      </div>
    </div>
  </div>
</section>
<!-- end section -->
<!-- <section class="choose-your-plan">
  <div class="container">
    <div class="plans">
      <p>PLANS</p>
      <h2>Choose Your Pricing Plan</h2>
    </div>
    <div class="row">
    <div class="col-md-4">
    <div class="have-any">
    <h2>Have Any Questions?</h2>
    <p>We work with a wide variety of groups an individuals to promote prison reform. We look forward to hearing from you!</p>
    <a href="https://netmaxims.in/projects/powerofourvoice/front/contact-us"><button type="button" class="btn btn-warning">Contact Us</button></a>
  </div>
  </div>
  @if(Auth::User())
<div class="col-md-4">
<div class="bronze-plan">
  <h2>Bronze Plan</h2>
  <h3>$0.00</h3>
   <span>Free Plan</span>
    <p>Perfect for those who want to know the truth behind bars</p>
    <ul>
     <i class="fa fa-check"></i>
      <li>Unlimited access to Prisoners' Corner blogs</li>
    <i class="fa fa-check"></i>
    <li>Unlimited forum access</li>
     <i class="fa fa-check"></i>
    <li>Unlimited access to prisoner re-entry resources</li>
  </ul>
  @if(Auth::User())
  @else
  <a href="{{url('front/sign-up')}}" style="text-decoration:none;"><button type="button" class="btn btn-warning">Select</button></a>
  @endif
</div>
</div>
<div class="col-md-4">
<div class="sliver-plan">
  <h2>Silver Plan</h2>
  <h3>$6.95</h3>
<span>Paid Plan</span>
<p>Government officials who found themselves on the wrong side</p>
    <ul>
 <i class="fa fa-check"></i>
  <li>Compromised judges</li>
  <i class="fa fa-check"></i>
  <li>Compromised congress</li>
  </ul>
  @if(Auth::User())
  @else
  <a href="{{url('front/sign-up')}}" style="text-decoration:none;"><button type="button" class="btn btn-warning">Select</button></a>
  @endif
</div>
</div>
</div>
</div>
</section> -->
<section class="choose-your-plan services-mains">
  <div class="container">
    <div class="plans">
      <p>PLANS</p>
      <h2>Choose Your Pricing Plan</h2>
    </div>
    <div class="row">
    <div class="col-md-4">
    <div class="have-any">
    <h2>Have Any Questions?</h2>
    <p>We work with a wide variety of groups an individuals to promote prison reform. We look forward to hearing from you!</p>
      <button type="button" class="btn btn-warning">Contact Us</button>
  </div>
  </div>
@if(Auth::User())
<div class="col-md-4">
<div class="bronze-plan">
  <h2>Bronze Plan</h2>
  <h3>$0.00</h3>
   <span>Free Plan</span>
    <p>Perfect for those who want to know the truth behind bars</p>
    <ul>
     <i class="fa fa-check"></i>
      <li>Unlimited access to Prisoners' Corner blogs</li>
    <i class="fa fa-check"></i>
    <li>Unlimited forum access</li>
     <i class="fa fa-check"></i>
    <li>Unlimited access to prisoner re-entry resources</li>
  </ul>
  <a  style="text-decoration:none;"><button type="button" class="btn btn-warning">Activated</button></a>
</div>
</div>
@else
<div class="col-md-4">
<div class="bronze-plan">
  <h2>Bronze Plan</h2>
  <h3>$0.00</h3>
   <span>Free Plan</span>
    <p>Perfect for those who want to know the truth behind bars</p>
    <ul>
     <i class="fa fa-check"></i>
      <li>Unlimited access to Prisoners' Corner blogs</li>
    <i class="fa fa-check"></i>
    <li>Unlimited forum access</li>
     <i class="fa fa-check"></i>
    <li>Unlimited access to prisoner re-entry resources</li>
  </ul>
  @if(Auth::User())
  @else
  <a href="{{url('front/sign-up')}}" style="text-decoration:none;"><button type="button" class="btn btn-warning">Select</button></a>
  @endif
</div>
</div>
@endif
@if(Auth::User())
<div class="col-md-4">
<div class="sliver-plan">
  <h2>Silver Plan</h2>
  <h3>$6.95</h3>
<span>Paid Plan</span>
<p>Government officials who found themselves on the wrong side</p>
    <ul>
 <i class="fa fa-check"></i>
  <li>Compromised judges</li>
  <i class="fa fa-check"></i>
  <li>Compromised congress</li>
  </ul>
  <a href="{{url('front/billing-details')}}" style="text-decoration:none;"><button type="button" class="btn btn-warning">Upgrade</button></a>
</div>
</div>
@else
<div class="col-md-4">
<div class="sliver-plan">
  <h2>Silver Plan</h2>
  <h3>$6.95</h3>
<span>Paid Plan</span>
<p>Government officials who found themselves on the wrong side</p>
    <ul>
 <i class="fa fa-check"></i>
  <li>Compromised judges</li>
  <i class="fa fa-check"></i>
  <li>Compromised congress</li>
  </ul>
  @if(Auth::User())
  @else
  <a href="{{url('front/sign-up')}}" style="text-decoration:none;"><button type="button" class="btn btn-warning">Select</button></a>
  @endif
</div>
</div>
@endif
</div>
</div>
</section>
<!-- end section -->
<section class="research-services">
<div class="container">
<div class="row">
  <div class="col-md-6">
  <div class="we-provider">
  <img src="{{asset('/front/images/Rectangle -4.png')}}">
</div>
</div>
<div class="col-md-6 ">
<div class="we-provider-image">
  <h2>Research Services</h2>
  <img src="{{asset('/front/images/search-icon-services.png')}}">
  <p>We provide research services at $25/hr but offer discounted rates.</p>
  <button type="button" class="btn btn-warning">$25/hr</button>
</div>
</div>
@endif
</div>
</div>
</section>
<!-- end section -->
<section class="picture-shipped">
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <div class="picture">
        <p>PICTURES</p>
      <h2>Pictures For Prisoners</h2>
</div>
</div>
</div>
<div class="row">
  <div class="col-md-6">
    <div class="we-believe">
      <img src="/front/images/comma-paragrpah.png">
      <p>We believe that no life is beyond the reach of God's power, and we envision a future in which countless prisoners, ex-prisoners, and their families are redeemed, restored, and reconciled. We provide a service for pictures for prisoners. We charge 60 cents $0.60 per picture and shipped to the prisoner every set of 10.</p>
      <button type="button" class="btn btn-warning">$0.60</button>
   </div>
   </div>
   <div class="col-md-6">
  <div class="we-believes">
    <img src="/front/images/home-hover-image.png">
</div>
</div>
</div>
</div>
</section>
<!-- end section -->
<!-- start section blog -->
<section class="blog-main">
<div class="container">
  <div class="row">
    <div class="col-md-12">
    <div class="bolg-heading">
    <p>OUR BLOG</p>
    <h2>Latest Blog Post</h2>
  </div>
  </div>
  <div class="row">
  <div class="col-md-4">
    <div class="hello-you">
  <img src="/front/images/hello-dug-blog.png">
</div>
</div>
<div class="col-md-4">
  <div class="hello-you">
<img src="/front/images/blog-back.png">
</div>
</div>
<div class="col-md-4">
  <div class="hello-you">
    <img src="/front/images/called-blog.png">
</div>
</div>
</div>
</div>
</section>
<!-- end blog section -->
@include('layouts.front.include.footer')
