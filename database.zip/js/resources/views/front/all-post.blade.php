@include('layouts.front.include.header')

<html lang="en">

  <head>

    <title> Post Listing </title>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Bootstrap CSS -->

    <!-- <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> -->

    <style>

        table td p {

            word-break: break-all;

        }

    </style>

  </head>

<section class="forum-main-banner">

  <div class="container">

    <div class="row">

    <div class="col-md-12">

      <div class="contact-heading forum-heading">

        <h1>All posts</h1>

      </div>

    </div>

  </div>

  </div>

</section>

<!-- end banner section -->

<section class="table-past-main">

<div class="container">

  <div class="row linesss sdbs">

    <div class="col-md-12">

    <div class="newpost-blog sdbs" style="

    float: left;">

      <ul>

       <li>
       <select id="dropDown">
        <option value="Category">--Select Category--</option>
       @foreach ($data as $row)
 
       <option value="{{url('front/category/'.$row->id)}}"><p>{{$row->category_name}}</p></option>
       @endforeach
        </select>
      </li>

          <li><a href="{{url('front/all-post')}}">All Posts</a></li>

          @if(Auth::User())

          <li><a href="{{url('front/my-post')}}">My Posts</a></li>

          @endif

      </ul>

  </div>

  <div class="all-posts">

     <a href="{{url('front/create-post')}}">

    <button type="button" name="button">Create New Post</button></a>

  </div>

  </div>

  <!--<div class="col-md-4">

  <div class="search-create-post">

    <ul>

    <li>

    <i class="fa fa-search"></i><input type="text" placeholder="Search.." name="search"></li>

    <ul>

  </div>

  </div>-->

  </div>

  <div class="row sdbs allposts-table">

  <div class="col-md-12">



  <div class="container mt-4">

        <div class="row">

            @if(Session::has('success'))

                        <div class="alert alert-success alert-dismissible">

                            <button type="button" class="close" data-dismiss="alert">×</button>

                            {{ Session::get('success') }}

                        </div>

                    @elseif(Session::has('failed'))

                        <div class="alert alert-danger alert-dismissible">

                            <button type="button" class="close" data-dismiss="alert">×</button>

                            {{ Session::get('failed') }}

                        </div>

                    @endif

        </div>



        @if(count($posts) > 0)

          <div class="table-responsive mt-4 sdbs allpost">

            <table class="table ">

                <thead>

                    <tr>

                        <th style="width:30%;"> Title </th>

                        <th> Category Name </th>

                        <th> Decription </th>

                        <!-- <th>Action</th> -->

                    </tr>

                </thead>

                <tbody>

                    @foreach($posts as $post)



                        <tr>

                            <td><a class="titllee" href="{{url('front/title/'.$post->id)}}" style="color: inherit;
text-decoration: inherit;"> {{ $post->post_name }} </a></td>

                            <th>{{ $post->cat_names }}</th>

                            <td> {!! html_entity_decode($post->description) !!} </td>

                            <td>
                          
                            <!-- <div>
                         
                            <a href="{{url('front/editpostforum',$post->id)}}"> <button type="button" class="btn btn-default edit-student-btn" data-student-id="@cl.StudentID"><i class="fa fa-pencil-square-o" aria-hidden="true"></i>



</button></a>

<a href="{{url('front/delete-forumpost',$post->id)}}"><button type="button" class="btn btn-default"><i class="fa fa-trash"></i></button></a>

                    </div> -->
           
    </td>

                        </tr>

                    @endforeach

                </tbody>

            </table>

          </div>



          {{ $posts->links() }}

        @else

       <P style="text-align:centre;"> No data Found</p>

        @endif

      </div>



</div>

</div>

</div>

</section>  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    <script>
  var dropDownValue = document.getElementById("dropDown");

dropDownValue.onchange = function() {
  if (this.selectedIndex !== 0) {
    window.location.href = this.value;
  }
};
</script>

@include('layouts.front.include.footer')

