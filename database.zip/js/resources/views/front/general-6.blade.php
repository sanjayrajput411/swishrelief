@include('layouts.front.include.header')
<!-- start banner section -->
<section class="justics-system-banner">
<div class="container">
<div class="row">
<div class="col-md-12">
  <div class="contact-heading criminal-second">
  <h1>Criminal Justice System</h1>
  <p>Although legally we are a business entity, we are also a collective community that works for the social justice, reform, human dignity, and equality for everyone, including the poor, desolate, and those who've felt like outcasts to society.We understand that each and every person is unique with differing economics, intellects, and backgrounds. So, we focus on everyone's joys, sorrows, happiness, hurt, grief, struggles, backgrounds, accomplishments, hurdles, triumphs, and defeats. We recognize many are discriminated against, assaulted, degraded, abused, exploited, and even killed because of their race, gender, status, economics, demographics, or beliefs. There are no sides: we stand for the belief that what is right is right, and what is wrong is wrong. We do not believe in white pride, black pride, or brown pride, as that causes division. We do not fight for terrain with other organizations, for that shall cause us to lose focus on our goals and become victims of the broken system. There is no power control, there is all of us working together in unison. We have no room for pride; pride causes division, which we do not want. In order to succeed, we must stand together on the truth,leave all bias at the door, and not remain silent to any injustice.</p>
  <button type="button" class="btn btn-warning">DONATE</button>
</div>
</div>
</div>
</div>
</section>
<!-- end banner section -->





<section class="tabing-main-role">
  <div class="container">
    <!-------------- Benefits section for mobile version Start -------------->

  <div class="row desktop-hide">
    <div class="accordion " id="accordionExample">
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingOne">
        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        The Federal Court System
        </button>
      </h2>
      <div id="collapseOne" class="accordion-collapse collapse " aria-labelledby="headingOne" data-bs-parent="#accordionExample">
        <div class="accordion-body">
            <img src="../public/front/images/confident-professional-adult.png" alt="">
        <h2>  The Federal Court System</h2>
      <p>There are three main levels to the Federal Court System: district courts (the trial court), circuit courts and the Supreme Court of the United States. There are 94 district courts, 13 circuit courts, and one Supreme Court in the United States Federal system.</p>

     <p>Courts in the federal system work differently in many ways than state courts. The primary difference for civil cases is the types of cases that can be heard in the federal system. Federal courts are courts of limited jurisdiction, meaning they can only hear cases authorized by the United States Constitution or federal statutes. The federal district court is the starting point for any case arising under federal statutes, the Constitution, or treaties. This type of jurisdiction is called “original jurisdiction."</p>

    <p>Federal judges as well as Supreme Court “justices” are selected by the President and confirmed “with the advice and consent” of the Senate and “shall hold their Offices during good Behavior.” Judges hold their position for the rest of their lives, but many resign or retire earlier. They may be removed by impeachment by the House of Representatives and conviction by the Senate. Throughout history, fifteen federal judges have been impeached due to alleged wrongdoing. There is one        exception to the lifetime appointment and that is for magistrate judges, which are selected by district judges and serve a specified term.</p>
        </div>
      </div>
    </div>
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingTwo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          Role of the District Court
        </button>
      </h2>
      <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
        <div class="accordion-body">
            <img src="../public/front/images/confident-professional-adult.png" alt="">
        <h2>  Role of the District Court</h2>
     <p>District courts are "trial" courts, meaning that district court judges have the authority to try or hear cases. The United States Supreme Court and the circuit courts are appellate courts, meaning that they have the authority to hear appeals of decisions by trial court judges. District court judges can conduct jury trials in criminal or civil proceedings.</p>
        </div>
      </div>
    </div>
    <div class="accordion-item">
      <h2 class="accordion-header" id="headingThree">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
        The Federal Court System
        </button>
      </h2>
      <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
        <div class="accordion-body">
            <img src="../public/front/images/confident-professional-adult.png" alt="">
          <h2>The United States Courts of appeal</h2>
       <p>The United States courts of appeals or circuit courts are the intermediate appellate courts of the United States federal judiciary. The appellate courts are divided into 13 circuits, and each hears appeals from the district courts within its borders, or in some instances from other designated federal courts and administrative agencies. Appeals from the circuit courts are taken to the Supreme Court of the United States. The district, appellate, and Supreme courts are all authorized under Article Three of the United States Constitution. The United States courts of appeals are considered the most powerful and influential courts in the United States after the Supreme Court, because of their ability to set legal precedent in regions that cover millions of Americans. This is even more so, because the Supreme Court chooses to review less than 3% of the 7,000 to 8,000 cases filed with it annually, the U.S. courts of appeals serve as the final arbiter on most federal cases.</p>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- close -->

    <!-- Benefits section for mobile version End -->

  <div class="row">
    <div class="col-md-12 angular-tabs-mobile-hide">
        <div class="benifits_tabs angular">
            <div class="tab">
                <h3><button class="tablinks" onclick="openCity(event, 'Independency')" id="defaultOpen">The Federal Court System</button></h3>
                <h3><button class="tablinks" onclick="openCity(event, 'Exceptional')">Role of the District Court</button></h3>
                <h3><button class="tablinks" onclick="openCity(event, 'SEO_Friendly')">The Federal Court System</button></h3>
            </div>
            <div id="Independency" class="tabcontent">
                <div class="angular_platform">
                    <div class="angular_desc">
                  <img src="../public/front/images/confident-professional-adult.png" alt="">
                <h3>The Federal Court System</h3>
                <p>There are three main levels to the Federal Court System: district courts (the trial court), circuit courts and the Supreme Court of the United States. There are 94 district courts, 13 circuit courts, and one Supreme Court in the United States Federal system.  </p>
                <p>Courts in the federal system work differently in many ways than state courts. The primary difference for civil cases is the types of cases that can be heard in the federal system. Federal courts are courts of limited jurisdiction, meaning they can only hear cases authorized by the United States Constitution or federal statutes. The federal district court is the starting point for any case arising under federal statutes, the Constitution, or treaties. This type of jurisdiction is called “original jurisdiction."</p>
                <p> Federal judges as well as Supreme Court “justices” are selected by the President and confirmed “with the advice and consent” of the Senate and “shall hold their Offices during good Behavior.” Judges hold their position for the rest of their lives, but many resign or retire earlier. They may be removed by impeachment by the House of Representatives and conviction by the Senate. Throughout history, fifteen federal judges have been impeached due to alleged wrongdoing. There is one exception to the lifetime appointment and that is for magistrate judges, which are selected by district judges and serve a specified term.</p>
            </div>
        </div>
            </div>
            <div id="Exceptional" class="tabcontent">
                <div class="angular_platform">
                    <div class="angular_desc">
                    <img src="../public/front/images/confident-professional-adult.png" alt="">
                <h3>Role of the District Court</h3>
                <p>District courts are "trial" courts, meaning that district court judges have the authority to try or hear cases. The United States Supreme Court and the circuit courts are appellate courts, meaning that they have the authority to hear appeals of decisions by trial court judges. District court judges can conduct jury trials in criminal or civil proceedings.</p>
            </div>
        </div>
        </div>
            <div id="SEO_Friendly" class="tabcontent">
                <div class="angular_platform">
                    <div class="angular_desc">
                  <img src="../public/front/images/confident-professional-adult.png" alt="">
                <h3>The United States Courts of appeal</h3>
                <p>The United States courts of appeals or circuit courts are the intermediate appellate courts of the United States federal judiciary. The appellate courts are divided into 13 circuits, and each hears appeals from the district courts within its borders, or in some instances from other designated federal courts and administrative agencies. Appeals from the circuit courts are taken to the Supreme Court of the United States. The district, appellate, and Supreme courts are all authorized under Article Three of the United States Constitution. The United States courts of appeals are considered the most powerful and influential courts in the United States after the Supreme Court, because of their ability to set legal precedent in regions that cover millions of Americans.  This is even more so, because the Supreme Court chooses to review less than 3% of the 7,000 to 8,000 cases filed with it annually, the U.S. courts of appeals serve as the final arbiter on most federal cases. </p>
            </div>
        </div>
        </div>
        </div>
    </div>
  </div>
</div>
</section>


<script>
       function openCity(evt, cityName) {
           var i, tabcontent, tablinks;
           tabcontent = document.getElementsByClassName("tabcontent");
           for (i = 0; i < tabcontent.length; i++) {
               tabcontent[i].style.display = "none";
           }
           tablinks = document.getElementsByClassName("tablinks");
           for (i = 0; i < tablinks.length; i++) {
               tablinks[i].className = tablinks[i].className.replace(" active", "");
           }
           document.getElementById(cityName).style.display = "block";
           evt.currentTarget.className += " active";
       }
       // Get the element with id="defaultOpen" and click on it
       document.getElementById("defaultOpen").click();
   </script>
@include('layouts.front.include.footer')
