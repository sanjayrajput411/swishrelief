@include('layouts.front.include.header')

<!-- banner section start -->

<section class="national-inmat">

    <div class="container">

        <div class="row">

            <div class="col-md-12">

                <div class="banner-heading-select">

                    <h1>Personal Detail</h1>

                </div>

            </div>

        </div>

    </div>

</section>

<!-- end section -->

<section class="form-billing-and-summary">
@if(Session::has('Success_msg'))
<p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('Success_msg') }}</p>
@endif
    <div class="container">

      <div class="row">

            <div class="col-md-7">

              <h2 class="details-heading">Personal Detail</h2>

                <div class="billing-details-main">
               
             
                <form action="{{url('front/add-package-order')}}" method="POST">
                 @csrf
              
                        <div class="half-width">

                            <input type="text" class="phone-email" name="name" placeholder="First Name" value="">

                        </div>

                        <div class="half-width">

                            <input type="text" class="phone-email" name="last_name" placeholder="Last Name" value="" required>

                        </div>



                        <div class="half-width">

                            <input type="text" class="frist-name" name="company_name" placeholder="Mobile No." value="">

                        </div>

                        <div class="half-width">

                          <select id="country" name="country" value="" required>

                          <option value="" >Country</option>

                          <option value="Guyana">Guyana</option>

                          <option value="Haiti">Haiti</option>

                          <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>

                          <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>

                          <option value="Honduras">Honduras</option>

                          <option value="Hong Kong">Hong Kong</option>

                          <option value="Hungary">Hungary</option>

                          <option value="Iceland">Iceland</option>

                          <option value="India">India</option>

                          <option value="Indonesia">Indonesia</option>

                          <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>

                          <option value="Iraq">Iraq</option>

                          <option value="Ireland">Ireland</option>

                          <option value="Isle of Man">Isle of Man</option>

                          </select>

                          </div>

                         <div class="half-width"  style="margin-left: 16px;">

                          <select id="country" name="state" value="" required>

                          <option value="">State</option>

                          <option value="Guyana">Guyana</option>

                          <option value="Haiti">Haiti</option>

                          <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>

                          <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>

                          <option value="Honduras">Honduras</option>

                          <option value="Hong Kong">Hong Kong</option>

                          <option value="Hungary">Hungary</option>

                          <option value="Iceland">Iceland</option>

                          <option value="India">India</option>

                          <option value="Indonesia">Indonesia</option>

                          <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>

                          <option value="Iraq">Iraq</option>

                          <option value="Ireland">Ireland</option>

                          <option value="Isle of Man">Isle of Man</option>

                          </select>

                          </div>

                          <div class="half-width" style="margin-top: -83px;margin-left: 309px;">

                              <input type="text" class="phone-email" name="city" placeholder="City" value="" required>

                          </div>

                </div>

            </div>
          
            <div class="col-md-5">

              <h2 class="details-heading">Order Summary</h2>

                <div class="order-summary">

                  <ul>

                    <li><p class="title" name="package_name">Package Name</p>   <input type="text" id="package_name" class="phone-email" name="package_name" Value="Platinum" placeholder="package name"></li>

                    <li><p class="title" name="package_price">Package Price</p> <input type="text" id="package_name" class="phone-email" name="package_price" placeholder="package price" Value="$ 20"></li>

                  </ul>


                  <ul class="packeges">

                       <li><p class="title" name="total">TOTAL</p> <input type="text" id="package_name" class="phone-email" name="total"  Value="$ 20"></li>

                     </ul>
                   
                    <input type="submit" value="Continue Purchase"></a>
                   
               
                </form>

                </div>

            </div>

      </div>

    </div>
   
</section>









@include('layouts.front.include.footer')

