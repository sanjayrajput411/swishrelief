@include('layouts.front.include.header')

  <!-- end navbar -->

   <section class="main-banner">

    <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="sign-main">

        <h1>Sign Up</h1>

      <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform. Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>

    </div>

    </div>

  </div>

</div>

</section>

<!-- end banner section -->

<!-- start main section  -->

<section class="main-form">

  <div class="container">

   <div class="we-offer">

    <div class="row">

      <div class="col-md-6">

      <div class="sign-by-power">

        <h2>Sign Up</h2>

        <p>Already A Member ? <a href="{{url('/login')}}" style="text-decoration:none;">Log In</a></p>

        <a class="" href="{{ url('auth/facebook') }}"  id="btn-fblogin">
          <button type="button" class="btn btn-warning">
            <img src="/front/images/Icon awesome-sign.png">Sign up with facebook</button>
         </a>

         <!---- <a class="" href="{{ url('auth/google') }}"  id="btn-googlelogin">
            <button type="button" class="btn btn-warning"><img src="/front/images/google-sign.png"> Sign up with Google</button>
	    </a>   ---> 

		<a class="" href="{{ route('google.login') }}"  id="btn-googlelogin">
            <button type="button" class="btn btn-warning"><img src="/front/images/google-sign.png"> Sign up with Google</button>
	    </a>

            <h6>-Or-</h6>

            <div class="sign-with-email">

            <a href="{{url('/front/sign-up')}}"><button type="button" class="btn btn-warning"> Sign up with Email</button></a>

         </div>

       </div>

       <div class="checkboxx email-bottom">

        <input type="checkbox" name="vehicle1" value="Bike">

       <label>Sign up to this site with a public profile. <a href=""> Read more</a> </label>

      </div>

        </div>

        <div class="col-md-6">

         <div class="social-reform">

        <img src="/front/images/search-mojar.png">

        <h2>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform.</h2>

        <p>Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>

   </div>

  </div>

</div>

</div>

</div>

</section>

<!-- end section -->



<!-- footer section start -->



@include('layouts.front.include.footer')

