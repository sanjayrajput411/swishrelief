@include('layouts.front.include.header')
<section class="hood-suburbs">
<div class="container">
<div class="row">
<div class="col-md-4">
  <div class="hood-bottom">
    <h1>Hood</h1>
</div>
</div>
<div class="col-md-4">
  <div class="vs-centers">
  <h1>vs</h1>
</div>
</div>
<div class="col-md-4">
<div class="suburbs-end">
  <h1>Suburbs</h1>
</div>
</div>
</div>
</div>
</section>
<!-- end section -->
<section class="more-information-hood">
<div class="container">
  <div class="row">
  <div class="col-md-8">
  <div class="proformance">
    <ul>
      <li>Hood Vs Suburbs</li>
      <p>Federal data shows that there is a gap between education spending in the nation’s poorest and most affluent school districts, and in 23 states, richer school districts get more funding than the poor districts.</p>
      <p>Nationwide, an average of 15 percent less per pupil is spent in the poorest school district than in the most affluent, according to the Washington Post. </p>
      <p>Students in high poverty schools have less experienced instructors, less access to high level science, math, and advanced placement courses, and lower levels of state and local spending on instructors and instructional materials. The average teacher salary in high poverty schools was about $46,000 in the 2013-2014 school year compared to over $57,000 in low poverty schools. The students are the ones who feel the impact of these disparities, and the consequences are worse outcomes when it comes to attendance, school performance, and graduation rates. Only about one third of high poverty schools were fully accredited by the state.</p>
    </ul>
  </div>
 </div>
 <div class="col-md-4">
  <div class="hdbs">
    <img src="{{asset('front/images/nation-bulding.png')}}">
  </div>
 </div>
 <div class="col-md-12">
   <div class="graph">
   <img src="{{asset('front/images/graph-up.png')}}">
 </div>
 </div>
</div>
</div>
</section>


@include('layouts.front.include.footer')