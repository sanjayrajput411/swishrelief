@include('layouts.front.include.header')

<!-- end navbar -->

<section class="stateentry-banner">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="contact-heading">

          <h1>State Re-Entry</h1>

          <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform. Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>

          <button type="button" class="btn btn-warning">DONATE</button>

        </div>

      </div>

    </div>

  </div>

</section>

<!-- end banner section -->

<section class="main-pdf-entry">

  <div class="container">

    <div class="row">

      <div class="search-bar">

        <button class="search-btn"><i class="fa fa-search" aria-hidden="true"></i></button>

        <input class="search-input" type="text" placeholder="Let's find what you are looking for...">

      </div>

    </div>

    <div class="row">

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/CALIFORNIA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

              <img src="{{ asset('front/images/Object-pdf.png') }}"></img>

            </div>

            <div class="justics-heading">

              <p>CALIFORNIA</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/COLORADO.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

              <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>COLORADO</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/CONNECTICUT.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>CONNECTICUT</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/DELAWARE.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>DELAWARE</p>

            </div>

          </div>

        </a>

      </div>

    </div>

    <div class="row">

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/DISTRICT OF COLUMBIA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>COLUMBIA</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/FLORIDA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>FLORIDA</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/GEORGIA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>GEORGIA</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/HAWAII.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>HAWAII</p>

            </div>

          </div>

        </a>

      </div>

    </div>

    <div class="row">

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/IDAHO.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>IDAHO</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/ILLINOIS.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>ILLINOIS</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/INDIANA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>INDIANA</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/IOWA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>IOWA</p>

            </div>

          </div>

        </a>

      </div>

    </div>

    <div class="row">

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/KANSAS.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>KANSAS</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/KENTUCKY.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>KENTUCKY</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/MAINE.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>MAINE</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/MARYLAND.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>MARYLAND</p>

            </div>

          </div>

        </a>

      </div>

    </div>

    <div class="row">

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/MASSACHUSETTS.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>MASSACHUSETTS</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/MICHIGAN.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>MICHIGAN</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/MINNESOTA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>MINNESOTA</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/MISSISSIPPI.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>MISSISSIPPI</p>

            </div>

          </div>

        </a>

      </div>

    </div>

    <div class="row">

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/MISSOURI.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>MISSOURI</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/MONTANA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>MONTANA</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/NATIONWIDE.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>NATIONWIDE</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/NEBRASKA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>NEBRASKA</p>

            </div>

          </div>

        </a>

      </div>

    </div>

    <div class="row">

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/NEW HAMPSHIRE.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>NEW-HAMPSHIRE</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/NEW JERSEY.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>NEW-JERSEY</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/NEW MEXICO.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>NEW-MEXICO</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/NEW YORK.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>NEW-YORK</p>

            </div>

          </div>

        </a>

      </div>

    </div>

    <div class="row">

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/NORTH CAROLINA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>NORTH-CAROLINA</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/NORTH DAKOTA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>NORTH-DAKOTA</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/OHIO.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>OHIO</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/OKLAHOMA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>OKLAHOMA</p>

            </div>

          </div>

        </a>

      </div>

    </div>

    <div class="row">

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/OREGON.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>OREGON</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/PENNSYLVANIA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>PENNSYLVANIA</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/RHODE ISLAND.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>RHODE-ISLAND</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/SOUTH CAROLINA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>SOUTH-CAROLINA</p>

            </div>

          </div>

        </a>

      </div>

    </div>

    <div class="row">

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/SOUTH DAKOTA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>SOUTH-DAKOTA</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/TENNESSEE.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>TENNESSEE</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/TEXAS.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>TEXAS</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/UTAH.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>UTAH</p>

            </div>

          </div>

        </a>

      </div>

    </div>

    <div class="row">

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/VERMONT.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>VERMONT</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/VIRGINIA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>VIRGINIA</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/WEST VIRGINA.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>WEST-VIRGINA</p>

            </div>

          </div>

        </a>

      </div>

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/WISCONSIN.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>WISCONSIN</p>

            </div>

          </div>

        </a>

      </div>

    </div>

    <div class="row">

      <div class="col-md-3">

        <a href="{{ asset('front/re_entry_pdf/WYOMING.pdf') }}" target="_blank">

          <div class="justice-system-main">

            <div class="justice-system">

             <img src="{{ asset('front/images/Object-pdf.png') }}">

            </div>

            <div class="justics-heading">

              <p>WYOMING</p>

            </div>

          </div>

        </a>

      </div>

    

    </div>



  </div>



</section>

<!-- end section -->



<!-- footer section start -->



@include('layouts.front.include.footer')