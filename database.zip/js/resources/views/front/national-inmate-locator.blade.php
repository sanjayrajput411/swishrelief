@include('layouts.front.include.header')



<!-- banner section start -->

<section class="national-inmat">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="banner-heading-select">

          <h1>National Inmate Locator</h1>

        </div>

      </div>

    </div>

  </div>

</section>

<!-- end section -->

<section>

  <div class="container">

    <div class="row">

      <div class="col-md-4">

        <div class="state_changes" style="margin-top: 20px;">

          <select class="national_inmate_change">

            <option value="">--Select Category--</option>
            @foreach($cate as $cates)

            <option value="{{$cates->cate_name}}">{{$cates->cate_name}}</option>
            @endforeach
          </select>

        </div>

      </div>


    </div>

    <div class="nil-content" id="demo">
    
      @foreach($data as $row)
      <h4 class='x'>{{$row->Title_of_Educational_Resource}}</h4>
      <p class="xx">{{$row->author}}</p>
      <a href="{{$row->link}}" class="link">{{$row->link}}</a>
      <p class="description">{{$row->brief_description}}</p>
      @endforeach
   
    </div>
  </div>

</section>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
  $(function() {
    $("select").change(function() {
      var cat_name = $(this).val();
      $.ajax({
        data: {
          category_name: cat_name
        },
        url: "{{ url('front/showcategory') }}",
 
        success: function(data) {
          $('#demo').html(data);
          
        },
      
      });
    
    });
  });
</script>


@include('layouts.front.include.footer')