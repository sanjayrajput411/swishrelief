@include('layouts.front.include.header')

  <style>
    .box {
      width: 100px;
      height: 100px;
      border: 1px solid #80808070;
      border-radius: 10px;
    }

    .content {
      display: flex;
    }

    .text {
      width: 70%;
      margin: 0 25px;
    }

    .edit-btn button {
      background: skyblue;
      border: none;
      padding: 10px;
      width: 85px;
      border-radius: 20px;
      color: white;
    }

    .delete-btn button {
      background: skyblue;
      border: none;
      padding: 10px;
      width: 85px;
      border-radius: 20px;
      color: white;
    }

    .switch {
      position: relative;
      display: inline-block;
      width: 60px;
      height: 34px;
    }

    .switch input {
      opacity: 0;
      width: 0;
      height: 0;
    }

    .slider {
      position: absolute;
      cursor: pointer;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background-color: #ccc;
      -webkit-transition: .4s;
      transition: .4s;
    }

    .slider:before {
      position: absolute;
      content: "";
      height: 26px;
      width: 26px;
      left: 4px;
      bottom: 4px;
      background-color: white;
      -webkit-transition: .4s;
      transition: .4s;
    }

    input:checked+.slider {
      background-color: #2196F3;
    }

    input:focus+.slider {
      box-shadow: 0 0 1px #2196F3;
    }

    input:checked+.slider:before {
      -webkit-transform: translateX(26px);
      -ms-transform: translateX(26px);
      transform: translateX(26px);
    }

    /* Rounded sliders */
    .slider.round {
      border-radius: 34px;
    }

    .slider.round:before {
      border-radius: 50%;
    }

    /* .upload__box {
  padding: 40px;
} */
    .upload__inputfile {
      width: 0.1px;
      height: 0.1px;
      opacity: 0;
      overflow: hidden;
      position: absolute;
      z-index: -1;
    }

    .upload__btn {
      display: inline-block;
      font-weight: 600;
      color: #fff;
      text-align: center;
      min-width: 116px;
      padding: 5px;
      transition: all 0.3s ease;
      cursor: pointer;
      border: 2px solid;
      background-color: #373748;
      border-color: #373748;
      border-radius: 10px;
      line-height: 26px;
      font-size: 14px;
    }

    .upload__btn:hover {
      background-color: #a1a1d1;
      color: black;
      transition: all 0.3s ease;
      border: #a1a1d1;
    }

    .upload__btn-box {
      margin-bottom: 10px;
    }

    .upload__img-wrap {
      display: flex;
      flex-wrap: wrap;
      margin: 0 -10px;
    }

    .upload__img-box {
      width: 325px;
      padding: 0 10px;
      margin-bottom: 12px;
    }

    .upload__img-close {
      width: 24px;
      height: 24px;
      border-radius: 50%;
      background-color: rgba(0, 0, 0, 0.5);
      position: absolute;
      top: 10px;
      right: 10px;
      text-align: center;
      line-height: 24px;
      z-index: 1;
      cursor: pointer;
    }

    .upload__img-close:after {
      content: "✖";
      font-size: 14px;
      color: white;
    }

    .img-bg {
      background-repeat: no-repeat;
      background-position: center;
      background-size: cover;
      position: relative;
      padding-bottom: 100%;
    }
  </style>
</head>
<section class="forum-main-banner">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="contact-heading forum-heading">

          <h1>Create New Post</h1>

        </div>

      </div>

    </div>

  </div>

</section>
<div class="container my-5">
  <div class="row">
    <div class="col-md-12">
      
      <!-- <div class="col-md-5"> -->

        <div class="newpost-blog sdbs">
          <ul>

            <li>
              <select id="dropDown">
                <option value="Category">--Select Category--</option>
                @foreach ($ndata as $row)

                <option value="{{url('front/category/'.$row->id)}}">
                  <p>{{$row->category_name}}</p>
                </option>
                @endforeach
              </select>
            </li>
            <li><a href="{{url('front/all-post')}}">All Posts</a></li>
            <li><a href="{{url('front/my-post')}}">My Posts</a></li>
          </ul>
          <a href="https://netmaxims.in/projects/powerofourvoice/front/my-post" class="btn btn-danger backfpost"> Back </a>
        </div>
        
      <!-- </div> -->
    </div>

  </div>

  <form action="{{url('front/updatepost-forum/'.$data->id)}}" method="POST" enctype="multipart/form-data">
    @csrf
    @Method('PUT')
    <div class="row">
      <!-- <div class="col-xl-8 col-lg-8 col-sm-12 col-12 m-auto"> -->
      <div class="col-md-10 m-auto pt-5">

        @if(Session::has('success'))
        <div class="alert alert-success alert-dismissible">
          <button type="button" class="close" data-dismiss="alert">×</button>
          {{ Session::get('success') }}
        </div>
        @elseif(Session::has('failed'))
        <div class="alert alert-danger alert-dismissible">
          <button type="button" class="close" data-dismiss="alert">×</button>
          {{ Session::get('failed') }}
        </div>
        @endif

        <div class="card shadow">

          <div class="card-header">
            <h4 class="card-title"> Update Post </h4>
          </div>
          <div class="col-xl-12 text-left">
            <label for="cars">Select Category</label>

            <select name="category_name" class="form-control" required />
            @foreach ($ndata as $ndata)
            <?php //echo"<pre>";print_r($ndata);die;
            ?>
            <option value="{{ $ndata->category_name }}">{{ $ndata->category_name }}</option>
            @endforeach
            </select>
          </div>
          <div class="card-body">
            <div class="form-group">
              <label> Title </label>
              <input type="text" class="form-control" name="post_name" placeholder="Enter the Title" value="{{ $data->post_name }}" required/>
            </div>
            <div class="form-group create-edit-post">
              <label> Description </label>
              <textarea row="4" class="form-control" id="description" placeholder="Enter the Description" name="description" value="{{ $data->description }}" required />{{ $data->description }}</textarea>
            </div>
          </div>
          <!-- <div class="form-group">

<label for="name" class="col-sm-2 control-label">Image</label>

<div class="col-sm-12">

<div class="card-body">
                                	<div class="upload__box">
                                        <div class="upload__btn-box">
                                          <label class="upload__btn">
                                            <p style="margin: 0px;">Upload Images</p>
                                            <input type="file" multiple="" id="image" name="image" data-max_length="20" class="upload__inputfile" value="{{ $data->image}}">
                                        
                                          </label>
                                           <img src="{{ $data->image}}" style="width:60%;">
                                        </div>
                                        <div class="upload__img-wrap" value="{{ $data->image}}">
                                        </div>
                                      </div>
                                     </div>
</div>

</div> -->
          <div class="card-footer">
            <button type="submit" class="btn btn-success"> Update </button>
          </div>
        </div>
      </div>
    </div>
  </form>
</div>

<!-- <script>
        ClassicEditor
            .create( document.querySelector( '#description' ) )
            .catch( error => {
                console.error( error );
            } );
            tinymce.init({
  selector: 'textarea',  // change this value according to your HTML
  images_upload_url: '/frontend/save-post'
}); -->
<!-- <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css
" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.min.js
"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js
"></script> -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css
" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js
"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<!-- <link href="{{url('public/front/css/editor/summernote.css')}}"> -->
<!-- <script src="{{url('public/front/css/editor/summernote.js')}}"></script> -->
<script>
  $(document).ready(function() {
    $('#description').summernote();
  });
</script>
</script>



@include('layouts.front.include.footer')