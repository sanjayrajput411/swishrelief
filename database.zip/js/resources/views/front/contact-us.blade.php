@include('layouts.front.include.header')

<!-- start banner section -->

<section class="contact-main-banner">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="contact-heading">

          <h1>Contact Us</h1>

          <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform. Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>

          <button type="button" class="btn btn-warning">DONATE</button>

        </div>

      </div>

    </div>

  </div>

</section>

<!-- end banner section -->

<section class="book-appointment">

  <div class="container-fluid">

    <div class="row no-gutter">

      <div class="col-md-4">

        <div class="join-our-team">

          <div class="blance-our">

            <p><img src="{{asset('front/images/phone-banner.png')}}">(231) 598-8498</p>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="join-our-one">

          <div class="blance-our">

            <p> <img src="{{asset('front/images/balance-banner.png')}}">Join Our Team</p>

          </div>

        </div>

      </div>

      <div class="col-md-4">

        <div class="join-our-two">

          <div class="blance-our">

            <p><img src="{{asset('front/images/book-appoinment.png')}}">Book An Appointment</p>

          </div>

        </div>

      </div>

    </div>

  </div>

</section>

<!-- end section -->

<section class="major-topics">

  <div class="container">

    <div class="row">

      <div class="col-md-6">

        <div class="get-touch">

          <h2>CONTACT US</h2>

          <h3>Get In Touch</h3>

          <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform.<br> Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.
          <p>

          <ul>

            <li>

              <img src="{{asset('front/images/metro-location.png')}}">

              <span>Mailing Address:</span> <br> 2510 Royal Acres Dr, Denton, Texas 76209
            </li>

            <li>

              <img src="{{asset('front/images/address-contect.png')}}">

              <span>Headquarters: </span> <br>1790 Hadley Road , Lapeer, Michigan 48446
            </li>

            <li>

              <img src="{{asset('front/images/material-email.png')}}">

              Email info@powerofourvoices.com
            </li>

            <li>

              <img src="{{asset('front/images/phones-contect.png')}}">

              (231) 598-8498
            </li>

          </ul>

        </div>

      </div>

      <div class="col-md-6">

        <div class="customer-services-form">

          <form action="{{ url('/front/contact-us/sendmail') }}" method="POST">
            @csrf
            <input class="input-field" type="text" name="username" value="" placeholder="Your Name" required>

            <input class="input-field" type="email" name="email" value="" placeholder="Your Email" required>

            <input class="input-fields" type="number" name="phone" value="" placeholder="Your Mobile" required>

            <textarea id="subject" name="subject" value="" placeholder="Your Message" style="height:150px;" required></textarea>

            <input type="submit" name="Send_message" value="Send_message">

          </form>

        </div>

      </div>

    </div>

  </div>

</section>

<!-- end form section -->

<!-- start map section -->

<section class="map-background-image">

  <div class="container"></div>

</section>



@include('layouts.front.include.footer')
