@include('layouts.front.include.header')
<!-- start banner section -->
<section class="aboutus-main-banner">
  <div class="container">
    <div class="row">
    <div class="col-md-12">
      <div class="contact-heading">
        <h1>About Us</h1>
        <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform. Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>
       <button type="button" class="btn btn-warning">DONATE</button>
      </div>
    </div>
  </div>
  </div>
</section>
<!-- end banner section -->
<section class="book-appointment">
<div class="container-fluid">
<div class="row no-gutter">
  <div class="col-md-4">
    <div class="join-our-team">
        <div class="blance-our">
         <p><img src="{{asset('front/images/phone-banner.png')}}">(231) 598-8498</p>
    </div>
  </div>
   </div>
    <div class="col-md-4">
      <div class="join-our-one">
      <div class="blance-our">
      <p> <img src="{{asset('front/images/balance-banner.png')}}">Join Our Team</p>
      </div>
     </div>
   </div>
      <div class="col-md-4">
        <div class="join-our-two">
      <div class="blance-our">
      <p><img src="{{asset('front/images/book-appoinment.png')}}">Book An Appointment</p>
        </div>
      </div>
    </div>
    </div>
  </div>
</section>
<!-- end section -->
<section class="full-store-about">
  <div class="container">
    <div class="row">
      <div class="col-md-5">
        <div class="aboutus-heading-second">
       <img src="{{asset('front/images/full-store.png')}}">
      </div>
      </div>
      <div class="col-md-7">
        <div class="aboutus-heading-second">
          <h6>ABOUT US</h6>
          <h2>The Full Story</h2>
          <p>A home for people without distinction or separation. We as a community have reached out to those who have experienced the other side of our justice system. The ones that are often prohibited from voting, holding office, or otherwise being heard. They are prisoners who are trying to repay their debt to society and to get back. These individuals, the sometimes forgotten citizens, have spent their time researching and studying to provide the most vital information they could, all the while studying their own personal academics. They do so, so that they can help the people as a whole. They are considered part of the power of our voice's community. We all understand that there's a difference between what should be and what is. Together we hope that we can make change happen, first we must know the truth. Below we have gathered information and statistics to help you understand the legal system by providing free research. This is for informational purposes only and does not constitute legal advice. We are not attorneys and you should consult a licensed attorney for any legal advice. This information is intended to assist you and the lawyers by providing a great deal of information for free. This information will help you understand your rights and help alleviate some of the pressures from your attorney. Many of the most common questions can be found here so you can narrow your questions to the attorney. Although there are many books and websites with this information, sometimes finding it and navigating it is difficult and costly.</p>
        </div>
      </div>
    </div>
  <div class="row">
  <div class="col-md-12">
    <div class="we-wantabout">
    <p><img src="{{asset('front/images/charity-about.png')}}">Want to experience the expertise of POWER OF OUR VOICE for yourself? If you need more information on anything you see here, it will be found on our services page with a fixed fee for a consultation.We do not believe that you should have to pay to know your rights. Please provide your feedback so we can continue to make this site grow in a manner most efficient for everyone.</p>
  </div>
  </div>
</div>
</div>
</section>
<!-- end section -->
<section class="team-member-main">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="parter-about">
        <p>Who We Are</p>
        <h2>Our Team</h2>
      </div>
    </div>
    </div>
    <div class="row reversrow">
      <div class="col-md-8">
        <div class="parter-about-second">
        <h2>Khalajah "Kay" Wilson</h2>
        <h5>Partner</h5>
      <ul>
     <li>Web Designer And Team Member.</li>
    <li>Contact: 940-453-8550</li>
    <li>Mail: Info@Powerofourvoices.Com</li>
    </ul>
  <i class="fa fa-facebook" aria-hidden="true"></i>
  <i class="fa fa-twitter" aria-hidden="true"></i>
   <i class="fa fa-instagram" aria-hidden="true"></i>
    </div>
    </div>
    <div class="col-md-4">
    <div class="web-designer-images">
      <img src="{{asset('front/images/Rectangle -2.png')}}">
    </div>
    </div>
  </div>
</div>
</section>
<!-- end section -->
<section class="team-member-main-second">
  <div class="container">
    <div class="row">
      <div class="col-md-4">
      <div class="web-designer-image">
        <img src="{{asset('front/images/Rectangle-196.png')}}">
      </div>
      </div>
      <div class="col-md-8">
        <div class="parter-about-second">
        <h2>Rajahn "Hamzah" Brown</h2>
        <h5>Partner</h5>
      <ul>
     <li>Grew up in Newark, New Jersey. Successfully completed paralegal course with honors through Blackstone Career Institute.</li>
    <li>Contact: 940-453-8550</li>
    <li>Mail: Info@Powerofourvoices.Com</li>
    </ul>
    <i class="fa fa-facebook" aria-hidden="true"></i>
    <i class="fa fa-twitter" aria-hidden="true"></i>
     <i class="fa fa-instagram" aria-hidden="true"></i>
    </div>
    </div>
  </div>
</div>
</section>
<section class="team-member-main">
  <div class="container">
    <div class="row reversrow">
      <div class="col-md-8">
        <div class="parter-about-second">
        <h2>Michael "Mika'eel" Freeman</h2>
        <h5>Partner</h5>
      <ul>
     <li>Has self-studied law for 20 years, successfully completed law courses at Kaplan University and Everest University but is not a licensed lawyer. Successfully completed paralegal course with honors through Blackstone Career Institute.</li>
    <li>Contact: 940-453-8550</li>
    <li>Mail: Info@Powerofourvoices.Com</li>
    </ul>
    <i class="fa fa-facebook" aria-hidden="true"></i>
    <i class="fa fa-twitter" aria-hidden="true"></i>
     <i class="fa fa-instagram" aria-hidden="true"></i>
    </div>
    </div>
    <div class="col-md-4">
    <div class="web-designer-michael">
      <img src="{{asset('front/images/Rectangle -1.png')}}">
    </div>
    </div>
  </div>
</div>
</section>
<!-- end section -->
<section class="team-member-main-second hide">
  <div class="container">
    <div class="row">
      <div class="col-md-4">
      <div class="web-designer-charis">
        <img src="{{asset('front/images/Rectangle -3.png')}}">
      </div>
      </div>
      <div class="col-md-8">
        <div class="parter-about-second">
        <h2>Chris</h2>
        <h5>LLC Manager</h5>
      <ul>
     <li>A retired science teacher who has dedicated his life to helping others.</li>
    <li>Contact: 940-453-8550</li>
    <li>Mail: Info@Powerofourvoices.Com</li>
    </ul>
    <i class="fa fa-facebook" aria-hidden="true"></i>
    <i class="fa fa-twitter" aria-hidden="true"></i>
     <i class="fa fa-instagram" aria-hidden="true"></i>
    </div>
    </div>
  </div>
</div>
</section>@include('layouts.front.include.footer')
