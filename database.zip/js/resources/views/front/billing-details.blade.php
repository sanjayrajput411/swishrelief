@include('layouts.front.include.header')

<!-- banner section start -->

<section class="national-inmat">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="banner-heading-select">

          <h1>Personal Detail</h1>

        </div>

      </div>

    </div>

  </div>

</section>

<!-- end section -->

<section class="form-billing-and-summary">
  @if(Session::has('Success_msg'))
  <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('Success_msg') }}</p>
  @endif
  <div class="container">

    <div class="row">

      <div class="col-md-7">

        <h2 class="details-heading">Personal Detail</h2>

        <div class="billing-details-main">
          @foreach($data as $row)

          <form action="{{url('front/add-order')}}" method="POST">
            <!-- <form class="form-horizontal" method="POST" id="payment-form" role="form" action="{!! URL::route('paypal') !!}" >-->
            @csrf

            <div class="half-width">

              <input type="text" class="phone-email" name="name" placeholder="First Name" value="{{$row->name}}" required>

            </div>

            <div class="half-width">

              <input type="text" class="phone-email" name="last_name" placeholder="Last Name" value="{{$row->last_name}}" >

            </div>



            <div class="half-width">

              <input type="text" class="frist-name" name="company_name" placeholder="Mobile No." value="{{$row->company_name}}" required>

            </div>

            <div class="half-width">

              <select id="country" name="country" value="{{$row->country}}" required>

                <option>Country</option>

                <option value="Guyana">Guyana</option>

                <option value="Haiti">Haiti</option>

                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>

                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>

                <option value="Honduras">Honduras</option>

                <option value="Hong Kong">Hong Kong</option>

                <option value="Hungary">Hungary</option>

                <option value="Iceland">Iceland</option>

                <option value="India">India</option>

                <option value="Indonesia">Indonesia</option>

                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>

                <option value="Iraq">Iraq</option>

                <option value="Ireland">Ireland</option>

                <option value="Isle of Man">Isle of Man</option>

              </select>

            </div>

            <div class="half-width" style="margin-left: 16px;">

              <select id="country" name="state" value="{{$row->state}}" required>

                <option>State</option>

                <option value="Guyana">Guyana</option>

                <option value="Haiti">Haiti</option>

                <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>

                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>

                <option value="Honduras">Honduras</option>

                <option value="Hong Kong">Hong Kong</option>

                <option value="Hungary">Hungary</option>

                <option value="Iceland">Iceland</option>

                <option value="India">India</option>

                <option value="Indonesia">Indonesia</option>

                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>

                <option value="Iraq">Iraq</option>

                <option value="Ireland">Ireland</option>

                <option value="Isle of Man">Isle of Man</option>
              </select>
            </div>
            <div class="half-width" style="margin-top: -83px;margin-left: 309px;">
              <input type="text" class="phone-email" name="city" placeholder="City" value="{{$row->city}}" required>
            </div>
        </div>
      </div>
      <div class="col-md-5">
        <h2 class="details-heading">Order Summary</h2>
        <div class="order-summary">
          <ul>
            <input type="hidden" id="plan_id" name="plan_id" Value="{{ $plan_id }}">
            <li>
              <p class="title" name="package_name">Package Name</p>
              <input type="text" id="package_name" class="phone-email" name="package_name" Value="{{ $package_name }}" placeholder="package name">
            </li>
            <li>
              <p class="title" name="package_price">Package Price</p>
              <input type="text" id="package_name" class="phone-email" name="package_price" placeholder="package price" Value="${{ $plan_price }}">
            </li>
          </ul>
          <ul class="packeges">
            <li>
              <p class="title" name="total">TOTAL</p>
               <input type="text" id="package_name" class="phone-email" name="total" Value="{{ $plan_price }}">
            </li>
          </ul>
          <button name="submit" value="submit" class="paypal_btn py-2"  type="submit" value="Continue Purchase"><span>Cash on Delivery</span></button>  
           <button name="paywith_paypal" value="paywith_paypal" type="submit" class="paypal_btn" style="background: #efc541;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paypal my-2" viewBox="0 0 16 16">
            </svg>Paywith Paypal </button>
          </form>

          @endforeach
        </div>

      </div>

    </div>

  </div>

</section>

<style>
  .paypal_btn {
    background: #3E849E;
    color: #FFFFFF;
    font-family: 'helvetica';
    font-weight: bold;
    border: 0px solid;
    width: 85%;
    margin: 30px auto !important;
    display: block;

  }
</style>







@include('layouts.front.include.footer')
