@include('layouts.front.include.header')

<head>

  <!-- Required meta tags -->

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
  <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
  <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

  <title>Power Of Our Voices</title>

<style> 
 .editor span {
  background-color: #fff !important;
}
</style>

</head>


<section class="newforum-main-banner">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="contact-heading">

          <!-- <h1>Title</h1> -->

        </div>

      </div>

    </div>

  </div>

</section>
<!-- end banner section -->

<section class="table-past-main">

  <div class="container">

    

      

        <div class="newpost-blog sdbs">

          <ul>
            <li><select id="dropDown">
                <option value="Category">--Select Category--</option>
                @foreach ($cat_data as $row)

                <option value="{{url('front/category/'.$row->id)}}" {{ ($row->id == $category_id) ? 'selected' : '' }}> <p>{{$row->category_name}}</p> </option>
                @endforeach
              </select></li>
            <li><a href="{{url('front/all-post')}}">All Posts</a></li>
            <li> <span>Views : {{$viewcount}}</span>
          </ul>

        </div>
        <hr>

      

      

    

  </div>

</section>



<!-- end section -->
@foreach($data as $data)

<section class="forums-second">


  <div class="container">

    <div class="example-share">
      <span class="d-flex">
      <img src="{{asset('assets/images/profile/userimage.png')}}" style="border: 1px solid #c6c7c852;width: 50px !important;height: 50px !important;margin: 0;"></img>
      <h3 style="margin: 15px;">{{$data->post_name}}</h3>
      </span>

      <div class="post-by">
        <h4><strong>By: </strong><a href="{{ url('front/profile/' . $data->user_id)  }}">{{$data->name}}</a></h4>
        <p class="date">{{Carbon\Carbon::parse($data->created_at)->format('D, d M Y') }}</P>
      </div>

      <div class="editor all-postss-descriiption"><?php print_r($data->description); ?></div>

    </div>

  </div>

</section>


<section class="newforum-detail">

  <div class="container">
      <!-- <h4 class="avatar" style="color: brown;"> Comments : ({{$count}})</h4> -->
      <h3 class="comments">Comments: ({{$count}})</h3>
    <hr class="comments">

      @foreach ($comment as $comment)

      <div class=" unnamed-images data-table" style="margin-top:35px;display: flex;">
        <div class="avatar">

          <a href="{{ url('front/profile/' . $comment->user_id)  }}"><img src="https://netmaxims.in/projects/powerofourvoice/public/front/images/unnamed.png"></a>

        </div>
        <div class="avatar-info data-table">
          <h3 style="font-size: 22px;">{{$comment->name}}

            @if(isset(Auth::User()->id) == $comment->user_id)


            <a href="javascript:void(0)" data-toggle="tooltip" data-id="{{$comment->id}}" data-original-title="Edit" class="edit  editcategory"><i class="fa fa-align-right" aria-hidden="true" style="font-size: 14px;"></a></i>
            <a href="javascript:void(0)" onclick="destroy" data-toggle="tooltip" data-id="{{$comment->id}}" data-original-title="Delete" class="delete  deletecategory"><i class="fa fa-eraser" aria-hidden="true" style="font-size:14px;"></a></i>
            @else


            @endif
            </h3>          

            <p>{{strip_tags($comment->comment)}}</p>

            
        </div>
        
      </div>
      <p class="comment date">{{Carbon\Carbon::parse($comment->commu_date)->format('d M Y') }}</p>
      @endforeach
  </div>

  <div class="container">


    @if(Auth::User())
    <!-- <div class="modal-dialog" style="margin-left: 1px;"> -->

      

        

        

          <form id="productForm" name="productForm" class="form-horizontal">

            <input type="hidden" name="id" id="id">

            <div class="form-group">

              <input type="text" class="form-control" id="post_id" name="post_id" placeholder="Enter Name" value="{{$data->id}}" maxlength="50" required="" hidden>

            </div>



            <div class="form-group comments">

            <h2>Write a comment</h2>

              <textarea rows="4" id="comment" name="comment" required="" placeholder="Write your comment here..." class="form-control"></textarea>


            </div>

            <button type="submit" class="comments" id="saveBtn" value="{{$data->id}}">Publish </button>


          </form>

        

      

    <!-- </div> -->
    @endif



  </div>

  



</section>
@endforeach


<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<script type="text/javascript">
  $(function() {



    /*------------------------------------------

     --------------------------------------------

     Pass Header Token

     --------------------------------------------

     --------------------------------------------*/

    $.ajaxSetup({

      headers: {

        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

      }

    });



    /*------------------------------------------

    --------------------------------------------

    Render DataTable

    --------------------------------------------

    --------------------------------------------*/




    /*------------------------------------------

    --------------------------------------------

    Click to Button

    --------------------------------------------

    --------------------------------------------*/

    $('#createNewProduct').click(function() {

      $('#saveBtn').val("create-product");

      $('#id').val('');

      $('#productForm').trigger("reset");

      $('#modelHeading').html("Create New Category");

      $('#ajaxModel').modal('show');

    });



    /*------------------------------------------

    --------------------------------------------

    Click to Edit Button

    --------------------------------------------

    --------------------------------------------*/

    $('body').on('click', '.edit', function() {

      var id = $(this).data('id');

      $.get("{{ route('comment.store') }}" + '/' + id + '/edit', function(data) {

        $('#modelHeading').html("Edit Category");

        $('#saveBtn').val("edit-user");

        $('#ajaxModel').modal('show');

        $('#id').val(data.id);

        $('#comment').val(data.comment);

        $('#post_id').val(data.post_id);

      });

    });



    /*------------------------------------------

    --------------------------------------------

    Create Product Code

    --------------------------------------------

    --------------------------------------------*/

    $('#saveBtn').click(function(e) {

      e.preventDefault();

      $(this).html('Sending..');

      console.log(id);

      $.ajax({

        data: $('#productForm').serialize(),

        url: "{{ route('comment.store') }}",

        type: "POST",

        dataType: 'json',

        success: function(data) {

          document.location.reload(true);

          $('#productForm').trigger("reset");

          $('#ajaxModel').modal('hide');

          table.draw();



        },

        error: function(data) {
          document.location.reload(true);
          console.log('Error:', data);

          $('#saveBtn').html('Save Changes');


        }

      });

    });



    /*------------------------------------------

    --------------------------------------------

    Delete Product Code

    --------------------------------------------

    --------------------------------------------*/

    $('body').on('click', '.delete', function() {
     

      var id = $(this).data("id");
      if(confirm('Are you sure to remove this record ?')){

        $.ajax({

        type: "DELETE",

        url: "{{ route('comment.store') }}" + '/' + id,

        success: function(data) {

          table.draw();

        },

        error: function(data) {
          window.location.reload();
          console.log('Error:', data);

        }

      });
    }
    });



  });
</script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />

<link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">

<link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>

<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

<script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

<script>
  var dropDownValue = document.getElementById("dropDown");

  dropDownValue.onchange = function() {
    if (this.selectedIndex !== 0) {
      window.location.href = this.value;
    }
  };
</script>
<script>
  $('body').load('/site/pages/sample.html body');
</script>
<style>
  p.mm8Nw {
    background: inherit !important;
  }

  div.mm8Nw {
    background: inherit !important;
  }
</style>
@include('layouts.front.include.footer')