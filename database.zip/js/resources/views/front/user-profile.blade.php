@include('layouts.front.include.header')

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
@if(Session::has('Trans_msg'))
<script type="text/javascript">
  toastr.options.timeOut = 3000;
  toastr.success("{{ session('Trans_msg') }}");
  // toastr.info("{{ session('msg') }}");
  // toastr.warning("{{ session('msg') }}");
  //  toastr.error("{{ session('error') }}");
</script>
@endif

<section class="profile-main-banner">

  <div class="container">

    <div class="row">

      <div class="col-md-12">

        <div class="sign-main">

          <h1>Profile</h1>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- end banner section -->

<!-- start profie section -->

<!-- <button type="button" class="btn btn-primary add-pic" data-bs-toggle="modal" data-bs-target="#editpicoprison">
              Add Pictures
            </button> -->
<section class="profile-sec">
  <div class="container profile-tabs">
    <div class="box"></div>
    <div class="d-flex align-items-start">
      <div class="nav flex-column nav-pills me-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
        @if($userimage)
        <img id="blah" src="{{asset('front/images/'.$userimage)}}">
        @else
        <form class="text-center mb-4" method="POST" action="{{url('front/uploadimage') }}" enctype="multipart/form-data">
          @csrf

          <img id="blah" class="my-4" src="{{asset('front/profile.jpg')}}">
          <input accept="image/*" name="userimage" value="" type='file' id="imgInp" style="font-size: 10px;display:none">
          <button id="imagebtn" class="btn-sm" name="uploadimg" type="uploadimg" style="display: none;font-size: 10px;margin: 0px 35% 0 35%;">Upload</button>
        </form>

        @endif

        <h3 class="username">{{ $username }}</h3>

        <ul class="user-followers">
          <li>0 followers</li>
          <li>|</li>
          <li>1 following</li>
        </ul>
        <button class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-account" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true"><img src="{{asset('/front/images/user-profile/Icon material-account-circle@2x.png')}}">My Account</button>
        <button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-plan" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false"><img src="{{asset('/front/images/user-profile/credit-card (6)@2x.png')}}">Upgrade plan</button>
        <button class="nav-link" id="v-pills-messages-tab" data-bs-toggle="pill" data-bs-target="#v-pills-history" type="button" role="tab" aria-controls="v-pills-messages" aria-selected="false"><img src="{{asset('/front/images/user-profile/wallet (3)@2x.png')}}">Payment history</button>
        <button class="nav-link" id="v-pills-settings-tab" data-bs-toggle="pill" data-bs-target="#v-pills-prisoner" type="button" role="tab" aria-controls="v-pills-settings" aria-selected="false"><img src="{{asset('/front/images/user-profile/photo@2x.png')}}">Pictures for Prisoners</button>
        <!-- <button class="nav-link" id="v-pills-settings-tab" data-bs-toggle="pill" data-bs-target="#v-pills-settings" type="button" role="tab" aria-controls="v-pills-settings" aria-selected="false"><img src="{{asset('/front/images/user-profile/Icon ionic-ios-settings@2x.png')}}">Settings</button> -->
        <button class="nav-link" id="v-pills-settings-tab" data-bs-toggle="pill" data-bs-target="#v-pills-notification" type="button" role="tab" aria-controls="v-pills-settings" aria-selected="false"><img src="{{asset('/front/images/user-profile/Icon material-notifications-active@2x.png')}}">Notifications</button>
      </div>


      <div class="tab-content" id="v-pills-tabContent">
        <!---- account edit form ------------------------------------->
        <div class="tab-pane fade show active mt-0" id="v-pills-account" role="tabpanel" aria-labelledby="v-pills-home-tab" style="background: #8381782e;">
          <!-- <h2>Sign Up</h2> -->
          <h2 style="text-align: center;text-transform: capitalize;">Edit account details</h2>

          @foreach($data as $udetail)
          <form method="POST" action="{{ url('front/user-profile') }}">
            @csrf

            <div class="row">
              <div class="login-member signup-member pt-0 mt-0 col-6">
                <div class="feedback-sign-up">
                  <label for="name" class="col-form-label">First Name</label>
                  <input id="name" type="text" class="form-control  " name="name" value="{{ $udetail->name}}" required="" autocomplete="name" autofocus="">
                </div>

                <div class="feedback-sign-up">
                  <label for="email" class="col-form-label">Email Address</label>
                  <input id="email" type="email" class="form-control " name="email" value="{{ $udetail->email}}" required="" autocomplete="email">

                </div>

              </div>

              <div class="login-member signup-member pt-0 mt-0 col-6">
                <div class="feedback-sign-up">
                  <label for="name" class="col-form-label">Last Name</label>
                  <input id="name" type="text" class="form-control  " name="last_name" value="{{ $udetail->last_name}}" required="" autocomplete="name" autofocus="">
                </div>

              </div>
            </div>

            <div class="register-button" style="text-align: center;">
              <button type="submit" class="btn btn-primary" style=" width: 50%;">update</button>
            </div>

          </form>
          @endforeach
        </div>
        <!---- account edit form ------------------------------------->
        <div class="tab-pane fade" id="v-pills-plan" role="tabpanel" aria-labelledby="v-pills-profile-tab">

          <h3>Manage Subscription</h3>

          <div class="row activ-plans">
            <div class="col-md-4">
              <h5>Active Plan</h5>

              @if($active_plan_detail)

              @foreach($active_plan_detail as $plan_detail)

              <h3>{{ $plan_detail->package_name }}</h3>
              <h3 class="price">${{ $plan_detail->plan_price }}<span>/month</span></h3>

              @endforeach
              @else
              <h3>Trial</h3>
              <h3 class="price">$0.00<span>/month</span></h3>
              @endif

            </div>
            <div class="col-md-5">
              <p>Government officials who found themselves on the wrong side</p>
              <ul>
                <li>Compromised judges</li>
                <li>Compromised congress</li>
              </ul>
            </div>
            <div class="col-md-3">
              <!-- <button>Upgrade Plan</button> -->
              <!-- Button trigger modal -->
              <button type="button" class="btn btn-primary u-plans" data-bs-toggle="modal" data-bs-target="#exampleModal">
                Upgrade Plan
              </button>

              <!-- Modal -->
              <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                  <div class="modal-content">

                    <div class="modal-body">
                      <h4 class="modal-title" id="exampleModalLabel">Pricings</h4>
                      <p>Choose the right plan for you.</p>
                      <hr>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      <div class="row text-center">

                        @foreach($plans as $plan)
                        <div class="col-md-5 m-3">

                          <form action="{{url('front/billing-details') }}" method="POST" enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="plan_id" value="{{ $plan->id }}">
                            <div class="plan-cards">
                              <h5>{{ $plan->package_name }}</h5>
                              <h2 class="pricing">${{ $plan->plan_price }}</h2>
                              <span class="pricing">{{ $plan->plan_validity }} Day</span>
                              <hr>
                              <p>Government officials who found themselves on the wrong side</p>
                              <ul>
                                <li>Compromised judges</li>
                                <li>Compromised congress</li>
                              </ul>
                              <button type="submit" class="select">Select</button>
                            </div>
                          </form>

                        </div>
                        @endforeach


                        <!-- <div class="col-md-5">
                          <div class="plan-cards">
                            <h5>Platinum</h5>
                            <h2 class="pricing">$20.00</h2>
                            <span class="pricing">Per Month</span>
                            <hr>
                            <p>Government officials who found themselves on the wrong side</p>
                            <ul>
                              <li>Compromised judges</li>
                              <li>Compromised congress</li>
                            </ul>
                            <button class="select">Select</button>
                          </div>
                        </div> -->
                        <div class="col-md-2"></div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>

          <hr>

        </div>
        <div class="tab-pane fade" id="v-pills-history" role="tabpanel" aria-labelledby="v-pills-messages-tab">

          <h3>Payment History</h3>
          <hr>
          <div class="table-responsive">
          <table class=" table">
            <thead>
              <th>Order ID </th>
              <th>Plan name</th>
              <th>Amount</th>
              <th>Mobile Number</th>
              <th>Valid Up to</th>
            </thead>
            <tbody>
              @if(!$ctorder == '0')
              @foreach($order as $listorder)
              <tr>
                <td>{{$listorder->plan_id}}</td>
                <td>{{$listorder->package_name}}</td>
                <td>{{$listorder->package_price}}</td>
                <td>@if(!$listorder->company_name== '') {{$listorder->company_name}} @else - @endif</td>
                <td>{{date("d M Y h:i:s a",strtotime($listorder->Validity))}}</td>
              </tr>
              @endforeach
              @else
              @foreach($data as $userdetails)

              <td>No Record found.</td>
              @endforeach

              @endif
            </tbody>
          </table>
        </div>

        </div>

        <div class="tab-pane fade poprison" id="v-pills-prisoner" role="tabpanel" aria-labelledby="v-pills-settings-tab">


          <div class="head" style="height: 45px;">
            <h3>Pictures </h3>
            <!-- <button>Add Pictures</button> -->


            @if(!$ctorder == '0')
            <button type="button" class="btn btn-primary add-pic" data-bs-toggle="modal" data-bs-target="#picoprison">
              Add Pictures
            </button>
            @endif

            <form name="myForm" action="{{url('front/prisoners') }}" method="POST" enctype="multipart/form-data">
              @csrf
              <div class="modal fade" id="picoprison" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">


                <div class="modal-dialog main-model-pp">
                  <div class="modal-content">

                    <div class="modal-body">
                      <h5 class="modal-title" id="exampleModalLabel">Pictures For Prisoners</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      <div class="picopris-box">
                        <div class="row">
                          <div class="col-md-6">
                            <input type="text" placeholder="First Name" name="first_name" required>
                            <input type="tel" placeholder="Prisoner number" name="prisoner_name" required>
                          </div>
                          <div class="col-md-6">
                            <input type="text" placeholder="Last Name" name="last_name" required>
                            <input type="text" placeholder="Mailing address" name="mailing_address" required>
                          </div>
                          <div class="col-12 col-lg-12">
                            <div class="card">
                              <div class="card-header">
                                <h5 class="card-title mb-0"> Gallery </h5>
                              </div>



                              <div class="card-body">
                                <div class="upload__box">
                                  <div class="upload__btn-box">
                                    <label class="upload__btn">
                                      <p style="margin: 0px;">Upload Gallery Images</p>
                                      <input type="file" name="galleries[]" class="upload__inputfile" multiple  required='required'/>
                                    </label>
                                  </div>
                                  <div class="upload__img-wrap">
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="col-md-6">

                            <input type="submit" value="Submit">
                          </div>

                          @if($errors->any())
                          <span style="color:red">
                            {{ implode('', $errors->all('The Images must not have more than 5.')) }}
                          </span>
                          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
                          <script>
                            $("#v-pills-home-tab").removeClass("active");
                            $("#v-pills-settings-tab").addClass("active");
                            $("#v-pills-account").removeClass("active");
                            $("#v-pills-prisoner").addClass("poprison active show");
                            $("#picoprison").addClass("show");
                            $("#picoprison").css("display", "block");
                            $("#picoprison").css("background", "#0000000f");
                          </script>
                          @endif
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
          <p class="date">Gallery Images</p>
          <!-- <ul class="images">
            @foreach($prison_photo as $photo)
            @foreach(explode(",",$photo->galleries) as $image_new)
            <li>

              <img src="{{url('/')}}/images/gallery/{{ $image_new }}">


            </li>
            @endforeach
            @endforeach
          </ul> -->
        </div>
        <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</div>
        <div class="tab-pane fade" id="v-pills-notification" role="tabpanel" aria-labelledby="v-pills-settings-tab">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</div>
      </div>
    </div>
  </div>
</section>






<div class="head" style="height: 45px;">
  <!-- <button>Add Pictures</button> -->


  <form name="myForm" action="{{url('front/update-prisoners/.$data->id') }}" method="POST" enctype="multipart/form-data">
    @csrf
    @Method('PUT')
    <div class="modal fade" id="editpicoprison" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">


      <div class="modal-dialog">
        <div class="modal-content">

          <div class="modal-body">
            <h5 class="modal-title" id="exampleModalLabel">Pictures For Prisoners</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            <div class="picopris-box">
              <div class="row">
                <div class="col-md-6">
                  <input type="text" placeholder="First Name" name="first_name" value="">
                  <input type="tel" placeholder="Prisoner number" name="prisoner_name">
                </div>
                <div class="col-md-6">
                  <input type="text" placeholder="Last Name" name="last_name">
                  <input type="text" placeholder="Mailing address" name="mailing_address">
                </div>
                <div class="col-12 col-lg-12">
                  <div class="card">
                    <div class="card-header">
                      <h5 class="card-title mb-0"> Gallery </h5>
                    </div>
                    <div class="card-body">
                      <div class="upload__box">
                        <div class="upload__btn-box">
                          <label class="upload__btn">
                            <p style="margin: 0px;">Upload Gallery Images</p>
                            <input type="file" name="galleries[]" class="upload__inputfile" multiple />
                          </label>
                        </div>
                        <div class="upload__img-wrap">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">

                  <input type="submit" value="Submit">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </form>
</div>
<style>
  .switch {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 34px;
  }

  .switch input {
    opacity: 0;
    width: 0;
    height: 0;
  }

  .slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    -webkit-transition: .4s;
    transition: .4s;
  }

  .slider:before {
    position: absolute;
    content: "";
    height: 26px;
    width: 26px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    -webkit-transition: .4s;
    transition: .4s;
  }

  input:checked+.slider {
    background-color: #2196F3;
  }

  input:focus+.slider {
    box-shadow: 0 0 1px #2196F3;
  }

  input:checked+.slider:before {
    -webkit-transform: translateX(26px);
    -ms-transform: translateX(26px);
    transform: translateX(26px);
  }

  /* Rounded sliders */
  .slider.round {
    border-radius: 34px;
  }

  .slider.round:before {
    border-radius: 50%;
  }

  /* .upload__box {
  padding: 40px;
} */
  .upload__inputfile {
    width: 0.1px;
    height: 0.1px;
    opacity: 0;
    overflow: hidden;
    position: absolute;
    z-index: -1;
  }

  .upload__btn {
    display: inline-block;
    font-weight: 600;
    color: #fff;
    text-align: center;
    min-width: 116px;
    padding: 5px;
    transition: all 0.3s ease;
    cursor: pointer;
    border: 2px solid;
    background-color: #373748;
    border-color: #373748;
    border-radius: 10px;
    line-height: 26px;
    font-size: 14px;
  }

  .upload__btn:hover {
    background-color: #a1a1d1;
    color: black;
    transition: all 0.3s ease;
    border: #a1a1d1;
  }

  .upload__btn-box {
    margin-bottom: 10px;
  }

  .upload__img-wrap {
    display: flex;
    flex-wrap: wrap;
    margin: 0 -10px;
  }

  .upload__img-box {
    width: 200px;
    padding: 0 10px;
    margin-bottom: 12px;
  }

  .upload__img-close {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    background-color: rgba(0, 0, 0, 0.5);
    position: absolute;
    top: 10px;
    right: 10px;
    text-align: center;
    line-height: 24px;
    z-index: 1;
    cursor: pointer;
  }

  .upload__img-close:after {
    content: "✖";
    font-size: 14px;
    color: white;
  }

  .img-bg {
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    position: relative;
    padding-bottom: 100%;
  }
</style>
<script type="text/javascript">
  window.onload = function() {
    //Reference the DropDownList.
    var ddlYears = document.getElementById("ddlYears");

    //Determine the Current Year.
    var currentYear = (new Date()).getFullYear();

    //Loop and add the Year values to DropDownList.
    for (var i = 2000; i <= currentYear; i++) {
      var option = document.createElement("OPTION");
      option.innerHTML = i;
      option.value = i;
      ddlYears.appendChild(option);
    }
  };

  function loadPreview(input) {
    var data = $(input)[0].files; //this file data
    $.each(data, function(index, file) {
      if (/(\.|\/)(gif|jpe?g|png)$/i.test(file.type)) {
        var fRead = new FileReader();
        fRead.onload = (function(file) {
          return function(e) {
            var img = $('<img/>').addClass('thumb').attr('src', e.target.result); //create image thumb element
            $('#thumb-output').append(img);
          };
        })(file);
        fRead.readAsDataURL(file);
      }
    });
  }
</script>

<script>
  jQuery(document).ready(function() {
    ImgUpload();
  });

  function ImgUpload() {
    var imgWrap = "";
    var imgArray = [];

    $('.upload__inputfile').each(function() {
      $(this).on('change', function(e) {
        imgWrap = $(this).closest('.upload__box').find('.upload__img-wrap');
        var maxLength = $(this).attr('data-max_length');

        var files = e.target.files;
        var filesArr = Array.prototype.slice.call(files);
        var iterator = 0;
        filesArr.forEach(function(f, index) {

          if (!f.type.match('image.*')) {
            return;
          }

          if (imgArray.length > maxLength) {
            return false
          } else {
            var len = 0;
            for (var i = 0; i < imgArray.length; i++) {
              if (imgArray[i] !== undefined) {
                len++;
              }
            }
            if (len > maxLength) {
              return false;
            } else {
              imgArray.push(f);

              var reader = new FileReader();
              reader.onload = function(e) {
                var html = "<div class='upload__img-box'><div style='background-image: url(" + e.target.result + ")' data-number='" + $(".upload__img-close").length + "' data-file='" + f.name + "' class='img-bg'><div class='upload__img-close'></div></div></div>";
                imgWrap.append(html);
                iterator++;
              }
              reader.readAsDataURL(f);
            }
          }
        });
      });
    });

    $('body').on('click', ".upload__img-close", function(e) {
      var file = $(this).parent().data("file");
      for (var i = 0; i < imgArray.length; i++) {
        if (imgArray[i].name === file) {
          imgArray.splice(i, 1);
          break;
        }
      }
      $(this).parent().parent().remove();
    });
  }
</script>
<script>
  $(document).ready(function() {
    $(".btn-close").on("click", function() {
      $("#picoprison").removeClass("show");
      $("#picoprison").css("display", "none");
    });

  });
</script>
<script>
  $(function() {
    $('#blah').on('click', function() {
      $('#imgInp').trigger('click');
      $("#imagebtn").css("display", "block");
    });
  });
</script>
<script>
  imgInp.onchange = evt => {
    const [file] = imgInp.files
    if (file) {
      blah.src = URL.createObjectURL(file)
    }
  }
</script>
<!-- footer section start -->

@include('layouts.front.include.footer')
