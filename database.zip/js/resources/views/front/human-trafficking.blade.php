@include('layouts.front.include.header')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<section class="goverment-trafficking">
<div class="container">
<div class="row">
<div class="col-md-12">
  <div class="contact-heading">
  <h1>Human Trafficking</h1>
  <p>All victims who speak out against abuse and those who are unable to do so. We cannot properly begin to understand how much strength and courage it takes to speak out. Sometimes people don't believe you but you speak out anyway, especially when in today's society the victims are put to blame more than the abuser. So we give a special thanks to every victim of any kkind who has spoken out and lends support to those whose voices remain silenced by their victimizer. These include but not limited to Simone Biles and her teammates who testified before Congress on September 16, 2021.</p>
  <button type="button" class="btn btn-warning">DONATE</button>
</div>
</div>
</div>
</div>
</section>
<!-- end banner section -->
<section class="violence-human">
 <div class="container">
   <div class="row">
     <div class="col-md-12">
      <div class="second-human-trafficking">
        <h2 class="same-often">Psychological Violence</h2>
          <p>Human trafficking victims are often forced, through sexual, physical and/or psychological violence, to perform work under slavery-like conditions. These conditions are based often times on acts of manipulation. These services are placed on the internet like www.Backpage.com </p>
          <p>Tactics used by those who recruits, trafficks and their associates are often the same tactics used by those who beat and abuse their spouses, a.k.a. batters, and can mirror or mimic the dynamics of domestic violence.</p>
      </div>
     </div>
     <div class="col-md-7">
      <div class="trafficked-victus">
       <p>Traffickers use a variety of coercive and manipulative methods to control their victims including, but not limited to:</p>
       <ul>
           <li>Luring their victims with false promises of economic opportunity  </li>
           <li> Withholding identification, work authorization, or travel documents</li>
           <li>Demanding repayment for a real or alleged debt </li>
           <li>Using or threatening to use violence </li>
           <li>Monitoring and surveillance activities</li>
           <li>Paying very little or not paying at all for work</li>
       </ul>
      </div>
     </div>
     <div class="col-md-5">
    <div class="paying-little-images">
     <img src="../public/front/images/psychological-section.png" alt="">
    </div>
     </div>
   </div>
 </div>
</section>
<!-- ens section  -->
<section class="human-under-background">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="second-human-trafficking trafficked-victus">
          <h2 class="may-headind">Trafficked Victims May:</h2>
          <ul>
            <li>Be forced to live in subpar conditions (living in the same place as they work; living in a space that does not have heat, running water, or electricity; living with many people sharing the same, small space) </li>
            <li>Not be allowed to talk to anyone alone or without supervision</li>
            <li>Be coached on how to respond to inquiries from others including police and other authority figures</li>
          </ul>
        </div>
      </div>
    </div>
    <div class="row minimum-united">
      <div class="col-md-12">
        <div class="second-human-trafficking trafficked-victus">
        <h2>Regardless Of Immigration Status, All People That Work In The United States Have The Right To:</h2>
         <ul>
           <li>Be paid at least a minimum wage</li>
           <li>A safe and healthy workplace</li>
           <li>ot be held in a job against their will </li>
           <li>Keep their passport and other identification documents in their possession</li>
           <li>Report abuse without retaliation</li>
           <li>Leave an abusive employment situation </li>
           <li>Get help from unions, immigrant and labor rights groups, and other organizations</li>
         </ul>
        </div>
      </div>
        </div>
        <div class="row">
        <div class="col-md-12">
        <div class="second-human-trafficking trafficked-victus">
          <h2 class="statistics-headind">Statistics And Facts</h2>
          <p class="national-human">National Human Trafficking Statistics</p>
          <ul>
            <li>24.9 million people are victims of forced labor. (ILO, 2017)</li>
            <li>16 million people are trafficked for forced labor in the private economy. (Private economy includes: private individuals, groups, or companies in all sectors except the commercial sex industry). (ILO, 2017)</li>
            <li>4.8 million people are trafficked for forced sexual exploitation. (ILO, 2017) </li>
            <li>4.1 million people are trafficked for forced labor in state-imposed forced labor.It is estimated that 20.9 million people are trafficked worldwide. (ILO, 2017)</li>
            <li>Women and girls are disproportionately affected by human trafficking, accounting for 71% of all victims. (ILO, 2017)</li>
          </ul>
        </div>
        <div class="row labor-backpage">
          <div class="col-md-12">
        <div class="trafficked-victus">
          <p class="national-human"> Labor Trafficking Statistics</p>
          <ul>
            <li>Forced labor in the private economy generates an estimated $150 billion in illegal profits per year. (ILO, 2012) </li>
            <li>The largest share of labor trafficked adults are domestic workers (24%) followed by construction (18%), manufacturing (15%), and agriculture and fishing (11%) sectors. (ILO, 2017)</li>
            <li>Migrant workers and indigenous people are particularly vulnerable to forced labor. (ILO, 2017)</li>
          </ul>
        </div>
      </div>
    </div>
    <div class="row">
    <div class="col-md-6">
      <div class="trafficked-victus">
      <p class="national-human" >Sex Trafficking Statistics</p>
      <ul>
        <li>Forced labor in the private economy generates an estimated $150 billion in illegal profits per year. (ILO, 2012) </li>
        <li>The largest share of labor trafficked adults are domestic workers (24%) followed by construction (18%), manufacturing (15%), and agriculture and fishing (11%) sectors. (ILO, 2017)</li>
        <li>Migrant workers and indigenous people are particularly vulnerable to forced labor. (ILO, 2017)</li>
      </ul>
      </div>
    </div>
    <div class="col-md-6">
    <div class="forced-image">
    <img src="../public/front/images/human-traffing-chart.png" alt="">
    </div>
    </div>
    </div>
  </div>
</section>

@include('layouts.front.include.footer')