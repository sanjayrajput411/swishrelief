@include('layouts.front.include.header')

<section class="forum-main-banner">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="contact-heading forum-heading">
          <h1>All Categories</h1>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- end banner section -->
<section class="table-past-main">
  <div class="container">
    <div class="row linesss sdbs" style="border-bottom: 1px solid gray;">
      <div class="col-md-8">
        <div class="newpost-blog sdbs">
          <ul>
            <li> <select id="dropDown">
                <option value="">--Select Category--</option>
                @foreach ($cat_data as $row)

                <option value="{{url('front/category/'.$row->id)}}" {{ ($row->id == $category_id) ? 'selected' : '' }}><p>{{$row->category_name}}</p></option>
                @endforeach
              </select></li>
            <li><a href="{{url('front/all-post')}}">All Posts</a></li>
            <!-- <li><a href="{{url('front/my-post')}}">My Posts</a></li> -->
          </ul>
        </div>
      </div>
      <div class="col-md-4">
        <div class="search-create-post">
          <ul>
            <li>
              <form action="{{ url('searchbycid') }}" method="GET" style="display: flex;">
                <input type="text" name="search" required />
                <input type="hidden" name="category_id" value="{{ $category_id }}" required /> 
                <button type="submit">Search</button>
              </form>
              <!-- <i class="fa fa-search"></i><input type="text" placeholder="Search.." name="search"> -->
            </li>
            <ul>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col-md-12 text-center my-5">
        <h2>{{$category->category_name}}</h2>
        <p>{{$category->category_description}}</p>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="mark-read sdbs" style="transform: translateY(10px);">
          <div class="right" style="float: left;width: 50%;">
            <p>{{$category->category_name}}</p>
          </div>
          <div class="all-posts" style="width: 15%;">
            <a href="{{url('front/create-post/')}}/{{ $category_id}}">
              <button type="button" name="button">Create New Post</button></a>
          </div>
        </div>

        <div class="table-responsive sdbs cattab">
        <table class="table caption-top">
          <thead>
            <tr class="main-headiing-table">
              <th></th>
              <th class="chat-box"><i class="fa fa-comment" aria-hidden="true"></i></th>
              <th class="chat-box"><i class="fa fa-eye" aria-hidden="true"></i></th>
              <!-- <th class="chat-box"><i class="fa fa-heart" aria-hidden="true"></i></th> -->
              <th class="recent">Recent actives</th>
            </tr>

          </thead>
          <tbody>

            @foreach($data as $data)

            <tr class="all-class-same">
              <td class="example"><a class="titllee" href="{{url('front/title/'.$data->id)}}" style="color: inherit;
text-decoration: inherit;">{{$data->post_name}}</a> <br>
 <!-- <a href="{{url('front/profile/'.$data->user_id)}}"> -->
  <i class="fa fa-user-circle" aria-hidden="true">

  <!-- </a> -->
</i><span style="font-size: 18px;margin-left: 7px;">{{$data->name}}</td>

              <?php //print_r($data);die;
              ?>
              <td class="take-communtity">{{$data->comment_count}}</td>
              <td class="take-communtity">{{$data->viewcount}}</td>
              <td class="take-july">{{Carbon\Carbon::parse($data->updated_at)->format('D, d M Y') }}</td>
              <!-- <td><i class="fa fa-ellipsis-v" aria-hidden="true"></i></td> -->
            </tr>

            @endforeach
          </tbody>
        </table>
        </div>
      </div>
    </div>
  </div>
</section>

<script>
  /* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
  function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
  }

  // Close the dropdown if the user clicks outside of it
  window.onclick = function(event) {
    if (!event.target.matches('.dropbtn')) {
      var dropdowns = document.getElementsByClassName("dropdown-content");
      var i;
      for (i = 0; i < dropdowns.length; i++) {
        var openDropdown = dropdowns[i];
        if (openDropdown.classList.contains('show')) {
          openDropdown.classList.remove('show');
        }
      }
    }
  }
</script>
<script>
  var dropDownValue = document.getElementById("dropDown");

  dropDownValue.onchange = function() {
    if (this.selectedIndex !== 0) {
      window.location.href = this.value;
    }
  };
</script>
<style>
  .dropbtn {
    background-color: #3498DB;
    color: white;
    padding: 16px;
    font-size: 16px;
    border: none;
    cursor: pointer;
  }

  .dropbtn:hover,
  .dropbtn:focus {
    background-color: #2980B9;
  }

  .dropdown {
    position: relative;
    display: inline-block;
  }

  .dropdown-content {
    display: none;
    position: absolute;
    background-color: #f1f1f1;
    min-width: 160px;
    overflow: auto;
    box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
    z-index: 1;
  }

  .dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
  }

  .dropdown a:hover {
    background-color: #ddd;
  }

  .show {
    display: block;
  }
</style>
@include('layouts.front.include.footer')