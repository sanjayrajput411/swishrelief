

@include('layouts.front.include.header')


<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" rel="stylesheet" type="text/css" />

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>







<!-- start banner section -->

<section class="newforum-main-banner">

  <div class="container">

    <div class="row">

    <div class="col-md-12">

      <div class="contact-heading">

        <h1>All Posts</h1>

      </div>

    </div>

  </div>

  </div>

</section>

<section class="newforum-sec1">

  <div class="container">

    <table id="example" class="table" style="width:100%">
          <thead>
              <tr>
                  <th>No</th>
                  <th>Title</th>
                  <th>Category</th>
                  <th>View</th>
              </tr>
          </thead>
          <tbody>
              <tr>
                  <td>1</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td><button class="view-eye"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;View</button></td>
              </tr>
              <tr>
                  <td>2</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td><button class="view-eye"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;View</button></td>
              </tr>
              <tr>
                  <td>3</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td><button class="view-eye"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;View</button></td>
              </tr>
              <tr>
                  <td>4</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td><button class="view-eye"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;View</button></td>
              </tr>
              <tr>
                  <td>1</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td><button class="view-eye"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;View</button></td>
              </tr>
              <tr>
                  <td>2</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td><button class="view-eye"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;View</button></td>
              </tr>
              <tr>
                  <td>3</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td><button class="view-eye"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;View</button></td>
              </tr>
              <tr>
                  <td>4</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td><button class="view-eye"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;View</button></td>
              </tr>
              <tr>
                  <td>1</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td><button class="view-eye"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;View</button></td>
              </tr>
              <tr>
                  <td>2</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td><button class="view-eye"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;View</button></td>
              </tr>
              <tr>
                  <td>3</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td><button class="view-eye"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;View</button></td>
              </tr>
              <tr>
                  <td>4</td>
                  <td>System Architect</td>
                  <td>Edinburgh</td>
                  <td><button class="view-eye"><i class="fa fa-eye" aria-hidden="true"></i>&nbsp;View</button></td>
              </tr>
              
              
          </tbody>
          
    </table>

  </div>
</section>




@include('layouts.front.include.footer')

<script>
  $(document).ready(function () {
    $('#example').DataTable();
});
</script>

