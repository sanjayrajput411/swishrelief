<!DOCTYPE html>
<html>
<head>
    <title>powerofourvoice</title>
</head>
<body>
    <h1>{{ $mailData['title'] }}</h1>
    <p>{{ $mailData['body'] }}</p>
     
    <p>Thank you</p>
</body>
</html>