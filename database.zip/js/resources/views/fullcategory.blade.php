@include('layouts.admin.header')
@include('layouts.admin.sidebar')

<!DOCTYPE html>

<html>

<head>

    <title>Dashboard | Category</title>

    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />

    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet"> -->

    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>

    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>


    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css">
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
    <style>
        .box {
            width: 100px;
            height: 100px;
            border: 1px solid #80808070;
            border-radius: 10px;
        }

        .content {
            display: flex;
        }

        .text {
            width: 70%;
            margin: 0 25px;
        }

        .edit-btn button {
            background: skyblue;
            border: none;
            padding: 10px;
            width: 85px;
            border-radius: 20px;
            color: white;
        }

        .delete-btn button {
            background: skyblue;
            border: none;
            padding: 10px;
            width: 85px;
            border-radius: 20px;
            color: white;
        }
    </style>
</head>

<body>



    <div class="container" style="max-width: calc(1440px - calc(1.625rem * 2));
    width: 80%;
    margin-right: 0px;
    float: right;
}">

        <select class="national_inmate_change">

            <option value="">--Select Category--</option>
            @foreach($categ as $cates)

            <option value="{{$cates->cate_name}}">{{$cates->cate_name}}</option>
            @endforeach
        </select>
       
        <a class="btn btn-success" href="{{url('/importFile')}}" 
        style="float: right;margin: 15px;background: #007bff;border: none;"> Add Resource</a>


        <br><br><br>
 
        <table id="example" class="table table-striped table-bordered table-hover" >
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Keyword</th>
                    <th>Link</th>

                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php //print_r($all_cat_info);die;?>
            @foreach  ($all_cat_info as $cate)
                <tr>
                    <td>{{ $cate->Title_of_Educational_Resource }}</td>
                    <td>{{ $cate->author }}</td>
                    <td>{{ $cate->keywords }}</td>
                    <td>{{ $cate->link }}</td>
                    <td>
                    <!-- <button type="button"  class="btn btn-small btn-info" data-toggle="modal" data-target="#exampleModal" data-whatever="@mdo">
                        Edit </button> -->
                        <a href="{{ url('/edit/' . $cate->id) }}" data-toggle="modal" data-target="#exampleModal" class="btn btn-small btn-info">Edit</a>
                        <a class="btn btn-small btn-danger" href="{{ url('cate-delete/' . $cate->id) }}">Delete</a>
                    </td>
             
                </tr>
                @endforeach
            </tbody>
        </table>

    </div>


 <form  action="{{url('update-form/'.$cate->id) }}" method="POST" enctype="multipart/form-data"> 
 @csrf
@Method('PUT')
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Title:</label>
            <input type="text" class="form-control" id="recipient-name" name="Title_of_Educational_Resource" value="{{$cate->Title_of_Educational_Resource}}">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Author:</label>
            <input type="text" class="form-control" id="recipient-name" name="author" value="{{$cate->author}}">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Keyword:</label>
            <input type="text" class="form-control" id="recipient-name" name="keywords" value="{{$cate->keywords}}">
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Link:</label>
            <input type="text" class="form-control" id="recipient-name" name="link" value="{{$cate->link}}">
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" value="Submit"  class="btn btn-primary">Update</button>
      </div>
    </div>
  </div>
</div>
</form>


</body>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
 <!-- <script>
    $( document ).ready(function(e) {
        e.preventDefault();
    $('#exampleModal').on('show.bs.modal', function () {
    
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})
});
 </script> -->

<script type="text/javascript">
    $(function() {
        $("select").change(function() {
            var cates_name = $(this).val();
            console.log(cates_name);
            window.location.href = "http://powerofourvoice.netmaxims.in/fullcategory?cates_name=" + cates_name;
           //   window.location.href = appBaseUrl+'/fullcategory?cates_name='+ cates_name;
        });
    });
	
$(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
             'csv', 'excel', 
        ]
    } );
} );
</script>



</html>
@include('layouts.admin.footer')