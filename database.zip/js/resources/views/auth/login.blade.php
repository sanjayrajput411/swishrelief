@include('layouts.front.include.header')  <!-- end navbar -->
   <section class="main-banner">
    <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="sign-main">
        <h1>Log in</h1>
      <!-- <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform. Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p> -->
    </div>
    </div>
  </div>
</div>
</section>
<!-- end banner section -->
<!-- start main section  -->
<section class="main-form">
  <div class="container">
   <div class="we-offer">
    <div class="row">
      <div class="col-md-6">
      <div class="login-member login-sign-2">
        <!-- <h2>Log in</h2> -->
       <p>Log In </p>
            <form method="POST" action="{{ route('login') }}">
                        @csrf

            <div class="input-icon">
              <div>
                <i class="fa fa-user"></i>
                                                <input id="email" type="email" class="input-field @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" placeholder="email address" autofocus>
                                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror

               </div>

               <div>
                <i class="fa fa-lock" aria-hidden="true"></i>
                <input id="password" type="password" class="input-field @error('password') is-invalid @enderror" name="password" required autocomplete="current-password" placeholder="password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                <p><a href="{{url('/forgot-password')}}">Forgot your password</a></p>
              </div>
              <div>
              <input type="submit" value="LOG IN">
              </div>
             
               </div>
                </form>
                 </div>
                 <div class="sign-here">
                 <h5>Don’t have an account? <a href="{{url('/front/sign-up')}}">Signup here.</a></h5>
                 <!-- <h5>Don’t have an account? <a href="{{url('/front/sign-in-by')}}">Signup here.</a></h5> -->
               </div>
                 </div>
          <div class="col-md-6">
         <div class="social-reform">
        <img src="{{asset('front/images/search-mojar.png')}}">
        <h2>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform.</h2>
        <p>Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>
   </div>
  </div>
</div>
</div>
</div>
</section>
<!-- end section -->

@include('layouts.front.include.footer')

<!-- footer section start -->
<!-- start newsletter -->

<!-- <section class="newsletter-main">

<div class="container">

  <div class="row">

    <div class="col-md-6">

  <div class="newsletter-heading">

 <h2>Subscribe To Get My Newsletter</h2>

</div>

</div>

<div class="col-md-6">

 <div class="newsletter-input-field">

 <ul>

      <li><input type="text" placeholder="Enter your email here*" name="mail" required="">

     <button type="submit">Join</button></li>

    </ul>

</div>

</div>

</div>

</section>

 end news letter -->


<!--<section class="footer-main-class">

  <div class="container">

    <div class="row">

      <div class="col-md-4">

      <div class="footer-second">

     <img src="public/front/images/footer-logo.png">

     <button type="submit">Book a Consultation</button></li>

      </div>

    </div>

    <div class="col-md-2">

    <div class="footer-second">

    <h2>Quick Links</h2>

    <ul>

      <li>About us</li>

      <li>Services</li>

      <li>Appointment</li>

      <li>Blog</li>

      <li>Contact</li>

    </ul>

    </div>

  </div>

  <div class="col-md-2">

  <div class="footer-second">

      <h2>Service Links</h2>

      <ul>

        <li>About us</li>

        <li>Forums</li>

        <li>Plans & Pricing</li>

        <li>Re-entry</li>

        <li>Videos</li>

      </ul>

  </div>

</div>

<div class="col-md-4">

<div class="footer-second">

  <h2 class="left">Contact</h2>

  <ul class="address-section">

   <li> <i class="fas fa-map-marker-alt"></i> 1790 Hadley Road , Lapeer, Michigan 48446 <span>Mailing Address: </span><br>2510 Royal Acres Dr, Denton, Texas 76209</li>

    <li><i class="fa fa-envelope"></i>Email info@powerofourvoices.com</li>

    <li><i class="fa fa-phone-alt"></i>(231) 598-8498</li>

  </ul>

  <ul class="social-icon">

    <li>

      <i class="fab fa-facebook-f"></i>

      <i class="fab fa-twitter"></i>

      <i class="fab fa-instagram"></i>

    </li></li>
  </ul>

</div>

</div>

  </div>

</div>

</section> -->

<!-- end footer section -->

<!-- <div class="copyright">

  <p>© 2022 by Power Of Our Voices. | Designed & Developed by Netmaxims</p>

</div>


</body>
</html>


<script type="text/javascript">
         $(function() {
             var url = window.location.href;
             // alert(url);
             $("#menus a").each(function() {
                 if (url == (this.href)) {
                     $(this).closest("li").addClass("actives");

                 } else {
                     $(this).closest("li").removeClass("actives");
                 }

             });
         });
      </script> -->
