@include('layouts.header')

@include('layouts.sidebar')
<h3 style="margin-top: 55px;">Update Post</h3>



<div style="padding-left: 15%;">
<h3 style="margin-top: 55px;">Update Post</h3>
  <form name="myForm" action="{{url('admin/update/'.$data->id) }}" method="POST" enctype="multipart/form-data">

    @csrf

    @Method('PUT')

    <label for="country">Post Name</label>

    <input type="text" class="form-control" name="post_name" placeholder="Post Name" value="{{$data->post_name}}" />

    <label for="country">Category Name</label>

    <select name="category_id" class="form-control" value="{{$data->category_id}}" />



    @foreach ($ndata as $row)

    <option value="{{ $row->id }}">{{ $row->category_name }}</option>

    @endforeach

    </select>



    <label for="lname">Post Date</label>
<?php //echo'<pre>';print_r($data);die;?>
    <input type="date"  id="post_date" name="post_date" placeholder="" value="{{$data->post_date}}">

    <label for="country">Description</label>

    <textarea name="description" id="description" cols="45" rows="8" value="{{$data->description}}" />{{$data->description}}</textarea>

    <input type="Submit" value="Update">

  </form>

</div>


<link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css
" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js
"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<link href="{{url('public/front/css/editor/summernote.css')}}">
<script src="{{url('public/front/css/editor/summernote.js')}}"></script>
<script>
  $(document).ready(function() {
    $('#description').summernote();
  });
</script>
<style>
  input[type=text],
  select {

    width: 100%;

    padding: 12px 20px;

    margin: 8px 0;

    display: inline-block;

    border: 1px solid #ccc;

    border-radius: 4px;

    box-sizing: border-box;

  }

  input[type=file],
  select {

    width: 100%;

    padding: 12px 20px;

    margin: 8px 0;

    display: inline-block;

    border: 1px solid #ccc;

    border-radius: 4px;

    box-sizing: border-box;

  }

  input[type=date],
  select {

    width: 100%;

    padding: 12px 20px;

    margin: 8px 0;

    display: inline-block;

    border: 1px solid #ccc;

    border-radius: 4px;

    box-sizing: border-box;

  }

  input[type=textarea],
  select {

    width: 100%;

    padding: 12px 20px;

    margin: 8px 0;

    display: inline-block;

    border: 1px solid #ccc;

    border-radius: 4px;

    box-sizing: border-box;

  }

  input[type=submit] {

    width: 100%;

    background-color: #4CAF50;

    color: white;

    padding: 14px 20px;

    margin: 8px 0;

    border: none;

    border-radius: 4px;

    cursor: pointer;

  }



  input[type=submit]:hover {

    background-color: #45a049;

  }



  div {}

  .switch {

    position: relative;

    display: inline-block;

    width: 60px;

    height: 34px;

  }



  .switch input {

    opacity: 0;

    width: 0;

    height: 0;

  }



  .slider {

    position: absolute;

    cursor: pointer;

    top: 0;

    left: 0;

    right: 0;

    bottom: 0;

    background-color: #ccc;

    -webkit-transition: .4s;

    transition: .4s;

  }



  .slider:before {

    position: absolute;

    content: "";

    height: 26px;

    width: 26px;

    left: 4px;

    bottom: 4px;

    background-color: white;

    -webkit-transition: .4s;

    transition: .4s;

  }



  input:checked+.slider {

    background-color: #2196F3;

  }



  input:focus+.slider {

    box-shadow: 0 0 1px #2196F3;

  }



  input:checked+.slider:before {

    -webkit-transform: translateX(26px);

    -ms-transform: translateX(26px);

    transform: translateX(26px);

  }



  /* Rounded sliders */

  .slider.round {

    border-radius: 34px;

  }



  .slider.round:before {

    border-radius: 50%;

  }



  /* .upload__box {

  padding: 40px;

} */

  .upload__inputfile {

    width: 0.1px;

    height: 0.1px;

    opacity: 0;

    overflow: hidden;

    position: absolute;

    z-index: -1;

  }

  .upload__btn {

    display: inline-block;

    font-weight: 600;

    color: #fff;

    text-align: center;

    min-width: 116px;

    padding: 5px;

    transition: all 0.3s ease;

    cursor: pointer;

    border: 2px solid;

    background-color: #373748;

    border-color: #373748;

    border-radius: 10px;

    line-height: 26px;

    font-size: 14px;

  }

  .upload__btn:hover {

    background-color: #a1a1d1;

    color: black;

    transition: all 0.3s ease;

    border: #a1a1d1;

  }

  .upload__btn-box {

    margin-bottom: 10px;

  }

  .upload__img-wrap {

    display: flex;

    flex-wrap: wrap;

    margin: 0 -10px;

  }

  .upload__img-box {

    width: 200px;

    padding: 0 10px;

    margin-bottom: 12px;

  }

  .upload__img-close {

    width: 24px;

    height: 24px;

    border-radius: 50%;

    background-color: rgba(0, 0, 0, 0.5);

    position: absolute;

    top: 10px;

    right: 10px;

    text-align: center;

    line-height: 24px;

    z-index: 1;

    cursor: pointer;

  }

  .upload__img-close:after {

    content: "✖";

    font-size: 14px;

    color: white;

  }



  .img-bg {

    background-repeat: no-repeat;

    background-position: center;

    background-size: cover;

    position: relative;

    padding-bottom: 100%;

  }
</style>
@include('layouts.footer')