@include('layouts.admin.header')

@include('layouts.admin.sidebar')

<head>



  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />

  <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">

  <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>

  <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>

  <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>



</head>

<style>
  .switch {

    position: relative;

    display: inline-block;

    width: 60px;

    height: 34px;

  }



  .switch input {

    opacity: 0;

    width: 0;

    height: 0;

  }



  .slider {

    position: absolute;

    cursor: pointer;

    top: 0;

    left: 0;

    right: 0;

    bottom: 0;

    background-color: #ccc;

    -webkit-transition: .4s;

    transition: .4s;

  }



  .slider:before {

    position: absolute;

    content: "";

    height: 26px;

    width: 26px;

    left: 4px;

    bottom: 4px;

    background-color: white;

    -webkit-transition: .4s;

    transition: .4s;

  }



  input:checked+.slider {

    background-color: #2196F3;

  }



  input:focus+.slider {

    box-shadow: 0 0 1px #2196F3;

  }



  input:checked+.slider:before {

    -webkit-transform: translateX(26px);

    -ms-transform: translateX(26px);

    transform: translateX(26px);

  }



  /* Rounded sliders */

  .slider.round {

    border-radius: 34px;

  }



  .slider.round:before {

    border-radius: 50%;

  }

  a.selected {

    background-color: #1F75CC;

    color: white;

    z-index: 100;

  }



  .messagepop {

    background-color: #FFFFFF;

    border: 1px solid #999999;

    cursor: default;

    display: none;

    margin-top: 15px;

    position: absolute;

    text-align: left;

    width: 394px;

    z-index: 50;

    padding: 25px 25px 20px;

  }



  label {

    display: block;

    margin-bottom: 3px;

    padding-left: 15px;

    text-indent: -15px;

  }



  .messagepop p,
  .messagepop.div {

    border-bottom: 1px solid #EFEFEF;

    margin: 8px 0;

    padding-bottom: 8px;

  }
</style>





<form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">

  @csrf

</form>

<body>



  <div class="container" style="max-width: calc(1440px - calc(1.625rem * 2));width: 80%;margin-right: 0px;float: right;">

    <h1>Post List</h1><br>
    <a class="btn btn-success" href="{{url('admin/post')}}" id="createNewProduct" style="float: right;margin: 15px;background: #007bff;border: none; margin-top: -60px;"> Add Post</a>


    <table class="table table-bordered data-table" id="data-table" style="/*! margin-left: 200px; */ width: 1040px;">



      <thead>



        <tr>







          <th>Post Name</th>




          <th>Post Date</th>



          <th>Action</th>



        </tr>



      </thead>



      <tbody>



      </tbody>



    </table>

  </div>







  </div>



  <!-- <a href="/contact" id="contact">Contact Us</a> -->

</body>







<script type="text/javascript">
  $(function() {



    var table = $('.data-table').DataTable({

      processing: true,



      serverSide: true,

      "ajax": {



        "type": "POST"

      },

      ajax: "{{ url('get-post-list') }}",



      columns: [







        {
          data: 'post_name',
          name: 'post_name'
        },



        //    {data: 'description', name: 'category_name'},



        {
          data: 'post_date',
          name: 'post_date'
        },



        {
          data: 'action',
          name: 'action',
          orderable: false,
          searchable: false
        },







      ]



    });









  });
</script>
<script>
  function confirmation() {
    var result = confirm("Are you sure to delete?");
    if (result) {
      console.log("Deleted")
    }
  }
</script>