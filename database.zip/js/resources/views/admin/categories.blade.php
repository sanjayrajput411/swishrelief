@include('layouts.admin.header')
@include('layouts.admin.sidebar')
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

<style>
.box {
  width: 100px;
  height: 100px;
  border: 1px solid #80808070;
  border-radius: 10px;
}

.content {
  display: flex;
}

.text {
  width: 70%;
  margin: 0 25px;
}

.edit-btn button {
  background: skyblue;
  border: none;
  padding: 10px;
  width: 85px;
  border-radius: 20px;
  color: white;
}

.delete-btn button {
  background: skyblue;
  border: none;
  padding: 10px;
  width: 85px;
  border-radius: 20px;
  color: white;
}
</style>
</head>
  <body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
       @include('layouts.admin.sidebar')
        <div class="layout-page">
        <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
               <ul class="navbar-nav flex-row align-items-center ms-auto">
               <li class="nav-item navbar-dropdown dropdown-user dropdown">
                <button
                          class="btn btn-primary"
                          type="button"
                          data-bs-toggle="offcanvas"
                          data-bs-target="#offcanvasScroll"
                          aria-controls="offcanvasScroll"
                          style="background:skyblue;margin-right: 18px;margin-top: 20px;"
                          data-toggle="modal" data-target="#exampleModal" data-whatever="@getbootstrap" >
                        Add Category
                        </button>
                  </ul>
                </li>
            </div>
          </nav>
          <div class="content-wrapper">
            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light"></span> Categories</h4>

              <div class="card mb-4">
                
                <h5 class="card-header">Forum info</h5>
                <p style="margin-left:18px;">Customize your forum’s name, the header shown when there’s more than one category, and the forum guidelines.</p>
                
                <div class="card-body">
                  <div class="content">
                    <div class="box"></div>
                    <div class="text">
                        <h3>Forum</h3>
                        <p>Welcome! Have a look around and join the discussions.</p>
                    </div>
                    <!-- <div class="edit-btn">
                        <button>Edit</button>
                    </div>
                    <div class="delete-btn">
                        <button>...</button>
                    </div> -->
                  </div>
                </div>
              </div>

              <div class="card">
                <h5 class="card-header">Categories</h5>
                <div class="card-body">
                  <div class="row gy-3">
                  <div class="container">
                   <table class="table">
              <tbody>
            @foreach($data as $data)
				<tr>
            <td>{{$data->category_name}}</td>
            <td>{{$data->category_description}}</td>
            <td><a href="{{ route('updatecateogory', $data->id) }}" class="edit-btn"><button>Update</button></a>
            <a href="{{ route('deleteCategory', $data->id) }}" class="delete-btn"><button>Delete</button></a>
               </td>
        </tr>
 </tbody >
@endforeach
  </table>
</div>
</div>
</div>
 </div>
</div>               
                

<!--/Add Category Popup -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Category info</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        </button>
      </div>
      <form action="{{url('add-categories') }}" method="POST" enctype="multipart/form-data">
	      @csrf
          <div class="modal-body">
          <div class="form-group">
          <label for="recipient-name" class="col-form-label">Category Name:</label>
          <input type="text" class="form-control"  name="category_name"  >
          </div>
          <div class="form-group">
          <label for="message-text" class="col-form-label">Category Description:</label>
          <input type="text"  class="form-control" name="category_description" >
          </div>
          <div class="modal-footer">
          <input type="submit" class="btn btn-primary"  value="Submit">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
         </form> 
      </div>
    </div>
 </div>


<script type="text/javascript">
$('#exampleModal').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
 // modal.find('.modal-title').text('Category info ')
 // modal.find('.modal-body input').val(recipient)
})
</script>
