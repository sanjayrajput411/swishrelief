@include('layouts.header')

@include('layouts.sidebar')





<!DOCTYPE html>



<html>



<head>



    <title>Laravel Ajax CRUD Tutorial Example - ItSolutionStuff.com</title>



    <meta name="csrf-token" content="{{ csrf_token() }}">



    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />



    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">



    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">



    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  



    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>



    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>



    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>



    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

<!--summernote comment-->

<link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css
" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css
" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js
"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link href="{{url('public/front/css/editor/summernote.css')}}">
<script src="{{url('public/front/css/editor/summernote.js')}}"></script>


    <style>

.box {

  width: 100px;

  height: 100px;

  border: 1px solid #80808070;

  border-radius: 10px;

}



.content {

  display: flex;

}



.text {

  width: 70%;

  margin: 0 25px;

}



.edit-btn button {

  background: skyblue;

  border: none;

  padding: 10px;

  width: 85px;

  border-radius: 20px;

  color: white;

}



.delete-btn button {

  background: skyblue;

  border: none;

  padding: 10px;

  width: 85px;

  border-radius: 20px;

  color: white;

}

.switch {

  position: relative;

  display: inline-block;

  width: 60px;

  height: 34px;

}



.switch input { 

  opacity: 0;

  width: 0;

  height: 0;

}



.slider {

  position: absolute;

  cursor: pointer;

  top: 0;

  left: 0;

  right: 0;

  bottom: 0;

  background-color: #ccc;

  -webkit-transition: .4s;

  transition: .4s;

}



.slider:before {

  position: absolute;

  content: "";

  height: 26px;

  width: 26px;

  left: 4px;

  bottom: 4px;

  background-color: white;

  -webkit-transition: .4s;

  transition: .4s;

}



input:checked + .slider {

  background-color: #2196F3;

}



input:focus + .slider {

  box-shadow: 0 0 1px #2196F3;

}



input:checked + .slider:before {

  -webkit-transform: translateX(26px);

  -ms-transform: translateX(26px);

  transform: translateX(26px);

}



/* Rounded sliders */

.slider.round {

  border-radius: 34px;

}



.slider.round:before {

  border-radius: 50%;

}



/* .upload__box {

  padding: 40px;

} */

.upload__inputfile {

  width: 0.1px;

  height: 0.1px;

  opacity: 0;

  overflow: hidden;

  position: absolute;

  z-index: -1;

}

.upload__btn {

  display: inline-block;

  font-weight: 600;

  color: #fff;

  text-align: center;

  min-width: 116px;

  padding: 5px;

  transition: all 0.3s ease;

  cursor: pointer;

  border: 2px solid;

  background-color: #373748;

  border-color: #373748;

  border-radius: 10px;

  line-height: 26px;

  font-size: 14px;

}

.upload__btn:hover {

    background-color: #a1a1d1;

    color: black;

    transition: all 0.3s ease;

    border: #a1a1d1;

}

.upload__btn-box {

  margin-bottom: 10px;

}

.upload__img-wrap {

  display: flex;

  flex-wrap: wrap;

  margin: 0 -10px;

}

.upload__img-box {

  width: 200px;

  padding: 0 10px;

  margin-bottom: 12px;

}

.upload__img-close {

  width: 24px;

  height: 24px;

  border-radius: 50%;

  background-color: rgba(0, 0, 0, 0.5);

  position: absolute;

  top: 10px;

  right: 10px;

  text-align: center;

  line-height: 24px;

  z-index: 1;

  cursor: pointer;

}

.upload__img-close:after {

  content: "✖";

  font-size: 14px;

  color: white;

}



.img-bg {

  background-repeat: no-repeat;

  background-position: center;

  background-size: cover;

  position: relative;

  padding-bottom: 100%;

}



</style>

</head>



<body>

  <a class="btn btn-primary" style="text-align: right;font-size: 15px;" href="{{ route('logout') }}"

                                       onclick="event.preventDefault();

                                                     document.getElementById('logout-form').submit();">

                                        {{ __('Logout') }}

                    </a>

					<form id="logout-form"   action="{{ route('logout') }}" method="POST" class="d-none">

                        @csrf

                </form>

<div class="container" style="max-width: calc(1440px - calc(1.625rem * 2));

    width: 80%;

    margin-right: 0px;

    float: right;

}">



    <h1 style="  float: left;">Create Post</h1>



     <a class="btn btn-success" href="javascript:void(0)" id="createNewProduct" style="float: right;

margin: 15px;

background: #007bff;

border: none;"> Create New Post</a>



    <table class="table table-bordered data-table" style="    max-width: calc(1440px - calc(1.625rem * 2));

    width: 101%;">



        <thead>



            <tr>

            <th>No</th>

                <th>post Name</th>

               <th>Description</th> 



                <th width="280px">Action</th>



            </tr>



        </thead>



        <tbody>



        </tbody>



    </table>



</div>



     



<div class="modal fade" id="ajaxModel" aria-hidden="true">



    <div class="modal-dialog">



        <div class="modal-content">



            <div class="modal-header">



                <h4 class="modal-title" id="modelHeading"></h4>



            </div>



            <div class="modal-body">



                <form id="productForm" name="productForm" class="form-horizontal">



                   <input type="hidden" name="id" id="id">



                    <div class="form-group">



                        <label for="name" class="col-sm-4 control-label">Title</label>



                        <div class="col-sm-12">



                            <input type="text" class="form-control" id="post_name" name="post_name" placeholder="Enter Name" value="" maxlength="50" required="">



                        </div>



                    </div>



                    <div class="form-group">



                        <label for="name" class="col-sm-4 control-label">Category Name</label>



                        <div class="col-sm-12">



                          <select  name="category_id"  id="category_id" class="form-control" />

                        <option value="">-- Select category --</option>

							 @foreach ($ndata as $row)

                          <option value="{{ $row->id }}">{{ $row->category_name }}</option>

                             @endforeach

                               </select>

                      </div>



                    </div>



                    <div class="form-group">


<!-- 
<label for="name" class="col-sm-2 control-label">Image</label> -->



<div class="col-sm-12">



<!-- <div class="card-body">

                                	<div class="upload__box">

                                        <div class="upload__btn-box">

                                          <label class="upload__btn">

                                            <p style="margin: 0px;">Upload Images</p>

                                            <input type="file" multiple="" id="image" name="image" data-max_length="20" class="upload__inputfile" >

                                          </label>

                                        </div>

                                        <div class="upload__img-wrap">

                                        </div>

                                      </div>

                                     </div>

</div> -->



</div>

<div class="form-group">



<label class="col-sm-4 control-label">Post Date</label>



<div class="col-sm-12">



<input type="date"  id="post_date"  class="form-control" name="post_date" placeholder="" required/>

</div>



</div>

                    <div class="form-group">



                        <label class="col-sm-4 control-label">Post Description</label>



                        <div class="col-sm-12">



                            <textarea id="description" name="description"  required="" placeholder="Description" class="form-control" ></textarea>



                        </div>



                    </div>



        



                    <div class="col-sm-offset-2 col-sm-10">



                     <button type="submit" class="btn btn-primary" id="saveBtn" value="create">Save changes



                     </button>



                    </div>



                </form>



            </div>



        </div>



    </div>



</div>



      



</body>



      



<script type="text/javascript">



  $(function () {



      



    /*------------------------------------------



     --------------------------------------------



     Pass Header Token



     --------------------------------------------



     --------------------------------------------*/ 



    $.ajaxSetup({



          headers: {



              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')



          }



    });



      



    /*------------------------------------------



    --------------------------------------------



    Render DataTable



    --------------------------------------------



    --------------------------------------------*/



    var table = $('.data-table').DataTable({



        processing: true,



        serverSide: true,



        ajax: "{{ route('post.index') }}",



        columns: [



            {data: 'DT_RowIndex', name: 'DT_RowIndex'},



            {data: 'post_name', name: 'post_name'},


            {data: 'post_date', name: 'post_date'},

            {data: 'action', name: 'action', orderable: false, searchable: false},



        ]



    });



      



    /*------------------------------------------



    --------------------------------------------



    Click to Button



    --------------------------------------------



    --------------------------------------------*/



    $('#createNewProduct').click(function () {



        $('#saveBtn').val("create-product");



        $('#id').val('');



        $('#productForm').trigger("reset");



        $('#modelHeading').html("Create New post");



        $('#ajaxModel').modal('show');



    });



      



    /*------------------------------------------



    --------------------------------------------



    Click to Edit Button



    --------------------------------------------



    --------------------------------------------*/



    $('body').on('click', '.edit', function () {



      var id = $(this).data('id');



      $.get("{{ route('post.index') }}" +'/' + id +'/edit', function (data) {



          $('#modelHeading').html("Edit post");



          $('#saveBtn').val("edit-user");



          $('#ajaxModel').modal('show');



          $('#id').val(data.id);



          $('#post_name').val(data.post_name);



          $('#category_id').val(data.category_id);



          $('#image').val(data.image);



          $('#post_date').val(data.post_date);



          $('#description').val(data.description);

          



      })



    });



      



    /*------------------------------------------



    --------------------------------------------



    Create Product Code



    --------------------------------------------



    --------------------------------------------*/



    $('#saveBtn').click(function (e) {



        e.preventDefault();



        $(this).html('Sending..');



      



        $.ajax({



          data: $('#productForm').serialize(),



          url: "{{ route('post.store') }}",



          type: "POST",



          dataType: 'json',



          success: function (data) {



       



              $('#productForm').trigger("reset");



              $('#ajaxModel').modal('hide');



              table.draw();



           



          },



          error: function (data) {



              console.log('Error:', data);



              $('#saveBtn').html('Save Changes');



          }



      });



    });



      



    /*------------------------------------------



    --------------------------------------------



    Delete Product Code



    --------------------------------------------



    --------------------------------------------*/



    $('body').on('click', '.delete', function () {





        var id = $(this).data("id");



        confirm("Are You sure want to delete !");



        



        $.ajax({



            type: "DELETE",



            url: "{{ route('post.store') }}"+'/'+id,



            success: function (data) {



                table.draw();



            },

            

            error: function (data) {



                console.log('Error:', data);



            }



        });



    });



       



  });



</script>

</html>


<script>
  $(document).ready(function() {
    $('#description').summernote();
  });
</script>
@include('layouts.footer')