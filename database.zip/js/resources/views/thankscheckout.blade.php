@include('layouts.front.include.header')
<style>
.thankyou.neww h1 {
    color: green;
    font-size: 5em;
    font-weight: 600;
}

.thankyou.neww p {
    font-size: x-large;
        color: #FFB300;
}

.thankyou-banner {
  background: #0c3747;
  height: 9em;
}
.thankyou.neww {
  padding: 8em 0;
}
</style>

<section class="thankyou-banner">
    
</section>
<section class="thankyou neww py-5">
	<div class="container text-center">
		<h1>Thank you.</h1>
		<p>Your order successfully completed.</p>
	</div>
</section>

@include('layouts.front.include.footer')