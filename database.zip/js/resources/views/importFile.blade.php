@include('layouts.admin.header')
@include('layouts.admin.sidebar')

<link rel="stylesheet"
        href=
"https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" /> 



    <div class="container" style="padding-left: 13%;
margin-top: 5%;">
@if(Session::has('Success_msg'))
<p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('Success_msg') }}</p>
@endif
        <div class="card bg-light mt-3">
            <div class="card-header">
                Import  Excel 
            </div>
            <div class="card-body">
                <form action="{{ route('import') }}" 
                      method="POST" 
                      enctype="multipart/form-data">
                    @csrf
                    <input type="file" name="file" 
                           class="form-control" required/>
                    <br>
                    <button class="btn btn-success">
                          Import User Data
                       </button>
                       <p class="downlaod_sample">Download sample file <a href="{{ asset('/files/dowanload/excel_formate_resource.xlsx') }}">Click here </a> </p>

                </form>
            </div>
        </div>
    </div>
  

  
