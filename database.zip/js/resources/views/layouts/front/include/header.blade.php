<!doctype html>

<html lang="en">

<head>
    <!-- Required meta tags -->

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!--     <link href="https://netmaxims.in/projects/powerofourvoice/front/css/bootstrap.min.css" rel="stylesheet">
 -->
    <!-- <link href="https://www.1001fonts.com/quattrocento-font.html?text=Power%20of%20Our%20Voices%20LLC" rel="stylesheet">
 -->
    <link href="{{url('front/css/custom.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{url('front/css/responsive.css')}}" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>



    <title>Power Of Our Voices</title>

    <style>
        .modal-backdrop {
    position: inherit !important;
    top: 0;
    left: 0;
    z-index: 1040;
    width: 100vw;
    height: 100vh;
    background-color: #000;
}
    </style>

</head>

<body>

    <!-- navbar start -->

    <header class="header_white">

        <div class="top-bar">

            <div class="container">

                <div class="row horizontal-line">

                    <div class="col-md-6"></div>

                    <div class="col-md-6">

                        <ul>
                            <li><i class="fa fa-phone" aria-hidden="true"></i> <a href="tel:(231) 598-8498"  class="langs">(231) 598-8498</a> </li>

                            <li> <a href="#" class="lang"> <i class="fa fa-facebook" aria-hidden="true"></i></a></li>

                            <li> <a href="#" class="lang"> <i class="fa fa-twitter" aria-hidden="true"></i></a> </li>

                            <li> <a href="#" class="lang"> <i class="fa fa-instagram" aria-hidden="true"></i></a> </li>

                        </ul>

                    </div>
                </div>

            </div>

        </div>

        <nav class="navbar navbar-expand-lg navbar-light">

            <div class="container mobile-nav">

                <a class="navbar-brand" href="#"><img src="{{url('/front/images/power-logo.png')}}"></a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">

                    <span class="navbar-toggler-icon"></span>

                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">

                    <ul class="navbar-nav" id="menus">

                        <li class="nav-item">

                            <a class="nav-link" aria-current="page" href="{{url('front/index')}}">Home</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="{{url('front/pricing')}}">Pricing</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="{{url('front/about-us')}}">About Us</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="{{url('front/contact-us')}}">Contact</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="{{url('front/forum')}}">Forum</a>

                        </li>
                        <li class="nav-item">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle dropbtn" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                    More
                                </button>
                                <ul class="dropdown-menu dropdown-content" aria-labelledby="dropdownMenuButton1">
                                    <a href="{{url('front/government-racism')}}">Government & Racism</a>
                                    <a href="{{url('front/state-re-entry')}}">State re-entry</a>
                                    <a href="{{url('front/general-6')}}">Criminal Justice System</a>
                                    <a href="{{url('front/human-trafficking')}}">Human Trafficking</a>
                                    <a href="{{url('front/hood-vs-suburbs')}}">Hood Vs.Suburbs</a>

                                    @if(Auth::User())
                                    <?php  $active_plan = Session::has('active_plan'); 
                                    if($active_plan > 0){
                                    ?>
                                        <a href="{{url('front/national-inmate-locator')}}">National Inmate Locator{{ Session::has('active_plan')}}</a>                                  
                               <?php }?>
                                   @endif



                                    <a href="{{url('front/government-sexism')}}">Government & sexism</a>
                                    @if(Auth::User())

                                    <a href="{{url('front/user-profile')}}">My Profile</a>


                                    @endif
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            @if(Auth::User())

                            <a class="nav-link" href="{{url('front/user-profile')}}">My Profile</a>


                            @endif
                        </li>

                        <button type="button" class="btn btn-warning mt-2 btn-sm" data-bs-toggle="modal" data-bs-target="#staticBackdrop" style="height: 56%;font-size: 15px;color: #fff;">DONATE</button>

<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Choose amount</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">


      <script src="https://donorbox.org/widget.js" paypalExpress="false"></script><iframe src="https://donorbox.org/embed/power-of-voice" name="donorbox" allowpaymentrequest="allowpaymentrequest" seamless="seamless" frameborder="0" scrolling="no" height="900px" width="100%" style="max-width: 500px; min-width: 250px; max-height:none!important"></iframe>
       
      </div>
    </div>
  </div>
</div>

                        <li class="nav-item">
                            @if(Auth::User())
                            <!-- <a class="nav-link" href="https://netmaxims.in/projects/powerofourvoice/frontened-logout"><button type="button" class="btn btn-success sign-button">Logout</button></a>
--> <a class="nav-link" href="{{url('/frontened-logout')}}"><button type="button" class="btn btn-success sign-button">Logout</button></a>

                            @else
                            <a class="nav-link" href="{{url('/login')}}"><button type="button" class="btn btn-success sign-button">Login</button></a>
                            @endif
                        </li>
                    </ul>
                </div>

            </div>

        </nav>

    </header>
    <script>
        window.onload = function() {
            document.getElementById('logout-form').onclick = function() {
                document.getElementById('logout-form').submit();
                return false;
            };
        };
    </script>


    <script type="text/javascript">
        $(window).scroll(function() {
            if ($(this).scrollTop() > 120) {
                $('.header_white').addClass('fixed');
            } else {
                $('.header_white').removeClass('fixed');
            }
        });
    </script>