<!doctype html>

<html lang="en">

<head>
    <!-- Required meta tags -->

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <!--     <link href="https://netmaxims.in/projects/powerofourvoice/public/front/css/bootstrap.min.css" rel="stylesheet">
 -->
    <!-- <link href="https://www.1001fonts.com/quattrocento-font.html?text=Power%20of%20Our%20Voices%20LLC" rel="stylesheet">
 -->
    <link href="{{url('public/front/css/custom.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{url('public/front/css/responsive.css')}}" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>



    <title>Power Of Our Voices</title>

</head>

<body>

    <!-- navbar start -->

    <header class="header_white">

        <div class="top-bar">

            <div class="container">

                <div class="row horizontal-line">

                    <div class="col-md-6"></div>

                    <div class="col-md-6">

                        <ul>
                            <li><i class="fa fa-phone" aria-hidden="true"></i> <a href="#" class="langs">(231) 598-8498</a> </li>

                            <li> <a href="#" class="lang"> <i class="fa fa-facebook" aria-hidden="true"></i></a></li>

                            <li> <a href="#" class="lang"> <i class="fa fa-twitter" aria-hidden="true"></i></a> </li>

                            <li> <a href="#" class="lang"> <i class="fa fa-instagram" aria-hidden="true"></i></a> </li>

                        </ul>

                    </div>
                </div>

            </div>

        </div>

        <nav class="navbar navbar-expand-lg navbar-light">

            <div class="container mobile-nav">

                <a class="navbar-brand" href="#"><img src="https://netmaxims.in/projects/powerofourvoice/public/front/images/power-logo.png"></a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">

                    <span class="navbar-toggler-icon"></span>

                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">

                    <ul class="navbar-nav" id="menus">

                        <li class="nav-item">

                            <a class="nav-link" aria-current="page" href="{{url('front/index')}}">Home</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="{{url('front/pricing')}}">Pricing</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="{{url('front/about-us')}}">About Us</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="{{url('front/contact-us')}}">Contact</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="{{url('front/forum')}}">Forum</a>

                        </li>
                        <li class="nav-item">
                            <div class="dropdown">
                                <button class="btn btn-secondary dropdown-toggle dropbtn" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                    More
                                </button>
                                <ul class="dropdown-menu dropdown-content" aria-labelledby="dropdownMenuButton1">
                                    <a href="{{url('front/government-racism')}}">Government & Racism</a>
                                    <a href="{{url('front/state-re-entry')}}">State re-entry</a>
                                    <a href="{{url('front/general-6')}}">Criminal Justice System</a>
                                    <a href="{{url('front/human-trafficking')}}">Human Trafficking</a>
                                    <a href="{{url('front/hood-vs-suburbs')}}">Hood Vs.Suburbs</a>
                                    <a href="{{url('front/national-inmate-locator')}}">National Inmate Locator</a>
                                    <a href="{{url('front/government-sexism')}}">Government & sexism</a>
                                </ul>
                            </div>
                        </li>
                        <li class="nav-item">
                            @if(Auth::User())
                            <div class="dropdown">
                                <a href="{{url('front/user-profile')}}"><button class="dropbtn">My Profile</button></a>
                            </div>

                            @endif
                        </li>
                        <li class="nav-item">
                            @if(Auth::User())
                            <a href="https://netmaxims.in/projects/powerofourvoice/frontened-logout"><button type="button" class="btn btn-success sign-button">Logout</button></a>
                            @else
                            <a href="https://netmaxims.in/projects/powerofourvoice/login"><button type="button" class="btn btn-success sign-button">Login</button></a>
                            @endif
                        </li>
                    </ul>
                </div>

            </div>

        </nav>

    </header>
    <script>
        window.onload = function() {
            document.getElementById('logout-form').onclick = function() {
                document.getElementById('logout-form').submit();
                return false;
            };
        };
    </script>


    <script type="text/javascript">
        $(window).scroll(function() {
            if ($(this).scrollTop() > 120) {
                $('.header_white').addClass('fixed');
            } else {
                $('.header_white').removeClass('fixed');
            }
        });
    </script>