<!-- start newsletter -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<style>
  .toast.toast-success {
    background: #31c91e;
    opacity: inherit;
}
</style>
@if(Session::has('success_subcriber'))
<script type="text/javascript">
  toastr.options.timeOut = 5000;
  toastr.success("{{ session('success_subcriber') }}");
  // toastr.info("{{ session('del_msg') }}");
  // toastr.warning("{{ session('del_msg') }}");
  // toastr.error("{{ session('del_msg') }}");
</script>
@endif
@if(Session::has('fail_subcriber'))
<script type="text/javascript">
  toastr.options.timeOut = 5000;
  //toastr.success("{{ session('success_subcriber') }}");
  toastr.info("{{ session('fail_subcriber') }}");
  // toastr.warning("{{ session('del_msg') }}");
  // toastr.error("{{ session('del_msg') }}");
</script>
@endif

@if(Session::has('Up_msg'))
<script type="text/javascript">
  toastr.options.timeOut = 5000;
  //toastr.success("{{ session('success_subcriber') }}");
  toastr.success("{{ session('Up_msg') }}");
  // toastr.warning("{{ session('del_msg') }}");
  // toastr.error("{{ session('del_msg') }}");
</script>
@endif

@if(Session::has('Up_fail'))
<script type="text/javascript">
  toastr.options.timeOut = 5000;
  //toastr.success("{{ session('success_subcriber') }}");
  toastr.info("{{ session('Up_fail') }}");
  // toastr.warning("{{ session('del_msg') }}");
  // toastr.error("{{ session('del_msg') }}");
</script>
@endif

@if(Session::has('userimgsuccess'))
<script type="text/javascript">
  toastr.options.timeOut = 5000;
  //toastr.success("{{ session('success_subcriber') }}");
  toastr.success("{{ session('userimgsuccess') }}");
  // toastr.warning("{{ session('del_msg') }}");
  // toastr.error("{{ session('del_msg') }}");
</script>
@endif

@if(Session::has('updateuser'))
<script type="text/javascript">
  toastr.options.timeOut = 5000;
  //toastr.success("{{ session('success_subcriber') }}");
  toastr.success("{{ session('updateuser') }}");
  // toastr.warning("{{ session('del_msg') }}");
  // toastr.error("{{ session('del_msg') }}");
</script>
@endif

@if(Session::has('updateusererror'))
<script type="text/javascript">
  toastr.options.timeOut = 5000;
  //toastr.success("{{ session('success_subcriber') }}");
  toastr.info("{{ session('updateusererror') }}");
  // toastr.warning("{{ session('del_msg') }}");
  // toastr.error("{{ session('del_msg') }}");
</script>
@endif


@if(Session::has('insert_ok'))
<script type="text/javascript">
  toastr.options.timeOut = 5000;
  //toastr.success("{{ session('success_subcriber') }}");
  toastr.success("{{ session('insert_ok') }}");
  // toastr.warning("{{ session('del_msg') }}");
  // toastr.error("{{ session('del_msg') }}");
</script>
@endif

@if(Session::has('insert_fail'))
<script type="text/javascript">
  toastr.options.timeOut = 5000;
  //toastr.success("{{ session('success_subcriber') }}");
  toastr.info("{{ session('insert_fail') }}");
  // toastr.warning("{{ session('del_msg') }}");
  // toastr.error("{{ session('del_msg') }}");
</script>
@endif


<section class="newsletter-main">

<div class="container">

  <div class="row">

    <div class="col-md-6">

  <div class="newsletter-heading">

 <h2>Subscribe To Get My Newsletter</h2>

</div>

</div>

<div class="col-md-6">

 <div class="newsletter-input-field">

 <ul>


 <form action="{{url('front/subscribe')}}" method="post">
 @csrf
      <li><input type="email" placeholder="Enter your email here*" name="mail" required="">

     <button type="submit">Join</button></li>
</form>


    </ul>

</div>

</div>

</div>

</section>

<!-- end news letter -->


<section class="footer-main-class">

  <div class="container">

    <div class="row">

      <div class="col-md-4">

      <div class="footer-second">

     <img src="{{asset('front/images/footer-logo.png')}}">

     <!-- <button type="button" class="btn btn-primary">Book a Consultation</button> -->

      </div>

    </div>

    <div class="col-md-2 qck-serv">

    <div class="footer-second">

    <h2>Quick Links</h2>

    <ul>

      <li><a href="{{  url('front/about-us') }}">About us</a></li>

      <!-- <li><a href="{{  url('#') }}">Services</a></li>
      <li><a href="{{  url('#') }}">Appointment</a></li> -->

      <li><a href="{{  url('front/create-post') }}">Blog</a></li>

      <li><a href="{{  url('front/contact-us') }}">Contact</a></li>

    </ul>

    </div>

  </div>

  <div class="col-md-2 qck-serv">

  <div class="footer-second">

      <h2>Service Links</h2>

      <ul>

        <li><a href="{{  url('front/about-us') }}">About us</a></li>

        <li><a href="{{  url('front/forum') }}">Forum</a></li>

        <li><a href="{{  url('front/pricing') }}">Plans & Pricing</a></li>

        <li><a href="{{  url('front/state-re-entry') }}">Re-entry</a></li>

        <!-- <li><a href="#">Videos</a></li> -->

      </ul>

  </div>

</div>

<div class="col-md-4">

<div class="footer-second">

  <h2 class="left">Contact</h2>

  <ul class="address-section">

   <li> <i class="fa fa-home" aria-hidden="true"></i>  1790 Hadley Road, Lapeer, Michigan 48446   </li>

    <li><i class="fa fa-map-marker" aria-hidden="true"></i>624 W. University Dr. #386, Denton TX 76201</li>

      <li><i class="fa fa-envelope"></i><a href="mailto: info@powerofourvoices.com">Email info@powerofourvoices.com</a></li>

    <li><i class="fa fa-phone" aria-hidden="true"></i> <a href="tel:(231) 598-8498">(231) 598-8498</a></li>

  </ul>

  <ul class="social-icon">

    <li>

   <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>

   <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>

   <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>

    </li>
  </ul>

</div>

</div>

  </div>

</div>

</section>

<!-- end footer section -->

<div class="copyright">

  <p>© 2022 by Power Of Our Voices. | Designed & Developed by Netmaxims</p>

</div>


</body>
</html>


<script type="text/javascript">
         $(function() {
             var url = window.location.href;
             // alert(url);
             $("#menus a").each(function() {
                 if (url == (this.href)) {
                     $(this).closest("li").addClass("actives");

                 } else {
                     $(this).closest("li").removeClass("actives");
                 }

             });
         });
      </script>
