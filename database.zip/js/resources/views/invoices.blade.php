<table>
    <thead>
    <tr>
        <th>title</th>
        <th>author</th>
    </tr>
    </thead>
    <tbody>
    @foreach($invoices as $invoice)
        <tr>
            <td>{{ $invoice->Title_of_Educational_Resource }}</td>
            <td>{{ $invoice->author }}</td>
        </tr>
    @endforeach
    </tbody>
</table>
