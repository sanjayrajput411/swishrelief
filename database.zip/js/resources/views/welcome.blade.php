@include('layouts.front.include.header')
<style>
.tabs.donation-widget.v1_5.no-fast-checkout {
    max-width: 100% !important;
}
</style>

<!-- start banner section -->
<section class="home-main-banner">
  <div class="container">
    <div class="row">
    <div class="col-md-7">
      <div class="home-heading">
        <h6>INTRODUCING</h6>
        <h1>Power of Our Voices LLC</h1>
        <p>We offer free research on major topics like prisons, the legal system, the justice system, prison reform, and social reform. Donations are used to help with giving you the best research and customer service. Any donations to help us continue to help you can be made at.</p>
       <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#staticBackdrop">DONATE</button>

        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Choose amount</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">


              <script src="https://donorbox.org/widget.js" paypalExpress="false"></script><iframe src="https://donorbox.org/embed/power-of-voice" name="donorbox" allowpaymentrequest="allowpaymentrequest" seamless="seamless" frameborder="0" scrolling="no" height="900px" width="100%" style="max-width: 500px; min-width: 250px; max-height:none!important"></iframe>
                      <!-- <h1>Register:</h1>

                      <div class="tab">Custome amount:
                        <p><input  type="number" name="" value="" oninput="this.className = ''" name="amount" placeholder="Enter amount ...." ></p>
                        <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                          <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
                      </div>
                      <div class="tab">Contact Info:
                        <p><input  type="text" name="" value=""  oninput="this.className = ''" name="fname" placeholder="First name..."></p>
                        <p><input  type="text" name="" value=""  oninput="this.className = ''" name="lname" placeholder="Last name..."></p>
                        <p><input  type="email" name="" value=""  oninput="this.className = ''" name="email" placeholder="E-mail..."></p>
                        <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                          <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
                      </div>
                      <div class="tab" style="text-align: center;margin-bottom: 15%;">

                      <form action="{{url('front/payment-success')}}" method="POST">
                      <input type="hidden" id="plan_id" name="plan_id" Value="1">
                        <input type="hidden" name="package_price" value="22">
                       @csrf
                        <p><button name="paywith_paypal" value="paywith_paypal" type="submit" class="paypal_btn" style="background: #efc541;"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-paypal my-2" viewBox="0 0 16 16"></svg>Paywith Paypal </button> </p>
                      </form>

                        <button class="mt-3" type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                      </div>

                      <div style="text-align:center;margin-top:40px;">
                        <span class="step"></span>
                        <span class="step"></span>
                        <span class="step"></span>
                      </div> -->
              </div>
            </div>
          </div>
        </div>

        
      </div>
    </div>
  </div>
  </div>
</section>
<!-- end banner section -->
<section class="book-appointment">
<div class="container-fluid">
<div class="row no-gutter">
  <div class="col-md-4">
    <div class="join-our-team">
        <div class="blance-our">
        <p><img src="{{asset('front/images/phone-banner.png')}}">(231) 598-8498</p>
    </div>
  </div>
   </div>
    <div class="col-md-4">
      <div class="join-our-one">
      <div class="blance-our">
      <p> <img src="{{asset('front/images/balance-banner.png')}}">Join Our Team</p>
      </div>
     </div>
   </div>
      <div class="col-md-4">
        <div class="join-our-two">
      <div class="blance-our">
      <p><img src="{{asset('front/images/book-appoinment.png')}}">Book An Appointment</p>
        </div>
      </div>
    </div>
    </div>
  </div>
</section>
<!-- end section -->
<section class="your-gifts">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
      <div class="will-changes">
        <h2>ABOUT US</h2>
        <h3>Your Gifts Will Change Prisoners’ Lives!</h3>
        <p>Life doesn’t become simpler for people who go to jail. Families are strained and restricted when it comes to visitation and some families choose to disappear from the lives of their inmate all together.Supporting a prisoner shines a hope into a world of darkness and despair. <br> Donations help prisoners go through The Prisoner's Journey, a program that introduces them to the light and hope of changing them, and prisons, from the inside out.</p>
          <a href="{{ url('front/contact-us') }}" class="btn btn-warning">CONTACT US</a>
      </div>
    </div>
    <div class="col-md-6">
      <div class="picture-prisoners">
        <img src="{{asset('front/images/diverse-group.png')}}">
  </div>
  </div>
   </section>
<!-- end section -->
<section class="the-full-store">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="what-we-do">
          <h2>WHAT WE DO</h2>
          <h3>The Full Story</h3>
          <p>​Welcome to Power of Our Voice LLC, a home for people without <br> distinction or separation. We as a community have reached out to those who have experienced the other side of our justice system. The ones that are often prohibited from voting, holding office, or otherwise being heard. They are prisoners who are trying to repay their debt to society and to get back. These individuals, the sometimes forgotten citizens, have spent their time researching and studying to provide the most vital information they could, all the while studying their own personal academics. They do so, so that they can help the people as a whole. They are considered part of the power of our voice's community. We all understand that there's a difference between what should be and what is. Together we hope that we can make change happen, first we must know the truth.</p>
        <a href="{{ url('front/about-us') }}" class="btn btn-warning">MORE INFORMATION</a>
      </div>
    </div>
  </div>
</section>
<!-- end section -->
<section class="choose-your-plan services-mains">
  <div class="container">
    <div class="plans">
      <p>PLANS</p>
      <h2>Choose Your Pricing Plan</h2>
    </div>
    <div class="row">
      <!-- <div class="col-md-4">
    <div class="have-any">
    <h2>Have Any Questions?</h2>
    <p>We work with a wide variety of groups an individuals to promote prison reform. We look forward to hearing from you!</p>
      <button type="button" class="btn btn-warning">Contact Us</button>
  </div>
  </div> -->
      <?php //echo'<pre>';//print_r($data);die;
      ?>
      @if(Auth::User())
      <div class="col-md-4">
        <div class="bronze-plan">
          <h2 style="margin-bottom: 7%;">Bronze Plan</h2>
          <span>Free Plan</span>
          <p>Perfect for those who want to know the truth behind bars</p>
          <ul>
            <i class="fa fa-check"></i>
            <li>Unlimited access to Prisoners' Corner blogs</li>
            <i class="fa fa-check"></i>
            <li>Unlimited forum access</li>
            <i class="fa fa-check"></i>
            <li>Unlimited access to prisoner re-entry resources</li>
          </ul>

          <a style="text-decoration:none;"><button type="button" class="btn btn-warning">Activated</button></a>
        </div>
      </div>
      @else
      <div class="col-md-4">
        <div class="bronze-plan">
          <h2 style="margin-bottom: 7%;">Newsletters</h2>
          <span>Free Plan</span>
          <p>Perfect for those who want to know the truth behind bars</p>
          <ul>
            <i class="fa fa-check"></i>
            <li>Receive articles through Corrlinks.</li>
            <i class="fa fa-check"></i>
            <li>Motivate incarcerated to succeed.</li>
            <i class="fa fa-check"></i>
            <li>Free Service</li>
          </ul>
          @if(Auth::User())
          @else
          <a href="{{url('front/sign-up')}}" style="text-decoration:none;">
          <button type="button" class="btn btn-warning" style="text-decoration:none;position: absolute;margin-left: 23%;">Proceed</button></a>
          @endif
        </div>
      </div>
      @endif

      @if(Auth::User())

      <div class="col-md-4">
      <form  action="{{url('front/billing-details') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <input type="hidden" name="plan_id" value="{{ $plans1['plan_id'] }}">
            <div class="sliver-plan">
              <!---<h2>Silver Plan</h2>
              <h3>$6.95</h3> -->
              <h2 style="margin-bottom: 7%;">{{ $plans1['package_name'] }}</h2>
              <h3>${{ $plans1['plan_price'] }}</h3>
              <span>Paid Plan</span>
              <p>Government officials who found themselves on the wrong side</p>
              <ul>
                <i class="fa fa-check"></i>
                <li>$0.60 / picture</li>
                <i class="fa fa-check"></i>
                <li>$2.50 / 5 pictures</li>
                <i class="fa fa-check"></i>
                <li>$8.00/ 10 pictures</li>
                <li><a href="" class="mx-1" style="color: blue;font-size: 12px;">Important details you should know.</a></li>
              </ul>
              <button type="submit" class="btn btn-warning">Upgrade</button>
            <!--- <a href="{{url('front/billing-details')}}" style="text-decoration:none;">
            <button type="button" class="btn btn-warning">Upgrade</button>
          </a>  -->
          </form>
          </div>
      </div>
      @else
      <div class="col-md-4">
        <div class="sliver-plan">
          <h2 style="margin-bottom: 7%;">Cheer up loved ones</h2>
          <span>Paid Plan</span>
          <p>Government officials who found themselves on the wrong side</p>
          <ul>
               
                <li><input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" style="width: 10%;">$0.60 / picture</li>
                <li><input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" style="width: 10%;">$2.50 / 5 pictures</li>
                <li><input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" style="width: 10%;">$8.00/ 10 pictures</li>
                <li><a href="" class="mx-1" style="color: blue;font-size: 12px;">Important details you should know.</a></li>
          </ul>
          @if(Auth::User())
          @else
           <a href="{{url('front/sign-up')}}" style="text-decoration:none;"><button type="button" class="btn btn-warning">Proceed</button></a>
          @endif
        </div>
      </div>
      @endif

      @if(Auth::User())
      <div class="col-md-4">
      <form  action="{{url('front/billing-details') }}" method="POST" enctype="multipart/form-data">
      @csrf
      <input type="hidden" name="plan_id" value="{{ $plans2['plan_id'] }}">

        <div class="sliver-plan">
          <!---<h2>Platinum</h2>
          <h3>$20.00</h3>-->
          <h2 style="margin-bottom: 7%;">{{ $plans2['package_name'] }}</h2>
              <h3>${{ $plans2['plan_price'] }}</h3>
          <span>Paid Plan</span>
          <p>Government officials who found themselves on the wrong side</p>
          <ul>
            <i class="fa fa-check"></i>
            <li>Compromised judges</li>
            <i class="fa fa-check"></i>
            <li>Compromised congress</li>
          </ul>
         <!---<a href="{{url('front/bill-detail')}}" style="text-decoration:none;"><button type="button" class="btn btn-warning">Upgrade</button></a>-->
         <button type="submit" class="btn btn-warning">Upgrade</button>
         </form>
         </div>
      </div>
      @else
      <div class="col-md-4">
        <div class="sliver-plan">
          <h2 style="margin-bottom: 7%;">Research</h2>
          <span>Paid Plan</span>
          <p>Government officials who found themselves on the wrong side</p>
          <ul>          
            <li><input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" style="width: 10%;">Basic research at $6.95 / month<a href="" class="mx-1" style="color: blue;font-size: 12px;">Details</a></li>         
            <li><input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" style="width: 10%;">Advance research at $0.21 / minute.Additional $0.50 for regular mail<a href="" class="mx-1" style="color: blue;font-size: 12px;">More details</a></li>          
            <li><input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" style="width: 10%;">Case research. The price depends on the scope. Proceed and provide us with the scope.</li>
          </ul>
          @if(Auth::User())
          @else
          <a href="{{url('front/sign-up')}}" style="text-decoration:none;">
          <button type="button" class="btn btn-warning" style="text-decoration: none;position: absolute;margin-left: 23%; margin-top: 0% !important;">Proceed</button></a>
          @endif
        </div>
      </div>
      @endif
    </div>
  </div>
</section>
<script>
$('input[type="checkbox"]').on('change', function() {
   $('input[type="checkbox"]').not(this).prop('checked', false);
});
</script>
<!-- end section -->
<!-- start section blog -->

<!----
<section class="blog-main">
<div class="container">
  <div class="row">
    <div class="col-md-12">
    <div class="bolg-heading">
    <p>OUR BLOG</p>
    <h2>Latest Blog Post</h2>
  </div>
  </div>
  <div class="row">
  <div class="col-md-4">
    <div class="hello-you">
  <img src="{{asset('front/images/hello-dug-blog.png')}}">
</div>
</div>
<div class="col-md-4">
  <div class="hello-you">
<img src="{{asset('front/images/blog-back.png')}}">
</div>
</div>
<div class="col-md-4">
  <div class="hello-you">
    <img src="{{asset('front/images/called-blog.png')}}">
</div>
</div>
</div>
</div>
</section>  -->
<!-- end blog section -->
<!-- start newsletter -->

<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<style>
  .what-we-do a {
    background: #EFC541;
    border-color: #EFC541;
    font-size: 15px;
    color: #fff;
    font-family: Helvetica;
    margin: 0 auto;
    display: block;
    margin-bottom: 4em;
    padding: 7px 22px;
    border-radius: 0;
    margin-bottom: 4em;
    margin-right: 40%;
    margin-left: 40%;
}
.will-changes a {
    background: #EFC541;
    border-color: #EFC541;
    font-family: Helvetica;
    color: #fff;
    font-weight: 600;
    padding: 7px 24px;
    font-size: 15px;
    border-radius: 0;
    margin-top: 20px;
}


/* * {
  box-sizing: border-box;
}

body {
  background-color: #f1f1f1;
} */

#regForm {
  background-color: #ffffff;
    margin: 0 0 15% 15%;
    font-family: Raleway;
    padding: 2px;
    width: 70%;
    min-width: 300px;
}

input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

button {
  background-color: #04AA6D;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: Raleway;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}

#prevBtn {
  background-color: #016617;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #016617;
  border: none;
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #04AA6D;
}
</style>



<script>
var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  //... and run a function that will display the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form...
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class on the current step:
  x[n].className += " active";
}
</script>


@include('layouts.front.include.footer')

<!-- <section class="newsletter-main">

<div class="container">

  <div class="row">

    <div class="col-md-6">

  <div class="newsletter-heading">

 <h2>Subscribe To Get My Newsletter</h2>

</div>

</div>

<div class="col-md-6">

 <div class="newsletter-input-field">

 <ul>

      <li><input type="text" placeholder="Enter your email here*" name="mail" required="">

     <button type="submit">Join</button></li>

    </ul>

</div>

</div>

</div>

</section> -->

<!-- end news letter -->


<!-- <section class="footer-main-class">

  <div class="container">

    <div class="row">

      <div class="col-md-4">

      <div class="footer-second">

     <img src="public/front/images/footer-logo.png">

     <button type="submit">Book a Consultation</button></li>

      </div>

    </div>

    <div class="col-md-2">

    <div class="footer-second">

    <h2>Quick Links</h2>

    <ul>

      <li>About us</li>

      <li>Services</li>

      <li>Appointment</li>

      <li>Blog</li>

      <li>Contact</li>

    </ul>

    </div>

  </div>

  <div class="col-md-2">

  <div class="footer-second">

      <h2>Service Links</h2>

      <ul>

        <li>About us</li>

        <li>Forums</li>

        <li>Plans & Pricing</li>

        <li>Re-entry</li>

        <li>Videos</li>

      </ul>

  </div>

</div>

<div class="col-md-4">

<div class="footer-second">

  <h2 class="left">Contact</h2>

  <ul class="address-section">

   <li> <i class="fas fa-map-marker-alt"></i> 1790 Hadley Road , Lapeer, Michigan 48446 <span>Mailing Address: </span><br>2510 Royal Acres Dr, Denton, Texas 76209</li>

    <li><i class="fa fa-envelope"></i>Email info@powerofourvoices.com</li>

    <li><i class="fa fa-phone-alt"></i>(231) 598-8498</li>

  </ul>

  <ul class="social-icon">

    <li>

      <i class="fab fa-facebook-f"></i>

      <i class="fab fa-twitter"></i>

      <i class="fab fa-instagram"></i>

    </li></li>
  </ul>

</div>

</div>

  </div>

</div>

</section> -->

<!-- end footer section -->

<!-- <div class="copyright">

  <p>© 2022 by Power Of Our Voices. | Designed & Developed by Netmaxims</p>

</div>


</body>
</html>


<script type="text/javascript">
         $(function() {
             var url = window.location.href;
             // alert(url);
             $("#menus a").each(function() {
                 if (url == (this.href)) {
                     $(this).closest("li").addClass("actives");

                 } else {
                     $(this).closest("li").removeClass("actives");
                 }

             });
         });
      </script> -->
